--
-- PostgreSQL database dump
--

\restrict 77TwRn6COBC42aEVr2Pq7dAwNobAn369vtPSBYdLJGyV4KnrBiOae2XLzLGTZWp

-- Dumped from database version 17.9
-- Dumped by pg_dump version 17.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.ordered_work_packages DROP CONSTRAINT IF EXISTS fk_rails_fe038e4e03;
ALTER TABLE IF EXISTS ONLY public.bcf_viewpoints DROP CONSTRAINT IF EXISTS fk_rails_fa5c88e5be;
ALTER TABLE IF EXISTS ONLY public.time_entry_journals DROP CONSTRAINT IF EXISTS fk_rails_f6e3d60ab5;
ALTER TABLE IF EXISTS ONLY public.ical_token_query_assignments DROP CONSTRAINT IF EXISTS fk_rails_f5e934437b;
ALTER TABLE IF EXISTS ONLY public.work_packages DROP CONSTRAINT IF EXISTS fk_rails_f2a8977aa1;
ALTER TABLE IF EXISTS ONLY public.views DROP CONSTRAINT IF EXISTS fk_rails_ef3c430897;
ALTER TABLE IF EXISTS ONLY public.auth_providers DROP CONSTRAINT IF EXISTS fk_rails_e9bd348863;
ALTER TABLE IF EXISTS ONLY public.ordered_work_packages DROP CONSTRAINT IF EXISTS fk_rails_e99c4d5dfe;
ALTER TABLE IF EXISTS ONLY public.webhooks_projects DROP CONSTRAINT IF EXISTS fk_rails_e978b5e3d7;
ALTER TABLE IF EXISTS ONLY public.custom_fields_projects DROP CONSTRAINT IF EXISTS fk_rails_e51cefe60d;
ALTER TABLE IF EXISTS ONLY public.ical_token_query_assignments DROP CONSTRAINT IF EXISTS fk_rails_e0ecbb71e6;
ALTER TABLE IF EXISTS ONLY public.storages_file_links_journals DROP CONSTRAINT IF EXISTS fk_rails_e007095e78;
ALTER TABLE IF EXISTS ONLY public.scheduled_meetings DROP CONSTRAINT IF EXISTS fk_rails_dde1b994c5;
ALTER TABLE IF EXISTS ONLY public.subproject_template_assignments DROP CONSTRAINT IF EXISTS fk_rails_db83d82aa3;
ALTER TABLE IF EXISTS ONLY public.projects_types DROP CONSTRAINT IF EXISTS fk_rails_da213a0c8b;
ALTER TABLE IF EXISTS ONLY public.meeting_outcomes DROP CONSTRAINT IF EXISTS fk_rails_d89fa3e833;
ALTER TABLE IF EXISTS ONLY public.webhooks_projects DROP CONSTRAINT IF EXISTS fk_rails_d7ea5de5b8;
ALTER TABLE IF EXISTS ONLY public.favorites DROP CONSTRAINT IF EXISTS fk_rails_d15744e438;
ALTER TABLE IF EXISTS ONLY public.oidc_group_memberships DROP CONSTRAINT IF EXISTS fk_rails_cefb836ee1;
ALTER TABLE IF EXISTS ONLY public.recurring_meeting_interim_responses DROP CONSTRAINT IF EXISTS fk_rails_cd46c27804;
ALTER TABLE IF EXISTS ONLY public.oauth_applications DROP CONSTRAINT IF EXISTS fk_rails_cc886e315a;
ALTER TABLE IF EXISTS ONLY public.scheduled_meetings DROP CONSTRAINT IF EXISTS fk_rails_c79817dc8f;
ALTER TABLE IF EXISTS ONLY public.hierarchical_items DROP CONSTRAINT IF EXISTS fk_rails_c67cbe751d;
ALTER TABLE IF EXISTS ONLY public.time_entry_activities_projects DROP CONSTRAINT IF EXISTS fk_rails_bc6c409022;
ALTER TABLE IF EXISTS ONLY public.reminders DROP CONSTRAINT IF EXISTS fk_rails_b7e32f12b2;
ALTER TABLE IF EXISTS ONLY public.oauth_access_grants DROP CONSTRAINT IF EXISTS fk_rails_b4b53e07b8;
ALTER TABLE IF EXISTS ONLY public.workflows DROP CONSTRAINT IF EXISTS fk_rails_b4628cffdf;
ALTER TABLE IF EXISTS ONLY public.subproject_template_assignments DROP CONSTRAINT IF EXISTS fk_rails_b15b68fdaf;
ALTER TABLE IF EXISTS ONLY public.project_storages DROP CONSTRAINT IF EXISTS fk_rails_acca00a591;
ALTER TABLE IF EXISTS ONLY public.tokens DROP CONSTRAINT IF EXISTS fk_rails_ac8a5d0441;
ALTER TABLE IF EXISTS ONLY public.user_auth_provider_links DROP CONSTRAINT IF EXISTS fk_rails_aae2d958bb;
ALTER TABLE IF EXISTS ONLY public.file_links DROP CONSTRAINT IF EXISTS fk_rails_a29c1fb981;
ALTER TABLE IF EXISTS ONLY public.webhooks_events DROP CONSTRAINT IF EXISTS fk_rails_a166925c91;
ALTER TABLE IF EXISTS ONLY public.recurring_meetings DROP CONSTRAINT IF EXISTS fk_rails_a0ea141e10;
ALTER TABLE IF EXISTS ONLY public.meeting_outcomes DROP CONSTRAINT IF EXISTS fk_rails_9f4a5cc9ed;
ALTER TABLE IF EXISTS ONLY public.meeting_agenda_item_journals DROP CONSTRAINT IF EXISTS fk_rails_9b6296a185;
ALTER TABLE IF EXISTS ONLY public.user_auth_provider_links DROP CONSTRAINT IF EXISTS fk_rails_9a2c7082f0;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS fk_rails_9702eec5cd;
ALTER TABLE IF EXISTS ONLY public.custom_fields_roles DROP CONSTRAINT IF EXISTS fk_rails_96bf507f15;
ALTER TABLE IF EXISTS ONLY public.project_storages DROP CONSTRAINT IF EXISTS fk_rails_96ab713fe3;
ALTER TABLE IF EXISTS ONLY public.custom_fields_roles DROP CONSTRAINT IF EXISTS fk_rails_950d979cb9;
ALTER TABLE IF EXISTS ONLY public.autologin_session_links DROP CONSTRAINT IF EXISTS fk_rails_93f00f2aab;
ALTER TABLE IF EXISTS ONLY public.work_packages DROP CONSTRAINT IF EXISTS fk_rails_931ad309e8;
ALTER TABLE IF EXISTS ONLY public.meeting_agenda_items DROP CONSTRAINT IF EXISTS fk_rails_9089886cdd;
ALTER TABLE IF EXISTS ONLY public.calculated_value_errors DROP CONSTRAINT IF EXISTS fk_rails_8e54029654;
ALTER TABLE IF EXISTS ONLY public.oidc_group_links DROP CONSTRAINT IF EXISTS fk_rails_8d031325e2;
ALTER TABLE IF EXISTS ONLY public.recaptcha_entries DROP CONSTRAINT IF EXISTS fk_rails_890a90efa9;
ALTER TABLE IF EXISTS ONLY public.emoji_reactions DROP CONSTRAINT IF EXISTS fk_rails_80a9e7c3ce;
ALTER TABLE IF EXISTS ONLY public.remote_identities DROP CONSTRAINT IF EXISTS fk_rails_7f8585fc1a;
ALTER TABLE IF EXISTS ONLY public.project_phases DROP CONSTRAINT IF EXISTS fk_rails_7c456fca1d;
ALTER TABLE IF EXISTS ONLY public.projects_types DROP CONSTRAINT IF EXISTS fk_rails_7c3935a107;
ALTER TABLE IF EXISTS ONLY public.bcf_comments DROP CONSTRAINT IF EXISTS fk_rails_7ac870008c;
ALTER TABLE IF EXISTS ONLY public.project_custom_field_project_mappings DROP CONSTRAINT IF EXISTS fk_rails_79aa0057e4;
ALTER TABLE IF EXISTS ONLY public.last_project_folders DROP CONSTRAINT IF EXISTS fk_rails_73e1c678f1;
ALTER TABLE IF EXISTS ONLY public.oauth_access_tokens DROP CONSTRAINT IF EXISTS fk_rails_732cb83ab7;
ALTER TABLE IF EXISTS ONLY public.recurring_meetings DROP CONSTRAINT IF EXISTS fk_rails_718ca7b915;
ALTER TABLE IF EXISTS ONLY public.time_entries DROP CONSTRAINT IF EXISTS fk_rails_709864c72f;
ALTER TABLE IF EXISTS ONLY public.scim_clients DROP CONSTRAINT IF EXISTS fk_rails_705242b5b2;
ALTER TABLE IF EXISTS ONLY public.oauth_client_tokens DROP CONSTRAINT IF EXISTS fk_rails_6e922d4135;
ALTER TABLE IF EXISTS ONLY public.storages DROP CONSTRAINT IF EXISTS fk_rails_6c69bacb8d;
ALTER TABLE IF EXISTS ONLY public.workflows DROP CONSTRAINT IF EXISTS fk_rails_66af376b7e;
ALTER TABLE IF EXISTS ONLY public.project_phases DROP CONSTRAINT IF EXISTS fk_rails_664dd6ae3c;
ALTER TABLE IF EXISTS ONLY public.oauth_client_tokens DROP CONSTRAINT IF EXISTS fk_rails_65a92bfbf4;
ALTER TABLE IF EXISTS ONLY public.file_links DROP CONSTRAINT IF EXISTS fk_rails_650ebb2e1a;
ALTER TABLE IF EXISTS ONLY public.meeting_sections DROP CONSTRAINT IF EXISTS fk_rails_613c652e16;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS fk_rails_5fe3b44db5;
ALTER TABLE IF EXISTS ONLY public.work_packages DROP CONSTRAINT IF EXISTS fk_rails_5edb6f06e6;
ALTER TABLE IF EXISTS ONLY public.oidc_user_session_links DROP CONSTRAINT IF EXISTS fk_rails_5e6a849f92;
ALTER TABLE IF EXISTS ONLY public.time_entry_activities_projects DROP CONSTRAINT IF EXISTS fk_rails_5b669d4f34;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS fk_rails_595318131c;
ALTER TABLE IF EXISTS ONLY public.bcf_comments DROP CONSTRAINT IF EXISTS fk_rails_556ef6e73e;
ALTER TABLE IF EXISTS ONLY public.webhooks_logs DROP CONSTRAINT IF EXISTS fk_rails_551257cdac;
ALTER TABLE IF EXISTS ONLY public.meeting_outcomes DROP CONSTRAINT IF EXISTS fk_rails_53dfa07660;
ALTER TABLE IF EXISTS ONLY public.ifc_models DROP CONSTRAINT IF EXISTS fk_rails_4f53d4601c;
ALTER TABLE IF EXISTS ONLY public.bcf_issues DROP CONSTRAINT IF EXISTS fk_rails_4e35bc3056;
ALTER TABLE IF EXISTS ONLY public.export_settings DROP CONSTRAINT IF EXISTS fk_rails_4e2ea236a3;
ALTER TABLE IF EXISTS ONLY public.reminder_notifications DROP CONSTRAINT IF EXISTS fk_rails_4db3d8d95d;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS fk_rails_4aea6afa11;
ALTER TABLE IF EXISTS ONLY public.notification_settings DROP CONSTRAINT IF EXISTS fk_rails_496a500fda;
ALTER TABLE IF EXISTS ONLY public.types DROP CONSTRAINT IF EXISTS fk_rails_46ceaf0e5b;
ALTER TABLE IF EXISTS ONLY public.ldap_groups_synchronized_groups DROP CONSTRAINT IF EXISTS fk_rails_44dac1537e;
ALTER TABLE IF EXISTS ONLY public.reminder_notifications DROP CONSTRAINT IF EXISTS fk_rails_4398e72474;
ALTER TABLE IF EXISTS ONLY public.wiki_pages DROP CONSTRAINT IF EXISTS fk_rails_4189064f3f;
ALTER TABLE IF EXISTS ONLY public.meeting_agenda_items DROP CONSTRAINT IF EXISTS fk_rails_3f56abf49c;
ALTER TABLE IF EXISTS ONLY public.oauth_applications DROP CONSTRAINT IF EXISTS fk_rails_3d1f3b58d2;
ALTER TABLE IF EXISTS ONLY public.recurring_meeting_interim_responses DROP CONSTRAINT IF EXISTS fk_rails_2bc91bc636;
ALTER TABLE IF EXISTS ONLY public.workflows DROP CONSTRAINT IF EXISTS fk_rails_2a8f410364;
ALTER TABLE IF EXISTS ONLY public.project_custom_field_project_mappings DROP CONSTRAINT IF EXISTS fk_rails_1a1f3f10e9;
ALTER TABLE IF EXISTS ONLY public.service_account_associations DROP CONSTRAINT IF EXISTS fk_rails_18733515b3;
ALTER TABLE IF EXISTS ONLY public.oidc_user_tokens DROP CONSTRAINT IF EXISTS fk_rails_1571e35480;
ALTER TABLE IF EXISTS ONLY public.custom_fields_projects DROP CONSTRAINT IF EXISTS fk_rails_12fb30588e;
ALTER TABLE IF EXISTS ONLY public.oidc_group_links DROP CONSTRAINT IF EXISTS fk_rails_0ed529eb13;
ALTER TABLE IF EXISTS ONLY public.project_phase_journals DROP CONSTRAINT IF EXISTS fk_rails_0e71534908;
ALTER TABLE IF EXISTS ONLY public.cost_entries DROP CONSTRAINT IF EXISTS fk_rails_0d35f09506;
ALTER TABLE IF EXISTS ONLY public.project_phase_definitions DROP CONSTRAINT IF EXISTS fk_rails_0cd5e50674;
ALTER TABLE IF EXISTS ONLY public.notification_settings DROP CONSTRAINT IF EXISTS fk_rails_0c95e91db7;
ALTER TABLE IF EXISTS ONLY public.workflows DROP CONSTRAINT IF EXISTS fk_rails_0c5f149c21;
ALTER TABLE IF EXISTS ONLY public.two_factor_authentication_devices DROP CONSTRAINT IF EXISTS fk_rails_0b09e132e7;
ALTER TABLE IF EXISTS ONLY public.meeting_agenda_items DROP CONSTRAINT IF EXISTS fk_rails_06b94602d9;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS fk_rails_06a39bb8cc;
ALTER TABLE IF EXISTS ONLY public.oidc_group_memberships DROP CONSTRAINT IF EXISTS fk_rails_061b856d2a;
ALTER TABLE IF EXISTS ONLY public.bcf_comments DROP CONSTRAINT IF EXISTS fk_rails_0571c4b386;
ALTER TABLE IF EXISTS ONLY public.project_storages DROP CONSTRAINT IF EXISTS fk_rails_04546d7b88;
DROP INDEX IF EXISTS public.work_package_journal_on_burndown_attributes;
DROP INDEX IF EXISTS public.work_package_desc_idx;
DROP INDEX IF EXISTS public.work_package_anc_desc_idx;
DROP INDEX IF EXISTS public.wkfs_role_type_old_status;
DROP INDEX IF EXISTS public.wikis_project_id;
DROP INDEX IF EXISTS public.wiki_redirects_wiki_id_title;
DROP INDEX IF EXISTS public.wiki_pages_wiki_id_title;
DROP INDEX IF EXISTS public.wiki_pages_wiki_id_slug;
DROP INDEX IF EXISTS public.watchers_user_id_type;
DROP INDEX IF EXISTS public.versions_project_id;
DROP INDEX IF EXISTS public.unique_lastname_for_groups_and_placeholder_users;
DROP INDEX IF EXISTS public.unique_inherited_role;
DROP INDEX IF EXISTS public.unique_index_gl_mrs_wps_on_gl_mr_id_and_wp_id;
DROP INDEX IF EXISTS public.unique_index_gl_issues_wps_on_gl_issue_id_and_wp_id;
DROP INDEX IF EXISTS public.unique_index_gh_prs_wps_on_gh_pr_id_and_wp_id;
DROP INDEX IF EXISTS public.time_entries_project_id;
DROP INDEX IF EXISTS public.time_entries_issue_id;
DROP INDEX IF EXISTS public.projects_types_unique;
DROP INDEX IF EXISTS public.projects_types_project_id;
DROP INDEX IF EXISTS public.news_project_id;
DROP INDEX IF EXISTS public.messages_parent_id;
DROP INDEX IF EXISTS public.messages_board_id;
DROP INDEX IF EXISTS public.item_desc_idx;
DROP INDEX IF EXISTS public.item_anc_desc_idx;
DROP INDEX IF EXISTS public.issue_categories_project_id;
DROP INDEX IF EXISTS public.index_workflows_on_role_id;
DROP INDEX IF EXISTS public.index_workflows_on_old_status_id;
DROP INDEX IF EXISTS public.index_workflows_on_new_status_id;
DROP INDEX IF EXISTS public.index_work_packages_on_version_id;
DROP INDEX IF EXISTS public.index_work_packages_on_updated_at;
DROP INDEX IF EXISTS public.index_work_packages_on_type_id;
DROP INDEX IF EXISTS public.index_work_packages_on_status_id;
DROP INDEX IF EXISTS public.index_work_packages_on_start_date;
DROP INDEX IF EXISTS public.index_work_packages_on_schedule_manually;
DROP INDEX IF EXISTS public.index_work_packages_on_responsible_id;
DROP INDEX IF EXISTS public.index_work_packages_on_project_phase_definition_id;
DROP INDEX IF EXISTS public.index_work_packages_on_project_id_and_updated_at;
DROP INDEX IF EXISTS public.index_work_packages_on_project_id;
DROP INDEX IF EXISTS public.index_work_packages_on_parent_id;
DROP INDEX IF EXISTS public.index_work_packages_on_due_date;
DROP INDEX IF EXISTS public.index_work_packages_on_created_at;
DROP INDEX IF EXISTS public.index_work_packages_on_category_id;
DROP INDEX IF EXISTS public.index_work_packages_on_author_id;
DROP INDEX IF EXISTS public.index_work_packages_on_assigned_to_id;
DROP INDEX IF EXISTS public.index_work_package_journals_on_version_id;
DROP INDEX IF EXISTS public.index_work_package_journals_on_type_id;
DROP INDEX IF EXISTS public.index_work_package_journals_on_status_id;
DROP INDEX IF EXISTS public.index_work_package_journals_on_start_date;
DROP INDEX IF EXISTS public.index_work_package_journals_on_schedule_manually;
DROP INDEX IF EXISTS public.index_work_package_journals_on_responsible_id;
DROP INDEX IF EXISTS public.index_work_package_journals_on_project_id;
DROP INDEX IF EXISTS public.index_work_package_journals_on_parent_id;
DROP INDEX IF EXISTS public.index_work_package_journals_on_due_date;
DROP INDEX IF EXISTS public.index_work_package_journals_on_category_id;
DROP INDEX IF EXISTS public.index_work_package_journals_on_author_id;
DROP INDEX IF EXISTS public.index_work_package_journals_on_assigned_to_id;
DROP INDEX IF EXISTS public.index_wiki_redirects_on_wiki_id;
DROP INDEX IF EXISTS public.index_wiki_pages_on_wiki_id;
DROP INDEX IF EXISTS public.index_wiki_pages_on_updated_at;
DROP INDEX IF EXISTS public.index_wiki_pages_on_parent_id;
DROP INDEX IF EXISTS public.index_wiki_pages_on_author_id;
DROP INDEX IF EXISTS public."index_webhooks_webhooks_on_LOWER_name";
DROP INDEX IF EXISTS public.index_webhooks_projects_on_webhooks_webhook_id;
DROP INDEX IF EXISTS public.index_webhooks_projects_on_project_id;
DROP INDEX IF EXISTS public.index_webhooks_logs_on_webhooks_webhook_id;
DROP INDEX IF EXISTS public.index_webhooks_events_on_webhooks_webhook_id;
DROP INDEX IF EXISTS public.index_watchers_on_watchable_id_and_watchable_type;
DROP INDEX IF EXISTS public.index_watchers_on_user_id_and_watchable;
DROP INDEX IF EXISTS public.index_watchers_on_user_id;
DROP INDEX IF EXISTS public.index_views_on_query_id;
DROP INDEX IF EXISTS public.index_versions_on_sharing;
DROP INDEX IF EXISTS public."index_versions_on_project_id_and_LOWER_name";
DROP INDEX IF EXISTS public.index_version_settings_on_project_id_and_version_id;
DROP INDEX IF EXISTS public.index_users_on_type_and_status;
DROP INDEX IF EXISTS public.index_users_on_type_and_login;
DROP INDEX IF EXISTS public.index_users_on_type;
DROP INDEX IF EXISTS public.index_users_on_ldap_auth_source_id;
DROP INDEX IF EXISTS public.index_users_on_id_and_type;
DROP INDEX IF EXISTS public.index_user_prefs_settings_workdays;
DROP INDEX IF EXISTS public.index_user_prefs_settings_time_zone;
DROP INDEX IF EXISTS public.index_user_prefs_settings_pause_reminders_enabled;
DROP INDEX IF EXISTS public.index_user_prefs_settings_daily_reminders_times;
DROP INDEX IF EXISTS public.index_user_prefs_settings_daily_reminders_enabled;
DROP INDEX IF EXISTS public.index_user_preferences_on_user_id;
DROP INDEX IF EXISTS public.index_user_passwords_on_user_id;
DROP INDEX IF EXISTS public.index_user_auth_provider_links_on_user_id_and_auth_provider_id;
DROP INDEX IF EXISTS public.index_user_auth_provider_links_on_user_id;
DROP INDEX IF EXISTS public.index_user_auth_provider_links_on_auth_provider_id;
DROP INDEX IF EXISTS public.index_unique_calc_val_error_per_customized_and_cf;
DROP INDEX IF EXISTS public.index_types_on_color_id;
DROP INDEX IF EXISTS public."index_types_on_LOWER_name";
DROP INDEX IF EXISTS public.index_two_factor_authentication_devices_on_webauthn_external_id;
DROP INDEX IF EXISTS public.index_two_factor_authentication_devices_on_user_id;
DROP INDEX IF EXISTS public.index_tokens_on_user_id;
DROP INDEX IF EXISTS public.index_time_entry_journals_on_project_id;
DROP INDEX IF EXISTS public.index_time_entry_journals_on_logged_by_id;
DROP INDEX IF EXISTS public.index_time_entry_journals_on_entity_type_and_entity_id;
DROP INDEX IF EXISTS public.index_time_entry_journals_on_entity;
DROP INDEX IF EXISTS public.index_time_entry_activities_projects_on_project_id;
DROP INDEX IF EXISTS public.index_time_entry_activities_projects_on_activity_id;
DROP INDEX IF EXISTS public.index_time_entry_activities_projects_on_active;
DROP INDEX IF EXISTS public.index_time_entries_on_user_id_and_ongoing;
DROP INDEX IF EXISTS public.index_time_entries_on_user_id;
DROP INDEX IF EXISTS public.index_time_entries_on_project_id_and_updated_at;
DROP INDEX IF EXISTS public.index_time_entries_on_ongoing;
DROP INDEX IF EXISTS public.index_time_entries_on_logged_by_id;
DROP INDEX IF EXISTS public.index_time_entries_on_entity_type_and_entity_id;
DROP INDEX IF EXISTS public.index_time_entries_on_entity;
DROP INDEX IF EXISTS public.index_time_entries_on_created_at;
DROP INDEX IF EXISTS public.index_time_entries_on_activity_id;
DROP INDEX IF EXISTS public.index_teap_on_project_id_and_activity_id;
DROP INDEX IF EXISTS public.index_subproject_template_assignments_on_workspace_type;
DROP INDEX IF EXISTS public.index_subproject_template_assignments_on_template_id;
DROP INDEX IF EXISTS public.index_subproject_template_assignments_on_project_id;
DROP INDEX IF EXISTS public.index_storages_on_name;
DROP INDEX IF EXISTS public.index_storages_on_host;
DROP INDEX IF EXISTS public.index_storages_on_creator_id;
DROP INDEX IF EXISTS public."index_storages_on_LOWER_name";
DROP INDEX IF EXISTS public.index_storages_file_links_journals_on_journal_id;
DROP INDEX IF EXISTS public.index_storages_file_links_journals_on_file_link_id;
DROP INDEX IF EXISTS public.index_statuses_on_position;
DROP INDEX IF EXISTS public.index_statuses_on_is_default;
DROP INDEX IF EXISTS public.index_statuses_on_is_closed;
DROP INDEX IF EXISTS public.index_statuses_on_color_id;
DROP INDEX IF EXISTS public."index_statuses_on_LOWER_name";
DROP INDEX IF EXISTS public.index_settings_on_name;
DROP INDEX IF EXISTS public.index_sessions_on_user_id;
DROP INDEX IF EXISTS public.index_sessions_on_updated_at;
DROP INDEX IF EXISTS public.index_sessions_on_session_id;
DROP INDEX IF EXISTS public.index_service_account_associations_on_service_account_id;
DROP INDEX IF EXISTS public.index_scim_clients_on_auth_provider_id;
DROP INDEX IF EXISTS public.index_scheduled_meetings_on_recurring_meeting_id;
DROP INDEX IF EXISTS public.index_scheduled_meetings_on_meeting_id;
DROP INDEX IF EXISTS public."index_roles_on_LOWER_name";
DROP INDEX IF EXISTS public.index_role_permissions_on_role_id;
DROP INDEX IF EXISTS public.index_repositories_on_project_id;
DROP INDEX IF EXISTS public.index_remote_identities_on_integration_type_and_integration_id;
DROP INDEX IF EXISTS public.index_remote_identities_on_auth_source_type_and_auth_source_id;
DROP INDEX IF EXISTS public.index_reminders_on_remindable;
DROP INDEX IF EXISTS public.index_reminders_on_creator_id;
DROP INDEX IF EXISTS public.index_reminder_notifications_unique;
DROP INDEX IF EXISTS public.index_reminder_notifications_on_reminder_id;
DROP INDEX IF EXISTS public.index_reminder_notifications_on_notification_id;
DROP INDEX IF EXISTS public.index_relations_on_to_id_and_from_id_and_relation_type;
DROP INDEX IF EXISTS public.index_relations_on_to_id;
DROP INDEX IF EXISTS public.index_relations_on_from_id_and_to_id_and_relation_type;
DROP INDEX IF EXISTS public.index_relations_on_from_id;
DROP INDEX IF EXISTS public.index_recurring_meetings_on_uid;
DROP INDEX IF EXISTS public.index_recurring_meetings_on_project_id;
DROP INDEX IF EXISTS public.index_recurring_meetings_on_author_id;
DROP INDEX IF EXISTS public.index_recaptcha_entries_on_user_id;
DROP INDEX IF EXISTS public.index_queries_on_user_id;
DROP INDEX IF EXISTS public.index_queries_on_updated_at;
DROP INDEX IF EXISTS public.index_queries_on_project_id;
DROP INDEX IF EXISTS public.index_projects_on_workspace_type;
DROP INDEX IF EXISTS public.index_projects_on_template_id;
DROP INDEX IF EXISTS public.index_projects_on_rgt;
DROP INDEX IF EXISTS public.index_projects_on_lft_and_rgt;
DROP INDEX IF EXISTS public.index_projects_on_lft;
DROP INDEX IF EXISTS public.index_projects_on_identifier;
DROP INDEX IF EXISTS public.index_projects_on_active;
DROP INDEX IF EXISTS public.index_project_storages_on_storage_id;
DROP INDEX IF EXISTS public.index_project_storages_on_project_id_and_storage_id;
DROP INDEX IF EXISTS public.index_project_storages_on_project_id;
DROP INDEX IF EXISTS public.index_project_storages_on_creator_id;
DROP INDEX IF EXISTS public.index_project_queries_on_user_id;
DROP INDEX IF EXISTS public.index_project_queries_on_public;
DROP INDEX IF EXISTS public.index_project_phases_on_start_date;
DROP INDEX IF EXISTS public.index_project_phases_on_project_id_and_definition_id;
DROP INDEX IF EXISTS public.index_project_phases_on_project_id;
DROP INDEX IF EXISTS public.index_project_phases_on_finish_date;
DROP INDEX IF EXISTS public.index_project_phases_on_definition_id;
DROP INDEX IF EXISTS public.index_project_phase_journals_on_phase_id;
DROP INDEX IF EXISTS public.index_project_phase_journals_on_journal_id;
DROP INDEX IF EXISTS public.index_project_phase_definitions_on_name;
DROP INDEX IF EXISTS public.index_project_phase_definitions_on_color_id;
DROP INDEX IF EXISTS public.index_project_custom_field_project_mappings_unique;
DROP INDEX IF EXISTS public.index_project_custom_field_project_mappings_on_project_id;
DROP INDEX IF EXISTS public.index_project_cf_project_mappings_on_custom_field_id;
DROP INDEX IF EXISTS public.index_paper_trail_audits_on_item_type_and_item_id;
DROP INDEX IF EXISTS public.index_ordered_work_packages_on_work_package_id;
DROP INDEX IF EXISTS public.index_ordered_work_packages_on_query_id;
DROP INDEX IF EXISTS public.index_ordered_work_packages_on_position;
DROP INDEX IF EXISTS public.index_oidc_user_tokens_on_user_id;
DROP INDEX IF EXISTS public.index_oidc_user_session_links_on_session_id;
DROP INDEX IF EXISTS public.index_oidc_user_session_links_on_oidc_session;
DROP INDEX IF EXISTS public.index_oidc_group_memberships_on_group_user_id;
DROP INDEX IF EXISTS public.index_oidc_group_links_on_group_id;
DROP INDEX IF EXISTS public.index_oidc_group_links_on_auth_provider_id_and_oidc_group_name;
DROP INDEX IF EXISTS public.index_oauth_clients_on_integration;
DROP INDEX IF EXISTS public.index_oauth_client_tokens_on_user_id_and_oauth_client_id;
DROP INDEX IF EXISTS public.index_oauth_client_tokens_on_user_id;
DROP INDEX IF EXISTS public.index_oauth_client_tokens_on_oauth_client_id;
DROP INDEX IF EXISTS public.index_oauth_applications_on_uid;
DROP INDEX IF EXISTS public.index_oauth_applications_on_owner_id_and_owner_type;
DROP INDEX IF EXISTS public.index_oauth_applications_on_integration;
DROP INDEX IF EXISTS public.index_oauth_access_tokens_on_token;
DROP INDEX IF EXISTS public.index_oauth_access_tokens_on_resource_owner_id;
DROP INDEX IF EXISTS public.index_oauth_access_tokens_on_refresh_token;
DROP INDEX IF EXISTS public.index_oauth_access_tokens_on_application_id;
DROP INDEX IF EXISTS public.index_oauth_access_grants_on_token;
DROP INDEX IF EXISTS public.index_oauth_access_grants_on_resource_owner_id;
DROP INDEX IF EXISTS public.index_oauth_access_grants_on_application_id;
DROP INDEX IF EXISTS public.index_notifications_on_resource;
DROP INDEX IF EXISTS public.index_notifications_on_recipient_id;
DROP INDEX IF EXISTS public.index_notifications_on_read_ian;
DROP INDEX IF EXISTS public.index_notifications_on_mail_reminder_sent;
DROP INDEX IF EXISTS public.index_notifications_on_mail_alert_sent;
DROP INDEX IF EXISTS public.index_notifications_on_journal_id;
DROP INDEX IF EXISTS public.index_notifications_on_actor_id;
DROP INDEX IF EXISTS public.index_notification_settings_unique_project_null;
DROP INDEX IF EXISTS public.index_notification_settings_unique_project;
DROP INDEX IF EXISTS public.index_notification_settings_on_work_package_scheduled;
DROP INDEX IF EXISTS public.index_notification_settings_on_work_package_processed;
DROP INDEX IF EXISTS public.index_notification_settings_on_work_package_prioritized;
DROP INDEX IF EXISTS public.index_notification_settings_on_work_package_created;
DROP INDEX IF EXISTS public.index_notification_settings_on_work_package_commented;
DROP INDEX IF EXISTS public.index_notification_settings_on_wiki_page_updated;
DROP INDEX IF EXISTS public.index_notification_settings_on_wiki_page_added;
DROP INDEX IF EXISTS public.index_notification_settings_on_user_id;
DROP INDEX IF EXISTS public.index_notification_settings_on_project_id;
DROP INDEX IF EXISTS public.index_notification_settings_on_news_commented;
DROP INDEX IF EXISTS public.index_notification_settings_on_news_added;
DROP INDEX IF EXISTS public.index_notification_settings_on_membership_updated;
DROP INDEX IF EXISTS public.index_notification_settings_on_membership_added;
DROP INDEX IF EXISTS public.index_notification_settings_on_forum_messages;
DROP INDEX IF EXISTS public.index_notification_settings_on_document_added;
DROP INDEX IF EXISTS public.index_non_working_days_on_date;
DROP INDEX IF EXISTS public.index_news_on_project_id_and_created_at;
DROP INDEX IF EXISTS public.index_news_on_created_at;
DROP INDEX IF EXISTS public.index_news_on_author_id;
DROP INDEX IF EXISTS public.index_news_journals_on_project_id;
DROP INDEX IF EXISTS public.index_messages_on_last_reply_id;
DROP INDEX IF EXISTS public.index_messages_on_forum_id_and_updated_at;
DROP INDEX IF EXISTS public.index_messages_on_created_at;
DROP INDEX IF EXISTS public.index_messages_on_author_id;
DROP INDEX IF EXISTS public.index_menu_items_on_parent_id;
DROP INDEX IF EXISTS public.index_menu_items_on_navigatable_id_and_title;
DROP INDEX IF EXISTS public.index_members_on_user_id_and_project_without_entity;
DROP INDEX IF EXISTS public.index_members_on_user_id_and_project_with_entity;
DROP INDEX IF EXISTS public.index_members_on_user_id;
DROP INDEX IF EXISTS public.index_members_on_project_id;
DROP INDEX IF EXISTS public.index_members_on_entity;
DROP INDEX IF EXISTS public.index_member_roles_on_role_id;
DROP INDEX IF EXISTS public.index_member_roles_on_member_id;
DROP INDEX IF EXISTS public.index_member_roles_on_inherited_from;
DROP INDEX IF EXISTS public.index_meetings_on_uid;
DROP INDEX IF EXISTS public.index_meetings_on_recurring_meeting_id;
DROP INDEX IF EXISTS public.index_meetings_on_project_id_and_updated_at;
DROP INDEX IF EXISTS public.index_meeting_sections_on_meeting_id;
DROP INDEX IF EXISTS public.index_meeting_participants_on_user_id;
DROP INDEX IF EXISTS public.index_meeting_participants_on_meeting_id;
DROP INDEX IF EXISTS public.index_meeting_outcomes_on_work_package_id;
DROP INDEX IF EXISTS public.index_meeting_outcomes_on_meeting_agenda_item_id;
DROP INDEX IF EXISTS public.index_meeting_outcomes_on_author_id;
DROP INDEX IF EXISTS public.index_meeting_agenda_items_on_work_package_id;
DROP INDEX IF EXISTS public.index_meeting_agenda_items_on_presenter_id;
DROP INDEX IF EXISTS public.index_meeting_agenda_items_on_notes;
DROP INDEX IF EXISTS public.index_meeting_agenda_items_on_meeting_section_id;
DROP INDEX IF EXISTS public.index_meeting_agenda_items_on_meeting_id;
DROP INDEX IF EXISTS public.index_meeting_agenda_items_on_author_id;
DROP INDEX IF EXISTS public.index_meeting_agenda_item_journals_on_presenter_id;
DROP INDEX IF EXISTS public.index_ldap_groups_synchronized_groups_on_ldap_auth_source_id;
DROP INDEX IF EXISTS public.index_ldap_groups_synchronized_groups_on_group_id;
DROP INDEX IF EXISTS public.index_ldap_groups_synchronized_groups_on_filter_id;
DROP INDEX IF EXISTS public.index_ldap_groups_synchronized_filters_on_ldap_auth_source_id;
DROP INDEX IF EXISTS public.index_ldap_groups_memberships_on_user_id_and_group_id;
DROP INDEX IF EXISTS public.index_ldap_groups_memberships_on_user_id;
DROP INDEX IF EXISTS public.index_ldap_groups_memberships_on_group_id;
DROP INDEX IF EXISTS public."index_ldap_auth_sources_on_LOWER_name";
DROP INDEX IF EXISTS public.index_last_project_folders_on_project_storage_id_and_mode;
DROP INDEX IF EXISTS public.index_last_project_folders_on_project_storage_id;
DROP INDEX IF EXISTS public.index_journals_on_user_id;
DROP INDEX IF EXISTS public.index_journals_on_notes;
DROP INDEX IF EXISTS public.index_journals_on_journable_type_and_journable_id_and_version;
DROP INDEX IF EXISTS public.index_journals_on_journable_type;
DROP INDEX IF EXISTS public.index_journals_on_journable_id;
DROP INDEX IF EXISTS public.index_journals_on_data_id_and_data_type;
DROP INDEX IF EXISTS public.index_journals_on_created_at;
DROP INDEX IF EXISTS public.index_job_statuses_on_user_id;
DROP INDEX IF EXISTS public.index_job_statuses_on_reference_type_and_reference_id;
DROP INDEX IF EXISTS public.index_job_statuses_on_job_id;
DROP INDEX IF EXISTS public.index_ifc_models_on_uploader_id;
DROP INDEX IF EXISTS public.index_ifc_models_on_project_id;
DROP INDEX IF EXISTS public.index_ifc_models_on_is_default;
DROP INDEX IF EXISTS public.index_ical_token_query_assignments_on_query_id;
DROP INDEX IF EXISTS public.index_ical_token_query_assignments_on_ical_token_id;
DROP INDEX IF EXISTS public.index_hierarchical_items_on_position_cache;
DROP INDEX IF EXISTS public.index_hierarchical_items_on_custom_field_id;
DROP INDEX IF EXISTS public.index_group_users_on_user_id_and_group_id;
DROP INDEX IF EXISTS public.index_grids_on_user_id;
DROP INDEX IF EXISTS public.index_grids_on_project_id;
DROP INDEX IF EXISTS public.index_grid_widgets_on_grid_id;
DROP INDEX IF EXISTS public.index_good_jobs_on_scheduled_at;
DROP INDEX IF EXISTS public.index_good_jobs_on_queue_name_and_scheduled_at;
DROP INDEX IF EXISTS public.index_good_jobs_on_priority_scheduled_at_unfinished_unlocked;
DROP INDEX IF EXISTS public.index_good_jobs_on_locked_by_id;
DROP INDEX IF EXISTS public.index_good_jobs_on_labels;
DROP INDEX IF EXISTS public.index_good_jobs_on_job_class;
DROP INDEX IF EXISTS public.index_good_jobs_on_cron_key_and_cron_at_cond;
DROP INDEX IF EXISTS public.index_good_jobs_on_cron_key_and_created_at_cond;
DROP INDEX IF EXISTS public.index_good_jobs_on_concurrency_key_when_unfinished;
DROP INDEX IF EXISTS public.index_good_jobs_on_concurrency_key_and_created_at;
DROP INDEX IF EXISTS public.index_good_jobs_on_batch_id;
DROP INDEX IF EXISTS public.index_good_jobs_on_batch_callback_id;
DROP INDEX IF EXISTS public.index_good_jobs_on_active_job_id_and_created_at;
DROP INDEX IF EXISTS public.index_good_jobs_jobs_on_priority_created_at_when_unfinished;
DROP INDEX IF EXISTS public.index_good_jobs_jobs_on_finished_at;
DROP INDEX IF EXISTS public.index_good_job_settings_on_key;
DROP INDEX IF EXISTS public.index_good_job_jobs_for_candidate_lookup;
DROP INDEX IF EXISTS public.index_good_job_executions_on_process_id_and_created_at;
DROP INDEX IF EXISTS public.index_good_job_executions_on_active_job_id_and_created_at;
DROP INDEX IF EXISTS public.index_gitlab_pipelines_on_gitlab_merge_request_id;
DROP INDEX IF EXISTS public.index_gitlab_merge_requests_on_merged_by_id;
DROP INDEX IF EXISTS public.index_gitlab_merge_requests_on_gitlab_user_id;
DROP INDEX IF EXISTS public.index_gitlab_issues_on_gitlab_user_id;
DROP INDEX IF EXISTS public.index_github_pull_requests_on_merged_by_id;
DROP INDEX IF EXISTS public.index_github_pull_requests_on_github_user_id;
DROP INDEX IF EXISTS public.index_github_check_runs_on_github_pull_request_id;
DROP INDEX IF EXISTS public.index_forums_on_last_message_id;
DROP INDEX IF EXISTS public.index_file_links_on_storage_id;
DROP INDEX IF EXISTS public.index_file_links_on_origin_id_and_storage_id;
DROP INDEX IF EXISTS public.index_file_links_on_creator_id;
DROP INDEX IF EXISTS public.index_file_links_on_container_id_and_container_type;
DROP INDEX IF EXISTS public.index_favorites_on_user_id_and_favorited_type_and_favorited_id;
DROP INDEX IF EXISTS public.index_favorites_on_user_id;
DROP INDEX IF EXISTS public.index_favorites_on_favorited_type_and_favorited_id;
DROP INDEX IF EXISTS public.index_favorites_on_favored;
DROP INDEX IF EXISTS public.index_export_settings_on_query_id_and_format;
DROP INDEX IF EXISTS public.index_export_settings_on_query_id;
DROP INDEX IF EXISTS public."index_enumerations_on_type_project_id_and_LOWER_name";
DROP INDEX IF EXISTS public.index_enumerations_on_project_id;
DROP INDEX IF EXISTS public.index_enumerations_on_id_and_type;
DROP INDEX IF EXISTS public.index_enumerations_on_color_id;
DROP INDEX IF EXISTS public.index_enterprise_tokens_on_valid_from_and_valid_until;
DROP INDEX IF EXISTS public.index_enabled_modules_on_name;
DROP INDEX IF EXISTS public.index_emoji_reactions_uniqueness;
DROP INDEX IF EXISTS public.index_emoji_reactions_on_user_id;
DROP INDEX IF EXISTS public.index_emoji_reactions_on_reaction;
DROP INDEX IF EXISTS public.index_emoji_reactions_on_reactable;
DROP INDEX IF EXISTS public.index_documents_on_type_id;
DROP INDEX IF EXISTS public.index_documents_on_created_at;
DROP INDEX IF EXISTS public.index_documents_on_category_id;
DROP INDEX IF EXISTS public.index_document_types_on_name;
DROP INDEX IF EXISTS public.index_design_colors_on_variable;
DROP INDEX IF EXISTS public.index_deploy_targets_on_host;
DROP INDEX IF EXISTS public.index_deploy_status_checks_on_github_pull_request_id;
DROP INDEX IF EXISTS public.index_deploy_status_checks_on_deploy_target_id;
DROP INDEX IF EXISTS public.index_customizable_journals_on_journal_id;
DROP INDEX IF EXISTS public.index_customizable_journals_on_custom_field_id;
DROP INDEX IF EXISTS public.index_custom_values_on_value;
DROP INDEX IF EXISTS public.index_custom_values_on_custom_field_id;
DROP INDEX IF EXISTS public.index_custom_options_on_value;
DROP INDEX IF EXISTS public.index_custom_options_on_custom_field_id;
DROP INDEX IF EXISTS public.index_custom_fields_roles_on_role_id;
DROP INDEX IF EXISTS public.index_custom_fields_roles_on_custom_field_id;
DROP INDEX IF EXISTS public.index_custom_fields_projects_on_custom_field_id_and_project_id;
DROP INDEX IF EXISTS public."index_custom_fields_on_type_and_LOWER_name";
DROP INDEX IF EXISTS public.index_custom_fields_on_id_and_type;
DROP INDEX IF EXISTS public.index_custom_fields_on_formula;
DROP INDEX IF EXISTS public.index_custom_fields_on_custom_field_section_id;
DROP INDEX IF EXISTS public.index_custom_actions_types_on_type_id;
DROP INDEX IF EXISTS public.index_custom_actions_types_on_custom_action_id;
DROP INDEX IF EXISTS public.index_custom_actions_statuses_on_status_id;
DROP INDEX IF EXISTS public.index_custom_actions_statuses_on_custom_action_id;
DROP INDEX IF EXISTS public.index_custom_actions_roles_on_role_id;
DROP INDEX IF EXISTS public.index_custom_actions_roles_on_custom_action_id;
DROP INDEX IF EXISTS public.index_custom_actions_projects_on_project_id;
DROP INDEX IF EXISTS public.index_custom_actions_projects_on_custom_action_id;
DROP INDEX IF EXISTS public."index_cost_types_on_LOWER_name";
DROP INDEX IF EXISTS public.index_cost_entries_on_logged_by_id;
DROP INDEX IF EXISTS public.index_cost_entries_on_entity_type_and_entity_id;
DROP INDEX IF EXISTS public.index_cost_entries_on_entity;
DROP INDEX IF EXISTS public.index_comments_on_commented_id_and_commented_type;
DROP INDEX IF EXISTS public.index_comments_on_author_id;
DROP INDEX IF EXISTS public.index_changesets_on_user_id;
DROP INDEX IF EXISTS public.index_changesets_on_repository_id_and_committed_on;
DROP INDEX IF EXISTS public.index_changesets_on_repository_id;
DROP INDEX IF EXISTS public.index_changesets_on_committed_on;
DROP INDEX IF EXISTS public."index_categories_on_project_id_and_LOWER_name";
DROP INDEX IF EXISTS public.index_categories_on_assigned_to_id;
DROP INDEX IF EXISTS public.index_calculated_value_errors_on_customized;
DROP INDEX IF EXISTS public.index_calculated_value_errors_on_custom_field_id;
DROP INDEX IF EXISTS public.index_budgets_on_project_id_and_updated_at;
DROP INDEX IF EXISTS public.index_bcf_viewpoints_on_uuid_and_issue_id;
DROP INDEX IF EXISTS public.index_bcf_viewpoints_on_uuid;
DROP INDEX IF EXISTS public.index_bcf_viewpoints_on_issue_id;
DROP INDEX IF EXISTS public.index_bcf_issues_on_work_package_id;
DROP INDEX IF EXISTS public.index_bcf_issues_on_uuid;
DROP INDEX IF EXISTS public.index_bcf_comments_on_viewpoint_id;
DROP INDEX IF EXISTS public.index_bcf_comments_on_uuid_and_issue_id;
DROP INDEX IF EXISTS public.index_bcf_comments_on_uuid;
DROP INDEX IF EXISTS public.index_bcf_comments_on_journal_id;
DROP INDEX IF EXISTS public.index_bcf_comments_on_issue_id;
DROP INDEX IF EXISTS public.index_autologin_session_links_on_token_id;
DROP INDEX IF EXISTS public.index_autologin_session_links_on_session_id;
DROP INDEX IF EXISTS public.index_auth_providers_on_slug;
DROP INDEX IF EXISTS public.index_auth_providers_on_display_name;
DROP INDEX IF EXISTS public.index_auth_providers_on_creator_id;
DROP INDEX IF EXISTS public.index_attachments_on_fulltext_tsv;
DROP INDEX IF EXISTS public.index_attachments_on_file_tsv;
DROP INDEX IF EXISTS public.index_attachments_on_created_at;
DROP INDEX IF EXISTS public.index_attachments_on_container_id_and_container_type;
DROP INDEX IF EXISTS public.index_attachments_on_author_id;
DROP INDEX IF EXISTS public.index_attachable_journals_on_journal_id;
DROP INDEX IF EXISTS public.index_attachable_journals_on_attachment_id;
DROP INDEX IF EXISTS public.index_announcements_on_show_until_and_active;
DROP INDEX IF EXISTS public.idx_subproj_tmpl_assignments_on_project_workspace;
DROP INDEX IF EXISTS public.idx_on_user_id_auth_source_type_auth_source_id_inte_fc6941e656;
DROP INDEX IF EXISTS public.idx_on_service_type_service_id_a76ab08fa2;
DROP INDEX IF EXISTS public.idx_on_recurring_meeting_id_start_time_user_id_0ea652f142;
DROP INDEX IF EXISTS public.idx_on_auth_provider_id_group_user_id_f86563dc26;
DROP INDEX IF EXISTS public.idx_on_auth_provider_id_external_id_a8e6468bb9;
DROP INDEX IF EXISTS public.group_user_ids;
DROP INDEX IF EXISTS public.gitlab_mr_wp_mr_id;
DROP INDEX IF EXISTS public.gitlab_issues_wp_issue_id;
DROP INDEX IF EXISTS public.github_pr_wp_pr_id;
DROP INDEX IF EXISTS public.forums_project_id;
DROP INDEX IF EXISTS public.enabled_modules_project_id;
DROP INDEX IF EXISTS public.documents_project_id;
DROP INDEX IF EXISTS public.custom_values_customized;
DROP INDEX IF EXISTS public.custom_fields_types_unique;
DROP INDEX IF EXISTS public.changesets_work_packages_ids;
DROP INDEX IF EXISTS public.changesets_repos_scmid;
DROP INDEX IF EXISTS public.changesets_repos_rev;
DROP INDEX IF EXISTS public.changesets_changeset_id;
ALTER TABLE IF EXISTS ONLY public.workflows DROP CONSTRAINT IF EXISTS workflows_pkey;
ALTER TABLE IF EXISTS ONLY public.work_packages DROP CONSTRAINT IF EXISTS work_packages_pkey;
ALTER TABLE IF EXISTS ONLY public.work_package_journals DROP CONSTRAINT IF EXISTS work_package_journals_pkey;
ALTER TABLE IF EXISTS ONLY public.wikis DROP CONSTRAINT IF EXISTS wikis_pkey;
ALTER TABLE IF EXISTS ONLY public.wiki_redirects DROP CONSTRAINT IF EXISTS wiki_redirects_pkey;
ALTER TABLE IF EXISTS ONLY public.wiki_pages DROP CONSTRAINT IF EXISTS wiki_pages_pkey;
ALTER TABLE IF EXISTS ONLY public.wiki_page_journals DROP CONSTRAINT IF EXISTS wiki_page_journals_pkey;
ALTER TABLE IF EXISTS ONLY public.webhooks_webhooks DROP CONSTRAINT IF EXISTS webhooks_webhooks_pkey;
ALTER TABLE IF EXISTS ONLY public.webhooks_projects DROP CONSTRAINT IF EXISTS webhooks_projects_pkey;
ALTER TABLE IF EXISTS ONLY public.webhooks_logs DROP CONSTRAINT IF EXISTS webhooks_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.webhooks_events DROP CONSTRAINT IF EXISTS webhooks_events_pkey;
ALTER TABLE IF EXISTS ONLY public.watchers DROP CONSTRAINT IF EXISTS watchers_pkey;
ALTER TABLE IF EXISTS ONLY public.views DROP CONSTRAINT IF EXISTS views_pkey;
ALTER TABLE IF EXISTS ONLY public.versions DROP CONSTRAINT IF EXISTS versions_pkey;
ALTER TABLE IF EXISTS ONLY public.version_settings DROP CONSTRAINT IF EXISTS version_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.user_preferences DROP CONSTRAINT IF EXISTS user_preferences_pkey;
ALTER TABLE IF EXISTS ONLY public.user_passwords DROP CONSTRAINT IF EXISTS user_passwords_pkey;
ALTER TABLE IF EXISTS ONLY public.user_auth_provider_links DROP CONSTRAINT IF EXISTS user_auth_provider_links_pkey;
ALTER TABLE IF EXISTS ONLY public.scheduled_meetings DROP CONSTRAINT IF EXISTS unique_recurring_meeting_start_time;
ALTER TABLE IF EXISTS ONLY public.types DROP CONSTRAINT IF EXISTS types_pkey;
ALTER TABLE IF EXISTS ONLY public.two_factor_authentication_devices DROP CONSTRAINT IF EXISTS two_factor_authentication_devices_pkey;
ALTER TABLE IF EXISTS ONLY public.tokens DROP CONSTRAINT IF EXISTS tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.time_entry_journals DROP CONSTRAINT IF EXISTS time_entry_journals_pkey;
ALTER TABLE IF EXISTS ONLY public.time_entry_activities_projects DROP CONSTRAINT IF EXISTS time_entry_activities_projects_pkey;
ALTER TABLE IF EXISTS ONLY public.time_entries DROP CONSTRAINT IF EXISTS time_entries_pkey;
ALTER TABLE IF EXISTS ONLY public.subproject_template_assignments DROP CONSTRAINT IF EXISTS subproject_template_assignments_pkey;
ALTER TABLE IF EXISTS ONLY public.storages DROP CONSTRAINT IF EXISTS storages_pkey;
ALTER TABLE IF EXISTS ONLY public.storages_file_links_journals DROP CONSTRAINT IF EXISTS storages_file_links_journals_pkey;
ALTER TABLE IF EXISTS ONLY public.statuses DROP CONSTRAINT IF EXISTS statuses_pkey;
ALTER TABLE IF EXISTS ONLY public.settings DROP CONSTRAINT IF EXISTS settings_pkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.service_account_associations DROP CONSTRAINT IF EXISTS service_account_associations_pkey;
ALTER TABLE IF EXISTS ONLY public.scim_clients DROP CONSTRAINT IF EXISTS scim_clients_pkey;
ALTER TABLE IF EXISTS ONLY public.schema_migrations DROP CONSTRAINT IF EXISTS schema_migrations_pkey;
ALTER TABLE IF EXISTS ONLY public.scheduled_meetings DROP CONSTRAINT IF EXISTS scheduled_meetings_pkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_pkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.repositories DROP CONSTRAINT IF EXISTS repositories_pkey;
ALTER TABLE IF EXISTS ONLY public.remote_identities DROP CONSTRAINT IF EXISTS remote_identities_pkey;
ALTER TABLE IF EXISTS ONLY public.reminders DROP CONSTRAINT IF EXISTS reminders_pkey;
ALTER TABLE IF EXISTS ONLY public.reminder_notifications DROP CONSTRAINT IF EXISTS reminder_notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.relations DROP CONSTRAINT IF EXISTS relations_pkey;
ALTER TABLE IF EXISTS ONLY public.recurring_meetings DROP CONSTRAINT IF EXISTS recurring_meetings_pkey;
ALTER TABLE IF EXISTS ONLY public.recurring_meeting_interim_responses DROP CONSTRAINT IF EXISTS recurring_meeting_interim_responses_pkey;
ALTER TABLE IF EXISTS ONLY public.recaptcha_entries DROP CONSTRAINT IF EXISTS recaptcha_entries_pkey;
ALTER TABLE IF EXISTS ONLY public.rates DROP CONSTRAINT IF EXISTS rates_pkey;
ALTER TABLE IF EXISTS ONLY public.queries DROP CONSTRAINT IF EXISTS queries_pkey;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS projects_pkey;
ALTER TABLE IF EXISTS ONLY public.project_storages DROP CONSTRAINT IF EXISTS project_storages_pkey;
ALTER TABLE IF EXISTS ONLY public.project_queries DROP CONSTRAINT IF EXISTS project_queries_pkey;
ALTER TABLE IF EXISTS ONLY public.project_phases DROP CONSTRAINT IF EXISTS project_phases_pkey;
ALTER TABLE IF EXISTS ONLY public.project_phase_journals DROP CONSTRAINT IF EXISTS project_phase_journals_pkey;
ALTER TABLE IF EXISTS ONLY public.project_phase_definitions DROP CONSTRAINT IF EXISTS project_phase_definitions_pkey;
ALTER TABLE IF EXISTS ONLY public.project_journals DROP CONSTRAINT IF EXISTS project_journals_pkey;
ALTER TABLE IF EXISTS ONLY public.project_custom_field_project_mappings DROP CONSTRAINT IF EXISTS project_custom_field_project_mappings_pkey;
ALTER TABLE IF EXISTS ONLY public.paper_trail_audits DROP CONSTRAINT IF EXISTS paper_trail_audits_pkey;
ALTER TABLE IF EXISTS ONLY public.ordered_work_packages DROP CONSTRAINT IF EXISTS ordered_work_packages_pkey;
ALTER TABLE IF EXISTS ONLY public.oidc_user_tokens DROP CONSTRAINT IF EXISTS oidc_user_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.oidc_user_session_links DROP CONSTRAINT IF EXISTS oidc_user_session_links_pkey;
ALTER TABLE IF EXISTS ONLY public.oidc_group_memberships DROP CONSTRAINT IF EXISTS oidc_group_memberships_pkey;
ALTER TABLE IF EXISTS ONLY public.oidc_group_links DROP CONSTRAINT IF EXISTS oidc_group_links_pkey;
ALTER TABLE IF EXISTS ONLY public.oauth_clients DROP CONSTRAINT IF EXISTS oauth_clients_pkey;
ALTER TABLE IF EXISTS ONLY public.oauth_client_tokens DROP CONSTRAINT IF EXISTS oauth_client_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.oauth_applications DROP CONSTRAINT IF EXISTS oauth_applications_pkey;
ALTER TABLE IF EXISTS ONLY public.oauth_access_tokens DROP CONSTRAINT IF EXISTS oauth_access_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.oauth_access_grants DROP CONSTRAINT IF EXISTS oauth_access_grants_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.notification_settings DROP CONSTRAINT IF EXISTS notification_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.non_working_days DROP CONSTRAINT IF EXISTS non_working_days_pkey;
ALTER TABLE IF EXISTS ONLY public.journals DROP CONSTRAINT IF EXISTS non_overlapping_journals_validity_periods;
ALTER TABLE IF EXISTS ONLY public.news DROP CONSTRAINT IF EXISTS news_pkey;
ALTER TABLE IF EXISTS ONLY public.news_journals DROP CONSTRAINT IF EXISTS news_journals_pkey;
ALTER TABLE IF EXISTS ONLY public.messages DROP CONSTRAINT IF EXISTS messages_pkey;
ALTER TABLE IF EXISTS ONLY public.message_journals DROP CONSTRAINT IF EXISTS message_journals_pkey;
ALTER TABLE IF EXISTS ONLY public.menu_items DROP CONSTRAINT IF EXISTS menu_items_pkey;
ALTER TABLE IF EXISTS ONLY public.members DROP CONSTRAINT IF EXISTS members_pkey;
ALTER TABLE IF EXISTS ONLY public.member_roles DROP CONSTRAINT IF EXISTS member_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.meetings DROP CONSTRAINT IF EXISTS meetings_pkey;
ALTER TABLE IF EXISTS ONLY public.meeting_sections DROP CONSTRAINT IF EXISTS meeting_sections_pkey;
ALTER TABLE IF EXISTS ONLY public.meeting_participants DROP CONSTRAINT IF EXISTS meeting_participants_pkey;
ALTER TABLE IF EXISTS ONLY public.meeting_outcomes DROP CONSTRAINT IF EXISTS meeting_outcomes_pkey;
ALTER TABLE IF EXISTS ONLY public.meeting_journals DROP CONSTRAINT IF EXISTS meeting_journals_pkey;
ALTER TABLE IF EXISTS ONLY public.meeting_agenda_items DROP CONSTRAINT IF EXISTS meeting_agenda_items_pkey;
ALTER TABLE IF EXISTS ONLY public.meeting_agenda_item_journals DROP CONSTRAINT IF EXISTS meeting_agenda_item_journals_pkey;
ALTER TABLE IF EXISTS ONLY public.mcp_configurations DROP CONSTRAINT IF EXISTS mcp_configurations_pkey;
ALTER TABLE IF EXISTS ONLY public.material_budget_items DROP CONSTRAINT IF EXISTS material_budget_items_pkey;
ALTER TABLE IF EXISTS ONLY public.ldap_groups_synchronized_groups DROP CONSTRAINT IF EXISTS ldap_groups_synchronized_groups_pkey;
ALTER TABLE IF EXISTS ONLY public.ldap_groups_synchronized_filters DROP CONSTRAINT IF EXISTS ldap_groups_synchronized_filters_pkey;
ALTER TABLE IF EXISTS ONLY public.ldap_groups_memberships DROP CONSTRAINT IF EXISTS ldap_groups_memberships_pkey;
ALTER TABLE IF EXISTS ONLY public.ldap_auth_sources DROP CONSTRAINT IF EXISTS ldap_auth_sources_pkey;
ALTER TABLE IF EXISTS ONLY public.last_project_folders DROP CONSTRAINT IF EXISTS last_project_folders_pkey;
ALTER TABLE IF EXISTS ONLY public.labor_budget_items DROP CONSTRAINT IF EXISTS labor_budget_items_pkey;
ALTER TABLE IF EXISTS ONLY public.journals DROP CONSTRAINT IF EXISTS journals_pkey;
ALTER TABLE IF EXISTS ONLY public.job_statuses DROP CONSTRAINT IF EXISTS job_statuses_pkey;
ALTER TABLE IF EXISTS ONLY public.ifc_models DROP CONSTRAINT IF EXISTS ifc_models_pkey;
ALTER TABLE IF EXISTS ONLY public.ical_token_query_assignments DROP CONSTRAINT IF EXISTS ical_token_query_assignments_pkey;
ALTER TABLE IF EXISTS ONLY public.hierarchical_items DROP CONSTRAINT IF EXISTS hierarchical_items_pkey;
ALTER TABLE IF EXISTS ONLY public.group_users DROP CONSTRAINT IF EXISTS group_users_pkey;
ALTER TABLE IF EXISTS ONLY public.grids DROP CONSTRAINT IF EXISTS grids_pkey;
ALTER TABLE IF EXISTS ONLY public.grid_widgets DROP CONSTRAINT IF EXISTS grid_widgets_pkey;
ALTER TABLE IF EXISTS ONLY public.good_jobs DROP CONSTRAINT IF EXISTS good_jobs_pkey;
ALTER TABLE IF EXISTS ONLY public.good_job_settings DROP CONSTRAINT IF EXISTS good_job_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.good_job_processes DROP CONSTRAINT IF EXISTS good_job_processes_pkey;
ALTER TABLE IF EXISTS ONLY public.good_job_executions DROP CONSTRAINT IF EXISTS good_job_executions_pkey;
ALTER TABLE IF EXISTS ONLY public.good_job_batches DROP CONSTRAINT IF EXISTS good_job_batches_pkey;
ALTER TABLE IF EXISTS ONLY public.gitlab_users DROP CONSTRAINT IF EXISTS gitlab_users_pkey;
ALTER TABLE IF EXISTS ONLY public.gitlab_pipelines DROP CONSTRAINT IF EXISTS gitlab_pipelines_pkey;
ALTER TABLE IF EXISTS ONLY public.gitlab_merge_requests DROP CONSTRAINT IF EXISTS gitlab_merge_requests_pkey;
ALTER TABLE IF EXISTS ONLY public.gitlab_issues DROP CONSTRAINT IF EXISTS gitlab_issues_pkey;
ALTER TABLE IF EXISTS ONLY public.github_users DROP CONSTRAINT IF EXISTS github_users_pkey;
ALTER TABLE IF EXISTS ONLY public.github_pull_requests DROP CONSTRAINT IF EXISTS github_pull_requests_pkey;
ALTER TABLE IF EXISTS ONLY public.github_check_runs DROP CONSTRAINT IF EXISTS github_check_runs_pkey;
ALTER TABLE IF EXISTS ONLY public.forums DROP CONSTRAINT IF EXISTS forums_pkey;
ALTER TABLE IF EXISTS ONLY public.file_links DROP CONSTRAINT IF EXISTS file_links_pkey;
ALTER TABLE IF EXISTS ONLY public.favorites DROP CONSTRAINT IF EXISTS favorites_pkey;
ALTER TABLE IF EXISTS ONLY public.exports DROP CONSTRAINT IF EXISTS exports_pkey;
ALTER TABLE IF EXISTS ONLY public.export_settings DROP CONSTRAINT IF EXISTS export_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.enumerations DROP CONSTRAINT IF EXISTS enumerations_pkey;
ALTER TABLE IF EXISTS ONLY public.enterprise_tokens DROP CONSTRAINT IF EXISTS enterprise_tokens_pkey;
ALTER TABLE IF EXISTS ONLY public.enabled_modules DROP CONSTRAINT IF EXISTS enabled_modules_pkey;
ALTER TABLE IF EXISTS ONLY public.emoji_reactions DROP CONSTRAINT IF EXISTS emoji_reactions_pkey;
ALTER TABLE IF EXISTS ONLY public.documents DROP CONSTRAINT IF EXISTS documents_pkey;
ALTER TABLE IF EXISTS ONLY public.document_types DROP CONSTRAINT IF EXISTS document_types_pkey;
ALTER TABLE IF EXISTS ONLY public.document_journals DROP CONSTRAINT IF EXISTS document_journals_pkey;
ALTER TABLE IF EXISTS ONLY public.design_colors DROP CONSTRAINT IF EXISTS design_colors_pkey;
ALTER TABLE IF EXISTS ONLY public.deploy_targets DROP CONSTRAINT IF EXISTS deploy_targets_pkey;
ALTER TABLE IF EXISTS ONLY public.deploy_status_checks DROP CONSTRAINT IF EXISTS deploy_status_checks_pkey;
ALTER TABLE IF EXISTS ONLY public.customizable_journals DROP CONSTRAINT IF EXISTS customizable_journals_pkey;
ALTER TABLE IF EXISTS ONLY public.custom_values DROP CONSTRAINT IF EXISTS custom_values_pkey;
ALTER TABLE IF EXISTS ONLY public.custom_styles DROP CONSTRAINT IF EXISTS custom_styles_pkey;
ALTER TABLE IF EXISTS ONLY public.custom_options DROP CONSTRAINT IF EXISTS custom_options_pkey;
ALTER TABLE IF EXISTS ONLY public.custom_fields_roles DROP CONSTRAINT IF EXISTS custom_fields_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.custom_fields_projects DROP CONSTRAINT IF EXISTS custom_fields_projects_pkey;
ALTER TABLE IF EXISTS ONLY public.custom_fields DROP CONSTRAINT IF EXISTS custom_fields_pkey;
ALTER TABLE IF EXISTS ONLY public.custom_field_sections DROP CONSTRAINT IF EXISTS custom_field_sections_pkey;
ALTER TABLE IF EXISTS ONLY public.custom_actions_types DROP CONSTRAINT IF EXISTS custom_actions_types_pkey;
ALTER TABLE IF EXISTS ONLY public.custom_actions_statuses DROP CONSTRAINT IF EXISTS custom_actions_statuses_pkey;
ALTER TABLE IF EXISTS ONLY public.custom_actions_roles DROP CONSTRAINT IF EXISTS custom_actions_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.custom_actions_projects DROP CONSTRAINT IF EXISTS custom_actions_projects_pkey;
ALTER TABLE IF EXISTS ONLY public.custom_actions DROP CONSTRAINT IF EXISTS custom_actions_pkey;
ALTER TABLE IF EXISTS ONLY public.cost_types DROP CONSTRAINT IF EXISTS cost_types_pkey;
ALTER TABLE IF EXISTS ONLY public.cost_queries DROP CONSTRAINT IF EXISTS cost_queries_pkey;
ALTER TABLE IF EXISTS ONLY public.cost_entries DROP CONSTRAINT IF EXISTS cost_entries_pkey;
ALTER TABLE IF EXISTS ONLY public.comments DROP CONSTRAINT IF EXISTS comments_pkey;
ALTER TABLE IF EXISTS ONLY public.colors DROP CONSTRAINT IF EXISTS colors_pkey;
ALTER TABLE IF EXISTS ONLY public.changesets DROP CONSTRAINT IF EXISTS changesets_pkey;
ALTER TABLE IF EXISTS ONLY public.changeset_journals DROP CONSTRAINT IF EXISTS changeset_journals_pkey;
ALTER TABLE IF EXISTS ONLY public.changes DROP CONSTRAINT IF EXISTS changes_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public.calculated_value_errors DROP CONSTRAINT IF EXISTS calculated_value_errors_pkey;
ALTER TABLE IF EXISTS ONLY public.budgets DROP CONSTRAINT IF EXISTS budgets_pkey;
ALTER TABLE IF EXISTS ONLY public.budget_journals DROP CONSTRAINT IF EXISTS budget_journals_pkey;
ALTER TABLE IF EXISTS ONLY public.bcf_viewpoints DROP CONSTRAINT IF EXISTS bcf_viewpoints_pkey;
ALTER TABLE IF EXISTS ONLY public.bcf_issues DROP CONSTRAINT IF EXISTS bcf_issues_pkey;
ALTER TABLE IF EXISTS ONLY public.bcf_comments DROP CONSTRAINT IF EXISTS bcf_comments_pkey;
ALTER TABLE IF EXISTS ONLY public.autologin_session_links DROP CONSTRAINT IF EXISTS autologin_session_links_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_providers DROP CONSTRAINT IF EXISTS auth_providers_pkey;
ALTER TABLE IF EXISTS ONLY public.attribute_help_texts DROP CONSTRAINT IF EXISTS attribute_help_texts_pkey;
ALTER TABLE IF EXISTS ONLY public.attachments DROP CONSTRAINT IF EXISTS attachments_pkey;
ALTER TABLE IF EXISTS ONLY public.attachment_journals DROP CONSTRAINT IF EXISTS attachment_journals_pkey;
ALTER TABLE IF EXISTS ONLY public.attachable_journals DROP CONSTRAINT IF EXISTS attachable_journals_pkey;
ALTER TABLE IF EXISTS ONLY public.ar_internal_metadata DROP CONSTRAINT IF EXISTS ar_internal_metadata_pkey;
ALTER TABLE IF EXISTS ONLY public.announcements DROP CONSTRAINT IF EXISTS announcements_pkey;
ALTER TABLE IF EXISTS public.workflows ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.work_packages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.work_package_journals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.wikis ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.wiki_redirects ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.wiki_pages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.wiki_page_journals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.webhooks_webhooks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.webhooks_projects ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.webhooks_logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.webhooks_events ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.watchers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.views ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.versions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.version_settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_preferences ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_passwords ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.user_auth_provider_links ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.types ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.two_factor_authentication_devices ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.tokens ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.time_entry_journals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.time_entry_activities_projects ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.time_entries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.subproject_template_assignments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.storages_file_links_journals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.storages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.statuses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.sessions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.service_account_associations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.scim_clients ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.scheduled_meetings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.role_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.repositories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.remote_identities ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.reminders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.reminder_notifications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.relations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.recurring_meetings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.recurring_meeting_interim_responses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.recaptcha_entries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.rates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.queries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.projects ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.project_storages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.project_queries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.project_phases ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.project_phase_journals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.project_phase_definitions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.project_journals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.project_custom_field_project_mappings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.paper_trail_audits ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ordered_work_packages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.oidc_user_tokens ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.oidc_user_session_links ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.oidc_group_memberships ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.oidc_group_links ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.oauth_clients ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.oauth_client_tokens ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.oauth_applications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.oauth_access_tokens ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.oauth_access_grants ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notifications ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.notification_settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.non_working_days ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.news_journals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.news ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.messages ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.message_journals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.menu_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.members ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.member_roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.meetings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.meeting_sections ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.meeting_participants ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.meeting_outcomes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.meeting_journals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.meeting_agenda_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.meeting_agenda_item_journals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.mcp_configurations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.material_budget_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ldap_groups_synchronized_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ldap_groups_synchronized_filters ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ldap_groups_memberships ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ldap_auth_sources ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.last_project_folders ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.labor_budget_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.journals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.job_statuses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ifc_models ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ical_token_query_assignments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.hierarchical_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.group_users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.grids ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.grid_widgets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.gitlab_users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.gitlab_pipelines ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.gitlab_merge_requests ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.gitlab_issues ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.github_users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.github_pull_requests ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.github_check_runs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.forums ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.file_links ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.favorites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.exports ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.export_settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.enumerations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.enterprise_tokens ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.enabled_modules ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.emoji_reactions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.documents ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.document_types ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.document_journals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.design_colors ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.deploy_targets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.deploy_status_checks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.customizable_journals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.custom_values ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.custom_styles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.custom_options ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.custom_fields_roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.custom_fields_projects ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.custom_fields ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.custom_field_sections ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.custom_actions_types ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.custom_actions_statuses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.custom_actions_roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.custom_actions_projects ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.custom_actions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cost_types ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cost_queries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cost_entries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.comments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.colors ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.changesets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.changeset_journals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.changes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.calculated_value_errors ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.budgets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.budget_journals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.bcf_viewpoints ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.bcf_issues ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.bcf_comments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.autologin_session_links ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.auth_providers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.attribute_help_texts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.attachments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.attachment_journals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.attachable_journals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.announcements ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.workflows_id_seq;
DROP TABLE IF EXISTS public.workflows;
DROP SEQUENCE IF EXISTS public.work_packages_id_seq;
DROP TABLE IF EXISTS public.work_packages;
DROP SEQUENCE IF EXISTS public.work_package_journals_id_seq;
DROP TABLE IF EXISTS public.work_package_journals;
DROP TABLE IF EXISTS public.work_package_hierarchies;
DROP SEQUENCE IF EXISTS public.wikis_id_seq;
DROP TABLE IF EXISTS public.wikis;
DROP SEQUENCE IF EXISTS public.wiki_redirects_id_seq;
DROP TABLE IF EXISTS public.wiki_redirects;
DROP SEQUENCE IF EXISTS public.wiki_pages_id_seq;
DROP TABLE IF EXISTS public.wiki_pages;
DROP SEQUENCE IF EXISTS public.wiki_page_journals_id_seq;
DROP TABLE IF EXISTS public.wiki_page_journals;
DROP SEQUENCE IF EXISTS public.webhooks_webhooks_id_seq;
DROP TABLE IF EXISTS public.webhooks_webhooks;
DROP SEQUENCE IF EXISTS public.webhooks_projects_id_seq;
DROP TABLE IF EXISTS public.webhooks_projects;
DROP SEQUENCE IF EXISTS public.webhooks_logs_id_seq;
DROP TABLE IF EXISTS public.webhooks_logs;
DROP SEQUENCE IF EXISTS public.webhooks_events_id_seq;
DROP TABLE IF EXISTS public.webhooks_events;
DROP SEQUENCE IF EXISTS public.watchers_id_seq;
DROP TABLE IF EXISTS public.watchers;
DROP SEQUENCE IF EXISTS public.views_id_seq;
DROP TABLE IF EXISTS public.views;
DROP SEQUENCE IF EXISTS public.versions_id_seq;
DROP TABLE IF EXISTS public.versions;
DROP SEQUENCE IF EXISTS public.version_settings_id_seq;
DROP TABLE IF EXISTS public.version_settings;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.user_preferences_id_seq;
DROP TABLE IF EXISTS public.user_preferences;
DROP SEQUENCE IF EXISTS public.user_passwords_id_seq;
DROP TABLE IF EXISTS public.user_passwords;
DROP SEQUENCE IF EXISTS public.user_auth_provider_links_id_seq;
DROP TABLE IF EXISTS public.user_auth_provider_links;
DROP SEQUENCE IF EXISTS public.types_id_seq;
DROP TABLE IF EXISTS public.types;
DROP SEQUENCE IF EXISTS public.two_factor_authentication_devices_id_seq;
DROP TABLE IF EXISTS public.two_factor_authentication_devices;
DROP SEQUENCE IF EXISTS public.tokens_id_seq;
DROP TABLE IF EXISTS public.tokens;
DROP SEQUENCE IF EXISTS public.time_entry_journals_id_seq;
DROP TABLE IF EXISTS public.time_entry_journals;
DROP SEQUENCE IF EXISTS public.time_entry_activities_projects_id_seq;
DROP TABLE IF EXISTS public.time_entry_activities_projects;
DROP SEQUENCE IF EXISTS public.time_entries_id_seq;
DROP TABLE IF EXISTS public.time_entries;
DROP SEQUENCE IF EXISTS public.subproject_template_assignments_id_seq;
DROP TABLE IF EXISTS public.subproject_template_assignments;
DROP SEQUENCE IF EXISTS public.storages_id_seq;
DROP SEQUENCE IF EXISTS public.storages_file_links_journals_id_seq;
DROP TABLE IF EXISTS public.storages_file_links_journals;
DROP TABLE IF EXISTS public.storages;
DROP SEQUENCE IF EXISTS public.statuses_id_seq;
DROP TABLE IF EXISTS public.statuses;
DROP SEQUENCE IF EXISTS public.settings_id_seq;
DROP TABLE IF EXISTS public.settings;
DROP SEQUENCE IF EXISTS public.sessions_id_seq;
DROP TABLE IF EXISTS public.sessions;
DROP SEQUENCE IF EXISTS public.service_account_associations_id_seq;
DROP TABLE IF EXISTS public.service_account_associations;
DROP SEQUENCE IF EXISTS public.scim_clients_id_seq;
DROP TABLE IF EXISTS public.scim_clients;
DROP TABLE IF EXISTS public.schema_migrations;
DROP SEQUENCE IF EXISTS public.scheduled_meetings_id_seq;
DROP TABLE IF EXISTS public.scheduled_meetings;
DROP SEQUENCE IF EXISTS public.roles_id_seq;
DROP TABLE IF EXISTS public.roles;
DROP SEQUENCE IF EXISTS public.role_permissions_id_seq;
DROP TABLE IF EXISTS public.role_permissions;
DROP SEQUENCE IF EXISTS public.repositories_id_seq;
DROP TABLE IF EXISTS public.repositories;
DROP SEQUENCE IF EXISTS public.remote_identities_id_seq;
DROP TABLE IF EXISTS public.remote_identities;
DROP SEQUENCE IF EXISTS public.reminders_id_seq;
DROP TABLE IF EXISTS public.reminders;
DROP SEQUENCE IF EXISTS public.reminder_notifications_id_seq;
DROP TABLE IF EXISTS public.reminder_notifications;
DROP SEQUENCE IF EXISTS public.relations_id_seq;
DROP TABLE IF EXISTS public.relations;
DROP SEQUENCE IF EXISTS public.recurring_meetings_id_seq;
DROP TABLE IF EXISTS public.recurring_meetings;
DROP SEQUENCE IF EXISTS public.recurring_meeting_interim_responses_id_seq;
DROP TABLE IF EXISTS public.recurring_meeting_interim_responses;
DROP SEQUENCE IF EXISTS public.recaptcha_entries_id_seq;
DROP TABLE IF EXISTS public.recaptcha_entries;
DROP SEQUENCE IF EXISTS public.rates_id_seq;
DROP TABLE IF EXISTS public.rates;
DROP SEQUENCE IF EXISTS public.queries_id_seq;
DROP TABLE IF EXISTS public.queries;
DROP TABLE IF EXISTS public.projects_types;
DROP SEQUENCE IF EXISTS public.projects_id_seq;
DROP TABLE IF EXISTS public.projects;
DROP SEQUENCE IF EXISTS public.project_storages_id_seq;
DROP TABLE IF EXISTS public.project_storages;
DROP SEQUENCE IF EXISTS public.project_queries_id_seq;
DROP TABLE IF EXISTS public.project_queries;
DROP SEQUENCE IF EXISTS public.project_phases_id_seq;
DROP TABLE IF EXISTS public.project_phases;
DROP SEQUENCE IF EXISTS public.project_phase_journals_id_seq;
DROP TABLE IF EXISTS public.project_phase_journals;
DROP SEQUENCE IF EXISTS public.project_phase_definitions_id_seq;
DROP TABLE IF EXISTS public.project_phase_definitions;
DROP SEQUENCE IF EXISTS public.project_journals_id_seq;
DROP TABLE IF EXISTS public.project_journals;
DROP SEQUENCE IF EXISTS public.project_custom_field_project_mappings_id_seq;
DROP TABLE IF EXISTS public.project_custom_field_project_mappings;
DROP SEQUENCE IF EXISTS public.paper_trail_audits_id_seq;
DROP TABLE IF EXISTS public.paper_trail_audits;
DROP SEQUENCE IF EXISTS public.ordered_work_packages_id_seq;
DROP TABLE IF EXISTS public.ordered_work_packages;
DROP SEQUENCE IF EXISTS public.oidc_user_tokens_id_seq;
DROP TABLE IF EXISTS public.oidc_user_tokens;
DROP SEQUENCE IF EXISTS public.oidc_user_session_links_id_seq;
DROP TABLE IF EXISTS public.oidc_user_session_links;
DROP SEQUENCE IF EXISTS public.oidc_group_memberships_id_seq;
DROP TABLE IF EXISTS public.oidc_group_memberships;
DROP SEQUENCE IF EXISTS public.oidc_group_links_id_seq;
DROP TABLE IF EXISTS public.oidc_group_links;
DROP SEQUENCE IF EXISTS public.oauth_clients_id_seq;
DROP TABLE IF EXISTS public.oauth_clients;
DROP SEQUENCE IF EXISTS public.oauth_client_tokens_id_seq;
DROP TABLE IF EXISTS public.oauth_client_tokens;
DROP SEQUENCE IF EXISTS public.oauth_applications_id_seq;
DROP TABLE IF EXISTS public.oauth_applications;
DROP SEQUENCE IF EXISTS public.oauth_access_tokens_id_seq;
DROP TABLE IF EXISTS public.oauth_access_tokens;
DROP SEQUENCE IF EXISTS public.oauth_access_grants_id_seq;
DROP TABLE IF EXISTS public.oauth_access_grants;
DROP SEQUENCE IF EXISTS public.notifications_id_seq;
DROP TABLE IF EXISTS public.notifications;
DROP SEQUENCE IF EXISTS public.notification_settings_id_seq;
DROP TABLE IF EXISTS public.notification_settings;
DROP SEQUENCE IF EXISTS public.non_working_days_id_seq;
DROP TABLE IF EXISTS public.non_working_days;
DROP SEQUENCE IF EXISTS public.news_journals_id_seq;
DROP TABLE IF EXISTS public.news_journals;
DROP SEQUENCE IF EXISTS public.news_id_seq;
DROP TABLE IF EXISTS public.news;
DROP SEQUENCE IF EXISTS public.messages_id_seq;
DROP TABLE IF EXISTS public.messages;
DROP SEQUENCE IF EXISTS public.message_journals_id_seq;
DROP TABLE IF EXISTS public.message_journals;
DROP SEQUENCE IF EXISTS public.menu_items_id_seq;
DROP TABLE IF EXISTS public.menu_items;
DROP SEQUENCE IF EXISTS public.members_id_seq;
DROP TABLE IF EXISTS public.members;
DROP SEQUENCE IF EXISTS public.member_roles_id_seq;
DROP TABLE IF EXISTS public.member_roles;
DROP SEQUENCE IF EXISTS public.meetings_id_seq;
DROP TABLE IF EXISTS public.meetings;
DROP SEQUENCE IF EXISTS public.meeting_sections_id_seq;
DROP TABLE IF EXISTS public.meeting_sections;
DROP SEQUENCE IF EXISTS public.meeting_participants_id_seq;
DROP TABLE IF EXISTS public.meeting_participants;
DROP SEQUENCE IF EXISTS public.meeting_outcomes_id_seq;
DROP TABLE IF EXISTS public.meeting_outcomes;
DROP SEQUENCE IF EXISTS public.meeting_journals_id_seq;
DROP TABLE IF EXISTS public.meeting_journals;
DROP SEQUENCE IF EXISTS public.meeting_agenda_items_id_seq;
DROP TABLE IF EXISTS public.meeting_agenda_items;
DROP SEQUENCE IF EXISTS public.meeting_agenda_item_journals_id_seq;
DROP TABLE IF EXISTS public.meeting_agenda_item_journals;
DROP SEQUENCE IF EXISTS public.mcp_configurations_id_seq;
DROP TABLE IF EXISTS public.mcp_configurations;
DROP SEQUENCE IF EXISTS public.material_budget_items_id_seq;
DROP TABLE IF EXISTS public.material_budget_items;
DROP SEQUENCE IF EXISTS public.ldap_groups_synchronized_groups_id_seq;
DROP TABLE IF EXISTS public.ldap_groups_synchronized_groups;
DROP SEQUENCE IF EXISTS public.ldap_groups_synchronized_filters_id_seq;
DROP TABLE IF EXISTS public.ldap_groups_synchronized_filters;
DROP SEQUENCE IF EXISTS public.ldap_groups_memberships_id_seq;
DROP TABLE IF EXISTS public.ldap_groups_memberships;
DROP SEQUENCE IF EXISTS public.ldap_auth_sources_id_seq;
DROP TABLE IF EXISTS public.ldap_auth_sources;
DROP SEQUENCE IF EXISTS public.last_project_folders_id_seq;
DROP TABLE IF EXISTS public.last_project_folders;
DROP SEQUENCE IF EXISTS public.labor_budget_items_id_seq;
DROP TABLE IF EXISTS public.labor_budget_items;
DROP SEQUENCE IF EXISTS public.journals_id_seq;
DROP TABLE IF EXISTS public.journals;
DROP SEQUENCE IF EXISTS public.job_statuses_id_seq;
DROP TABLE IF EXISTS public.job_statuses;
DROP SEQUENCE IF EXISTS public.ifc_models_id_seq;
DROP TABLE IF EXISTS public.ifc_models;
DROP SEQUENCE IF EXISTS public.ical_token_query_assignments_id_seq;
DROP TABLE IF EXISTS public.ical_token_query_assignments;
DROP SEQUENCE IF EXISTS public.hierarchical_items_id_seq;
DROP TABLE IF EXISTS public.hierarchical_items;
DROP TABLE IF EXISTS public.hierarchical_item_hierarchies;
DROP SEQUENCE IF EXISTS public.group_users_id_seq;
DROP TABLE IF EXISTS public.group_users;
DROP SEQUENCE IF EXISTS public.grids_id_seq;
DROP TABLE IF EXISTS public.grids;
DROP SEQUENCE IF EXISTS public.grid_widgets_id_seq;
DROP TABLE IF EXISTS public.grid_widgets;
DROP TABLE IF EXISTS public.good_jobs;
DROP TABLE IF EXISTS public.good_job_settings;
DROP TABLE IF EXISTS public.good_job_processes;
DROP TABLE IF EXISTS public.good_job_executions;
DROP TABLE IF EXISTS public.good_job_batches;
DROP SEQUENCE IF EXISTS public.gitlab_users_id_seq;
DROP TABLE IF EXISTS public.gitlab_users;
DROP SEQUENCE IF EXISTS public.gitlab_pipelines_id_seq;
DROP TABLE IF EXISTS public.gitlab_pipelines;
DROP TABLE IF EXISTS public.gitlab_merge_requests_work_packages;
DROP SEQUENCE IF EXISTS public.gitlab_merge_requests_id_seq;
DROP TABLE IF EXISTS public.gitlab_merge_requests;
DROP TABLE IF EXISTS public.gitlab_issues_work_packages;
DROP SEQUENCE IF EXISTS public.gitlab_issues_id_seq;
DROP TABLE IF EXISTS public.gitlab_issues;
DROP SEQUENCE IF EXISTS public.github_users_id_seq;
DROP TABLE IF EXISTS public.github_users;
DROP TABLE IF EXISTS public.github_pull_requests_work_packages;
DROP SEQUENCE IF EXISTS public.github_pull_requests_id_seq;
DROP TABLE IF EXISTS public.github_pull_requests;
DROP SEQUENCE IF EXISTS public.github_check_runs_id_seq;
DROP TABLE IF EXISTS public.github_check_runs;
DROP SEQUENCE IF EXISTS public.forums_id_seq;
DROP TABLE IF EXISTS public.forums;
DROP SEQUENCE IF EXISTS public.file_links_id_seq;
DROP TABLE IF EXISTS public.file_links;
DROP SEQUENCE IF EXISTS public.favorites_id_seq;
DROP TABLE IF EXISTS public.favorites;
DROP SEQUENCE IF EXISTS public.exports_id_seq;
DROP TABLE IF EXISTS public.exports;
DROP SEQUENCE IF EXISTS public.export_settings_id_seq;
DROP TABLE IF EXISTS public.export_settings;
DROP SEQUENCE IF EXISTS public.enumerations_id_seq;
DROP TABLE IF EXISTS public.enumerations;
DROP SEQUENCE IF EXISTS public.enterprise_tokens_id_seq;
DROP TABLE IF EXISTS public.enterprise_tokens;
DROP SEQUENCE IF EXISTS public.enabled_modules_id_seq;
DROP TABLE IF EXISTS public.enabled_modules;
DROP SEQUENCE IF EXISTS public.emoji_reactions_id_seq;
DROP TABLE IF EXISTS public.emoji_reactions;
DROP TABLE IF EXISTS public.done_statuses_for_project;
DROP SEQUENCE IF EXISTS public.documents_id_seq;
DROP TABLE IF EXISTS public.documents;
DROP SEQUENCE IF EXISTS public.document_types_id_seq;
DROP TABLE IF EXISTS public.document_types;
DROP SEQUENCE IF EXISTS public.document_journals_id_seq;
DROP TABLE IF EXISTS public.document_journals;
DROP SEQUENCE IF EXISTS public.design_colors_id_seq;
DROP TABLE IF EXISTS public.design_colors;
DROP SEQUENCE IF EXISTS public.deploy_targets_id_seq;
DROP TABLE IF EXISTS public.deploy_targets;
DROP SEQUENCE IF EXISTS public.deploy_status_checks_id_seq;
DROP TABLE IF EXISTS public.deploy_status_checks;
DROP SEQUENCE IF EXISTS public.customizable_journals_id_seq;
DROP TABLE IF EXISTS public.customizable_journals;
DROP SEQUENCE IF EXISTS public.custom_values_id_seq;
DROP TABLE IF EXISTS public.custom_values;
DROP SEQUENCE IF EXISTS public.custom_styles_id_seq;
DROP TABLE IF EXISTS public.custom_styles;
DROP SEQUENCE IF EXISTS public.custom_options_id_seq;
DROP TABLE IF EXISTS public.custom_options;
DROP TABLE IF EXISTS public.custom_fields_types;
DROP SEQUENCE IF EXISTS public.custom_fields_roles_id_seq;
DROP TABLE IF EXISTS public.custom_fields_roles;
DROP SEQUENCE IF EXISTS public.custom_fields_projects_id_seq;
DROP TABLE IF EXISTS public.custom_fields_projects;
DROP SEQUENCE IF EXISTS public.custom_fields_id_seq;
DROP TABLE IF EXISTS public.custom_fields;
DROP SEQUENCE IF EXISTS public.custom_field_sections_id_seq;
DROP TABLE IF EXISTS public.custom_field_sections;
DROP SEQUENCE IF EXISTS public.custom_actions_types_id_seq;
DROP TABLE IF EXISTS public.custom_actions_types;
DROP SEQUENCE IF EXISTS public.custom_actions_statuses_id_seq;
DROP TABLE IF EXISTS public.custom_actions_statuses;
DROP SEQUENCE IF EXISTS public.custom_actions_roles_id_seq;
DROP TABLE IF EXISTS public.custom_actions_roles;
DROP SEQUENCE IF EXISTS public.custom_actions_projects_id_seq;
DROP TABLE IF EXISTS public.custom_actions_projects;
DROP SEQUENCE IF EXISTS public.custom_actions_id_seq;
DROP TABLE IF EXISTS public.custom_actions;
DROP SEQUENCE IF EXISTS public.cost_types_id_seq;
DROP TABLE IF EXISTS public.cost_types;
DROP SEQUENCE IF EXISTS public.cost_queries_id_seq;
DROP TABLE IF EXISTS public.cost_queries;
DROP SEQUENCE IF EXISTS public.cost_entries_id_seq;
DROP TABLE IF EXISTS public.cost_entries;
DROP SEQUENCE IF EXISTS public.comments_id_seq;
DROP TABLE IF EXISTS public.comments;
DROP SEQUENCE IF EXISTS public.colors_id_seq;
DROP TABLE IF EXISTS public.colors;
DROP TABLE IF EXISTS public.changesets_work_packages;
DROP SEQUENCE IF EXISTS public.changesets_id_seq;
DROP TABLE IF EXISTS public.changesets;
DROP SEQUENCE IF EXISTS public.changeset_journals_id_seq;
DROP TABLE IF EXISTS public.changeset_journals;
DROP SEQUENCE IF EXISTS public.changes_id_seq;
DROP TABLE IF EXISTS public.changes;
DROP SEQUENCE IF EXISTS public.categories_id_seq;
DROP TABLE IF EXISTS public.categories;
DROP SEQUENCE IF EXISTS public.calculated_value_errors_id_seq;
DROP TABLE IF EXISTS public.calculated_value_errors;
DROP SEQUENCE IF EXISTS public.budgets_id_seq;
DROP TABLE IF EXISTS public.budgets;
DROP SEQUENCE IF EXISTS public.budget_journals_id_seq;
DROP TABLE IF EXISTS public.budget_journals;
DROP SEQUENCE IF EXISTS public.bcf_viewpoints_id_seq;
DROP TABLE IF EXISTS public.bcf_viewpoints;
DROP SEQUENCE IF EXISTS public.bcf_issues_id_seq;
DROP TABLE IF EXISTS public.bcf_issues;
DROP SEQUENCE IF EXISTS public.bcf_comments_id_seq;
DROP TABLE IF EXISTS public.bcf_comments;
DROP SEQUENCE IF EXISTS public.autologin_session_links_id_seq;
DROP TABLE IF EXISTS public.autologin_session_links;
DROP SEQUENCE IF EXISTS public.auth_providers_id_seq;
DROP TABLE IF EXISTS public.auth_providers;
DROP SEQUENCE IF EXISTS public.attribute_help_texts_id_seq;
DROP TABLE IF EXISTS public.attribute_help_texts;
DROP SEQUENCE IF EXISTS public.attachments_id_seq;
DROP TABLE IF EXISTS public.attachments;
DROP SEQUENCE IF EXISTS public.attachment_journals_id_seq;
DROP TABLE IF EXISTS public.attachment_journals;
DROP SEQUENCE IF EXISTS public.attachable_journals_id_seq;
DROP TABLE IF EXISTS public.attachable_journals;
DROP TABLE IF EXISTS public.ar_internal_metadata;
DROP SEQUENCE IF EXISTS public.announcements_id_seq;
DROP TABLE IF EXISTS public.announcements;
DROP EXTENSION IF EXISTS unaccent;
DROP EXTENSION IF EXISTS pg_trgm;
DROP EXTENSION IF EXISTS btree_gist;
DROP COLLATION IF EXISTS public.versions_name;
--
-- Name: versions_name; Type: COLLATION; Schema: public; Owner: -
--

CREATE COLLATION public.versions_name (provider = icu, locale = 'und-u-kn');


--
-- Name: btree_gist; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION btree_gist; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION btree_gist IS 'support for indexing common datatypes in GiST';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: announcements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.announcements (
    id bigint NOT NULL,
    text text,
    show_until date,
    active boolean DEFAULT false,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: announcements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.announcements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: announcements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.announcements_id_seq OWNED BY public.announcements.id;


--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: attachable_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachable_journals (
    id bigint NOT NULL,
    journal_id bigint NOT NULL,
    attachment_id bigint NOT NULL,
    filename character varying NOT NULL
);


--
-- Name: attachable_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attachable_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attachable_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attachable_journals_id_seq OWNED BY public.attachable_journals.id;


--
-- Name: attachment_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachment_journals (
    id bigint NOT NULL,
    container_id bigint,
    container_type character varying(30),
    filename character varying NOT NULL,
    disk_filename character varying NOT NULL,
    filesize bigint NOT NULL,
    content_type character varying,
    digest character varying(40) NOT NULL,
    downloads integer NOT NULL,
    author_id bigint NOT NULL,
    description text
);


--
-- Name: attachment_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attachment_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attachment_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attachment_journals_id_seq OWNED BY public.attachment_journals.id;


--
-- Name: attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachments (
    id bigint NOT NULL,
    container_id bigint,
    container_type character varying(30),
    filename character varying DEFAULT ''::character varying NOT NULL,
    disk_filename character varying DEFAULT ''::character varying NOT NULL,
    filesize bigint DEFAULT 0 NOT NULL,
    content_type character varying DEFAULT ''::character varying,
    digest character varying(40) DEFAULT ''::character varying NOT NULL,
    downloads integer DEFAULT 0 NOT NULL,
    author_id bigint NOT NULL,
    created_at timestamp with time zone,
    description character varying,
    file character varying,
    fulltext text,
    fulltext_tsv tsvector,
    file_tsv tsvector,
    updated_at timestamp with time zone,
    status integer DEFAULT 0 NOT NULL
);


--
-- Name: attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attachments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attachments_id_seq OWNED BY public.attachments.id;


--
-- Name: attribute_help_texts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attribute_help_texts (
    id bigint NOT NULL,
    help_text text NOT NULL,
    type character varying NOT NULL,
    attribute_name character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    caption text
);


--
-- Name: attribute_help_texts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.attribute_help_texts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attribute_help_texts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.attribute_help_texts_id_seq OWNED BY public.attribute_help_texts.id;


--
-- Name: auth_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_providers (
    id bigint NOT NULL,
    type character varying NOT NULL,
    display_name character varying NOT NULL,
    slug character varying NOT NULL,
    available boolean DEFAULT true NOT NULL,
    limit_self_registration boolean DEFAULT false NOT NULL,
    options jsonb DEFAULT '{}'::jsonb NOT NULL,
    creator_id bigint NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: auth_providers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.auth_providers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: auth_providers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.auth_providers_id_seq OWNED BY public.auth_providers.id;


--
-- Name: autologin_session_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.autologin_session_links (
    id bigint NOT NULL,
    token_id bigint NOT NULL,
    session_id bigint NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: autologin_session_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.autologin_session_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: autologin_session_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.autologin_session_links_id_seq OWNED BY public.autologin_session_links.id;


--
-- Name: bcf_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bcf_comments (
    id bigint NOT NULL,
    uuid text,
    journal_id bigint,
    issue_id bigint,
    viewpoint_id bigint,
    reply_to bigint
);


--
-- Name: bcf_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bcf_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bcf_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bcf_comments_id_seq OWNED BY public.bcf_comments.id;


--
-- Name: bcf_issues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bcf_issues (
    id bigint NOT NULL,
    uuid text,
    markup xml,
    work_package_id bigint,
    stage character varying,
    index integer,
    labels text[] DEFAULT '{}'::text[],
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: bcf_issues_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bcf_issues_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bcf_issues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bcf_issues_id_seq OWNED BY public.bcf_issues.id;


--
-- Name: bcf_viewpoints; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bcf_viewpoints (
    id bigint NOT NULL,
    uuid text,
    viewpoint_name text,
    issue_id bigint,
    json_viewpoint jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: bcf_viewpoints_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bcf_viewpoints_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bcf_viewpoints_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bcf_viewpoints_id_seq OWNED BY public.bcf_viewpoints.id;


--
-- Name: budget_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budget_journals (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    author_id bigint NOT NULL,
    subject character varying NOT NULL,
    description text,
    fixed_date date NOT NULL,
    base_amount numeric(20,2) DEFAULT 0.0 NOT NULL
);


--
-- Name: budget_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.budget_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: budget_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.budget_journals_id_seq OWNED BY public.budget_journals.id;


--
-- Name: budgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.budgets (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    author_id bigint NOT NULL,
    subject character varying NOT NULL,
    description text NOT NULL,
    fixed_date date NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    base_amount numeric(20,2) DEFAULT 0.0 NOT NULL
);


--
-- Name: budgets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.budgets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: budgets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.budgets_id_seq OWNED BY public.budgets.id;


--
-- Name: calculated_value_errors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calculated_value_errors (
    id bigint NOT NULL,
    customized_type character varying NOT NULL,
    customized_id bigint NOT NULL,
    custom_field_id bigint,
    error_code character varying NOT NULL,
    missing_custom_field_ids integer[] DEFAULT '{}'::integer[] NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: calculated_value_errors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.calculated_value_errors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: calculated_value_errors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.calculated_value_errors_id_seq OWNED BY public.calculated_value_errors.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.categories (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    assigned_to_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: changes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.changes (
    id bigint NOT NULL,
    changeset_id bigint NOT NULL,
    action character varying(1) DEFAULT ''::character varying NOT NULL,
    path text NOT NULL,
    from_path text,
    from_revision character varying,
    revision character varying,
    branch character varying
);


--
-- Name: changes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.changes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: changes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.changes_id_seq OWNED BY public.changes.id;


--
-- Name: changeset_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.changeset_journals (
    id bigint NOT NULL,
    repository_id bigint NOT NULL,
    revision character varying NOT NULL,
    committer character varying,
    committed_on timestamp with time zone NOT NULL,
    comments text,
    commit_date date,
    scmid character varying,
    user_id bigint
);


--
-- Name: changeset_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.changeset_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: changeset_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.changeset_journals_id_seq OWNED BY public.changeset_journals.id;


--
-- Name: changesets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.changesets (
    id bigint NOT NULL,
    repository_id bigint NOT NULL,
    revision character varying NOT NULL,
    committer character varying,
    committed_on timestamp with time zone NOT NULL,
    comments text,
    commit_date date,
    scmid character varying,
    user_id bigint
);


--
-- Name: changesets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.changesets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: changesets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.changesets_id_seq OWNED BY public.changesets.id;


--
-- Name: changesets_work_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.changesets_work_packages (
    changeset_id bigint NOT NULL,
    work_package_id bigint NOT NULL
);


--
-- Name: colors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.colors (
    id bigint NOT NULL,
    name character varying NOT NULL,
    hexcode character varying NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: colors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.colors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: colors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.colors_id_seq OWNED BY public.colors.id;


--
-- Name: comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comments (
    id bigint NOT NULL,
    commented_type character varying(30) DEFAULT ''::character varying NOT NULL,
    commented_id bigint NOT NULL,
    author_id bigint NOT NULL,
    comments text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: comments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.comments_id_seq OWNED BY public.comments.id;


--
-- Name: cost_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_entries (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    project_id bigint NOT NULL,
    work_package_id bigint,
    cost_type_id bigint NOT NULL,
    units double precision NOT NULL,
    spent_on date NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    comments character varying NOT NULL,
    blocked boolean DEFAULT false NOT NULL,
    overridden_costs numeric(15,4),
    costs numeric(15,4),
    rate_id bigint,
    tyear integer NOT NULL,
    tmonth integer NOT NULL,
    tweek integer NOT NULL,
    logged_by_id bigint,
    entity_type character varying,
    entity_id bigint
);


--
-- Name: cost_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cost_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cost_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cost_entries_id_seq OWNED BY public.cost_entries.id;


--
-- Name: cost_queries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_queries (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    project_id bigint,
    name character varying NOT NULL,
    is_public boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    serialized character varying(2000) NOT NULL
);


--
-- Name: cost_queries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cost_queries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cost_queries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cost_queries_id_seq OWNED BY public.cost_queries.id;


--
-- Name: cost_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_types (
    id bigint NOT NULL,
    name character varying NOT NULL,
    unit character varying NOT NULL,
    unit_plural character varying NOT NULL,
    "default" boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: cost_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cost_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cost_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cost_types_id_seq OWNED BY public.cost_types.id;


--
-- Name: custom_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_actions (
    id bigint NOT NULL,
    name character varying,
    actions text,
    description text,
    "position" integer
);


--
-- Name: custom_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_actions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_actions_id_seq OWNED BY public.custom_actions.id;


--
-- Name: custom_actions_projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_actions_projects (
    id bigint NOT NULL,
    project_id bigint,
    custom_action_id bigint
);


--
-- Name: custom_actions_projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_actions_projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_actions_projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_actions_projects_id_seq OWNED BY public.custom_actions_projects.id;


--
-- Name: custom_actions_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_actions_roles (
    id bigint NOT NULL,
    role_id bigint,
    custom_action_id bigint
);


--
-- Name: custom_actions_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_actions_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_actions_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_actions_roles_id_seq OWNED BY public.custom_actions_roles.id;


--
-- Name: custom_actions_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_actions_statuses (
    id bigint NOT NULL,
    status_id bigint,
    custom_action_id bigint
);


--
-- Name: custom_actions_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_actions_statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_actions_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_actions_statuses_id_seq OWNED BY public.custom_actions_statuses.id;


--
-- Name: custom_actions_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_actions_types (
    id bigint NOT NULL,
    type_id bigint,
    custom_action_id bigint
);


--
-- Name: custom_actions_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_actions_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_actions_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_actions_types_id_seq OWNED BY public.custom_actions_types.id;


--
-- Name: custom_field_sections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_field_sections (
    id bigint NOT NULL,
    "position" integer,
    name character varying,
    type character varying,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    display_representation jsonb DEFAULT '{"overview": "sidebar"}'::jsonb NOT NULL
);


--
-- Name: custom_field_sections_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_field_sections_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_field_sections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_field_sections_id_seq OWNED BY public.custom_field_sections.id;


--
-- Name: custom_fields; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_fields (
    id bigint NOT NULL,
    type character varying(30) DEFAULT ''::character varying NOT NULL,
    field_format character varying(30) DEFAULT ''::character varying NOT NULL,
    regexp character varying DEFAULT ''::character varying,
    min_length integer DEFAULT 0 NOT NULL,
    max_length integer DEFAULT 0 NOT NULL,
    is_required boolean DEFAULT false NOT NULL,
    is_for_all boolean DEFAULT false NOT NULL,
    is_filter boolean DEFAULT true NOT NULL,
    "position" integer DEFAULT 1,
    searchable boolean DEFAULT false,
    editable boolean DEFAULT true,
    admin_only boolean DEFAULT false NOT NULL,
    multi_value boolean DEFAULT false,
    default_value text,
    name character varying,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    content_right_to_left boolean DEFAULT false,
    allow_non_open_versions boolean DEFAULT false,
    custom_field_section_id bigint,
    position_in_custom_field_section integer,
    formula jsonb
);


--
-- Name: custom_fields_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_fields_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_fields_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_fields_id_seq OWNED BY public.custom_fields.id;


--
-- Name: custom_fields_projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_fields_projects (
    id bigint NOT NULL,
    custom_field_id bigint NOT NULL,
    project_id bigint NOT NULL
);


--
-- Name: custom_fields_projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_fields_projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_fields_projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_fields_projects_id_seq OWNED BY public.custom_fields_projects.id;


--
-- Name: custom_fields_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_fields_roles (
    id bigint NOT NULL,
    custom_field_id bigint NOT NULL,
    role_id bigint NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: custom_fields_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_fields_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_fields_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_fields_roles_id_seq OWNED BY public.custom_fields_roles.id;


--
-- Name: custom_fields_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_fields_types (
    custom_field_id bigint NOT NULL,
    type_id bigint NOT NULL
);


--
-- Name: custom_options; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_options (
    id bigint NOT NULL,
    custom_field_id bigint,
    "position" integer,
    default_value boolean,
    value text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- Name: custom_options_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_options_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_options_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_options_id_seq OWNED BY public.custom_options.id;


--
-- Name: custom_styles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_styles (
    id bigint NOT NULL,
    logo character varying,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    favicon character varying,
    touch_icon character varying,
    theme character varying DEFAULT 'OpenProject (default)'::character varying,
    theme_logo character varying,
    export_logo character varying,
    export_cover character varying,
    export_cover_text_color character varying,
    export_footer character varying,
    export_font_regular character varying,
    export_font_bold character varying,
    export_font_italic character varying,
    export_font_bold_italic character varying,
    logo_mobile character varying
);


--
-- Name: custom_styles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_styles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_styles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_styles_id_seq OWNED BY public.custom_styles.id;


--
-- Name: custom_values; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_values (
    id bigint NOT NULL,
    customized_type character varying(30) DEFAULT ''::character varying NOT NULL,
    customized_id bigint NOT NULL,
    custom_field_id bigint NOT NULL,
    value text
);


--
-- Name: custom_values_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.custom_values_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: custom_values_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.custom_values_id_seq OWNED BY public.custom_values.id;


--
-- Name: customizable_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customizable_journals (
    id bigint NOT NULL,
    journal_id bigint NOT NULL,
    custom_field_id bigint NOT NULL,
    value text
);


--
-- Name: customizable_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.customizable_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: customizable_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.customizable_journals_id_seq OWNED BY public.customizable_journals.id;


--
-- Name: deploy_status_checks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deploy_status_checks (
    id bigint NOT NULL,
    deploy_target_id bigint,
    github_pull_request_id bigint,
    core_sha text NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: deploy_status_checks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.deploy_status_checks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deploy_status_checks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.deploy_status_checks_id_seq OWNED BY public.deploy_status_checks.id;


--
-- Name: deploy_targets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deploy_targets (
    id bigint NOT NULL,
    type text NOT NULL,
    host text NOT NULL,
    options jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: deploy_targets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.deploy_targets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deploy_targets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.deploy_targets_id_seq OWNED BY public.deploy_targets.id;


--
-- Name: design_colors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.design_colors (
    id bigint NOT NULL,
    variable character varying,
    hexcode character varying,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: design_colors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.design_colors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: design_colors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.design_colors_id_seq OWNED BY public.design_colors.id;


--
-- Name: document_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_journals (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    category_id bigint,
    title character varying(255) NOT NULL,
    description text,
    content_binary text
);


--
-- Name: document_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_journals_id_seq OWNED BY public.document_journals.id;


--
-- Name: document_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_types (
    id bigint NOT NULL,
    name character varying,
    "position" integer,
    is_default boolean DEFAULT false NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    active boolean DEFAULT true NOT NULL,
    documents_count integer DEFAULT 0 NOT NULL
);


--
-- Name: document_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_types_id_seq OWNED BY public.document_types.id;


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    category_id bigint,
    title character varying(255) DEFAULT ''::character varying NOT NULL,
    description text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    type_id bigint,
    kind character varying DEFAULT 'collaborative'::character varying,
    content_binary text
);


--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.documents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- Name: done_statuses_for_project; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.done_statuses_for_project (
    project_id bigint,
    status_id bigint
);


--
-- Name: emoji_reactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.emoji_reactions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    reactable_type character varying NOT NULL,
    reactable_id bigint NOT NULL,
    reaction character varying NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: emoji_reactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.emoji_reactions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: emoji_reactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.emoji_reactions_id_seq OWNED BY public.emoji_reactions.id;


--
-- Name: enabled_modules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enabled_modules (
    id bigint NOT NULL,
    project_id bigint,
    name character varying NOT NULL
);


--
-- Name: enabled_modules_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.enabled_modules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: enabled_modules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.enabled_modules_id_seq OWNED BY public.enabled_modules.id;


--
-- Name: enterprise_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enterprise_tokens (
    id bigint NOT NULL,
    encoded_token text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    valid_from date,
    valid_until date
);


--
-- Name: enterprise_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.enterprise_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: enterprise_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.enterprise_tokens_id_seq OWNED BY public.enterprise_tokens.id;


--
-- Name: enumerations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.enumerations (
    id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    "position" integer DEFAULT 1,
    is_default boolean DEFAULT false NOT NULL,
    type character varying,
    active boolean DEFAULT true NOT NULL,
    project_id bigint,
    parent_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    color_id bigint
);


--
-- Name: enumerations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.enumerations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: enumerations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.enumerations_id_seq OWNED BY public.enumerations.id;


--
-- Name: export_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.export_settings (
    id bigint NOT NULL,
    query_id bigint NOT NULL,
    format character varying NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: export_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.export_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: export_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.export_settings_id_seq OWNED BY public.export_settings.id;


--
-- Name: exports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exports (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    type character varying
);


--
-- Name: exports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.exports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: exports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.exports_id_seq OWNED BY public.exports.id;


--
-- Name: favorites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.favorites (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    favorited_type character varying NOT NULL,
    favorited_id bigint NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: favorites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.favorites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: favorites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.favorites_id_seq OWNED BY public.favorites.id;


--
-- Name: file_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file_links (
    id bigint NOT NULL,
    storage_id bigint,
    creator_id bigint NOT NULL,
    container_id bigint,
    container_type character varying,
    origin_id character varying,
    origin_name character varying,
    origin_created_by_name character varying,
    origin_last_modified_by_name character varying,
    origin_mime_type character varying,
    origin_created_at timestamp with time zone,
    origin_updated_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: file_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.file_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: file_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.file_links_id_seq OWNED BY public.file_links.id;


--
-- Name: forums; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.forums (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    description character varying,
    "position" integer DEFAULT 1,
    topics_count integer DEFAULT 0 NOT NULL,
    messages_count integer DEFAULT 0 NOT NULL,
    last_message_id bigint
);


--
-- Name: forums_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.forums_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: forums_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.forums_id_seq OWNED BY public.forums.id;


--
-- Name: github_check_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_check_runs (
    id bigint NOT NULL,
    github_pull_request_id bigint NOT NULL,
    github_id bigint NOT NULL,
    github_html_url character varying NOT NULL,
    app_id bigint NOT NULL,
    github_app_owner_avatar_url character varying NOT NULL,
    status character varying NOT NULL,
    name character varying NOT NULL,
    conclusion character varying,
    output_title character varying,
    output_summary character varying,
    details_url character varying,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: github_check_runs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.github_check_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: github_check_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.github_check_runs_id_seq OWNED BY public.github_check_runs.id;


--
-- Name: github_pull_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_pull_requests (
    id bigint NOT NULL,
    github_user_id bigint,
    merged_by_id bigint,
    github_id bigint,
    number integer NOT NULL,
    github_html_url character varying NOT NULL,
    state character varying NOT NULL,
    repository character varying NOT NULL,
    github_updated_at timestamp with time zone,
    title character varying,
    body text,
    draft boolean,
    merged boolean,
    merged_at timestamp with time zone,
    comments_count integer,
    review_comments_count integer,
    additions_count integer,
    deletions_count integer,
    changed_files_count integer,
    labels json,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    repository_html_url character varying,
    merge_commit_sha text
);


--
-- Name: github_pull_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.github_pull_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: github_pull_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.github_pull_requests_id_seq OWNED BY public.github_pull_requests.id;


--
-- Name: github_pull_requests_work_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_pull_requests_work_packages (
    github_pull_request_id bigint NOT NULL,
    work_package_id bigint NOT NULL
);


--
-- Name: github_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.github_users (
    id bigint NOT NULL,
    github_id bigint NOT NULL,
    github_login character varying NOT NULL,
    github_html_url character varying NOT NULL,
    github_avatar_url character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: github_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.github_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: github_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.github_users_id_seq OWNED BY public.github_users.id;


--
-- Name: gitlab_issues; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gitlab_issues (
    id bigint NOT NULL,
    gitlab_user_id bigint,
    gitlab_id bigint,
    number integer NOT NULL,
    gitlab_html_url character varying NOT NULL,
    state character varying NOT NULL,
    repository character varying NOT NULL,
    gitlab_updated_at timestamp(6) with time zone,
    title character varying,
    body text,
    labels json,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: gitlab_issues_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gitlab_issues_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gitlab_issues_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gitlab_issues_id_seq OWNED BY public.gitlab_issues.id;


--
-- Name: gitlab_issues_work_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gitlab_issues_work_packages (
    gitlab_issue_id bigint NOT NULL,
    work_package_id bigint NOT NULL
);


--
-- Name: gitlab_merge_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gitlab_merge_requests (
    id bigint NOT NULL,
    gitlab_user_id bigint,
    merged_by_id bigint,
    gitlab_id bigint,
    number integer NOT NULL,
    gitlab_html_url character varying NOT NULL,
    state character varying NOT NULL,
    repository character varying NOT NULL,
    gitlab_updated_at timestamp with time zone,
    title character varying,
    body text,
    draft boolean,
    merged boolean,
    merged_at timestamp with time zone,
    labels json,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: gitlab_merge_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gitlab_merge_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gitlab_merge_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gitlab_merge_requests_id_seq OWNED BY public.gitlab_merge_requests.id;


--
-- Name: gitlab_merge_requests_work_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gitlab_merge_requests_work_packages (
    gitlab_merge_request_id bigint NOT NULL,
    work_package_id bigint NOT NULL
);


--
-- Name: gitlab_pipelines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gitlab_pipelines (
    id bigint NOT NULL,
    gitlab_merge_request_id bigint NOT NULL,
    gitlab_id bigint NOT NULL,
    gitlab_html_url character varying NOT NULL,
    project_id bigint NOT NULL,
    gitlab_user_avatar_url character varying NOT NULL,
    status character varying NOT NULL,
    name character varying NOT NULL,
    details_url character varying,
    ci_details json,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    username text,
    commit_id text
);


--
-- Name: gitlab_pipelines_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gitlab_pipelines_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gitlab_pipelines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gitlab_pipelines_id_seq OWNED BY public.gitlab_pipelines.id;


--
-- Name: gitlab_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gitlab_users (
    id bigint NOT NULL,
    gitlab_id bigint NOT NULL,
    gitlab_name character varying NOT NULL,
    gitlab_username character varying NOT NULL,
    gitlab_email character varying NOT NULL,
    gitlab_avatar_url character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: gitlab_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gitlab_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gitlab_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gitlab_users_id_seq OWNED BY public.gitlab_users.id;


--
-- Name: good_job_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.good_job_batches (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    description text,
    serialized_properties jsonb,
    on_finish text,
    on_success text,
    on_discard text,
    callback_queue_name text,
    callback_priority integer,
    enqueued_at timestamp(6) with time zone,
    discarded_at timestamp(6) with time zone,
    finished_at timestamp(6) with time zone,
    jobs_finished_at timestamp(6) with time zone
);


--
-- Name: good_job_executions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.good_job_executions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    active_job_id uuid NOT NULL,
    job_class text,
    queue_name text,
    serialized_params jsonb,
    scheduled_at timestamp(6) with time zone,
    finished_at timestamp(6) with time zone,
    error text,
    error_event smallint,
    error_backtrace text[],
    process_id uuid,
    duration interval
);


--
-- Name: good_job_processes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.good_job_processes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    state jsonb,
    lock_type smallint
);


--
-- Name: good_job_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.good_job_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    key text,
    value jsonb
);


--
-- Name: good_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.good_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    queue_name text,
    priority integer,
    serialized_params jsonb,
    scheduled_at timestamp(6) with time zone,
    performed_at timestamp(6) with time zone,
    finished_at timestamp(6) with time zone,
    error text,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    active_job_id uuid,
    concurrency_key text,
    cron_key text,
    retried_good_job_id uuid,
    cron_at timestamp(6) with time zone,
    batch_id uuid,
    batch_callback_id uuid,
    is_discrete boolean,
    executions_count integer,
    job_class text,
    error_event smallint,
    labels text[],
    locked_by_id uuid,
    locked_at timestamp(6) with time zone
);


--
-- Name: grid_widgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grid_widgets (
    id bigint NOT NULL,
    start_row integer NOT NULL,
    end_row integer NOT NULL,
    start_column integer NOT NULL,
    end_column integer NOT NULL,
    identifier character varying,
    options text,
    grid_id bigint
);


--
-- Name: grid_widgets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.grid_widgets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: grid_widgets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.grid_widgets_id_seq OWNED BY public.grid_widgets.id;


--
-- Name: grids; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.grids (
    id bigint NOT NULL,
    row_count integer NOT NULL,
    column_count integer NOT NULL,
    type character varying,
    user_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    project_id bigint,
    name text,
    options text
);


--
-- Name: grids_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.grids_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: grids_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.grids_id_seq OWNED BY public.grids.id;


--
-- Name: group_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_users (
    id bigint NOT NULL,
    group_id bigint NOT NULL,
    user_id bigint NOT NULL
);


--
-- Name: group_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.group_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: group_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.group_users_id_seq OWNED BY public.group_users.id;


--
-- Name: hierarchical_item_hierarchies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hierarchical_item_hierarchies (
    ancestor_id integer NOT NULL,
    descendant_id integer NOT NULL,
    generations integer NOT NULL
);


--
-- Name: hierarchical_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hierarchical_items (
    id bigint NOT NULL,
    parent_id integer,
    sort_order integer,
    label character varying,
    short character varying,
    is_deleted boolean DEFAULT false NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    custom_field_id bigint,
    position_cache bigint,
    weight numeric,
    children_count integer DEFAULT 0
);


--
-- Name: hierarchical_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hierarchical_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hierarchical_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hierarchical_items_id_seq OWNED BY public.hierarchical_items.id;


--
-- Name: ical_token_query_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ical_token_query_assignments (
    id bigint NOT NULL,
    ical_token_id bigint,
    query_id bigint,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    name character varying NOT NULL
);


--
-- Name: ical_token_query_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ical_token_query_assignments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ical_token_query_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ical_token_query_assignments_id_seq OWNED BY public.ical_token_query_assignments.id;


--
-- Name: ifc_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ifc_models (
    id bigint NOT NULL,
    title character varying,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    project_id bigint,
    uploader_id bigint,
    is_default boolean DEFAULT false NOT NULL,
    conversion_status integer DEFAULT 0,
    conversion_error_message text
);


--
-- Name: ifc_models_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ifc_models_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ifc_models_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ifc_models_id_seq OWNED BY public.ifc_models.id;


--
-- Name: job_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.job_statuses (
    id bigint NOT NULL,
    reference_type character varying,
    reference_id bigint,
    message character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    status character varying DEFAULT 'in_queue'::character varying,
    user_id bigint,
    job_id character varying,
    payload jsonb,
    CONSTRAINT delayed_job_statuses_status_check CHECK (((status IS NULL) OR ((status)::text = ANY (ARRAY[('in_queue'::character varying)::text, ('error'::character varying)::text, ('in_process'::character varying)::text, ('success'::character varying)::text, ('failure'::character varying)::text, ('cancelled'::character varying)::text]))))
);


--
-- Name: job_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.job_statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: job_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.job_statuses_id_seq OWNED BY public.job_statuses.id;


--
-- Name: journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.journals (
    id bigint NOT NULL,
    journable_type character varying,
    journable_id bigint,
    user_id bigint NOT NULL,
    notes text,
    created_at timestamp with time zone NOT NULL,
    version integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    data_type character varying NOT NULL,
    data_id bigint NOT NULL,
    cause jsonb DEFAULT '{}'::jsonb,
    validity_period tstzrange,
    restricted boolean DEFAULT false NOT NULL,
    CONSTRAINT journals_validity_period_not_empty CHECK (((NOT isempty(validity_period)) AND (validity_period IS NOT NULL)))
);


--
-- Name: journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.journals_id_seq OWNED BY public.journals.id;


--
-- Name: labor_budget_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.labor_budget_items (
    id bigint NOT NULL,
    budget_id bigint NOT NULL,
    hours double precision NOT NULL,
    user_id bigint,
    comments character varying DEFAULT ''::character varying NOT NULL,
    amount numeric(15,4)
);


--
-- Name: labor_budget_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.labor_budget_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: labor_budget_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.labor_budget_items_id_seq OWNED BY public.labor_budget_items.id;


--
-- Name: last_project_folders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.last_project_folders (
    id bigint NOT NULL,
    project_storage_id bigint NOT NULL,
    origin_folder_id character varying,
    mode character varying DEFAULT 'inactive'::character varying NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    CONSTRAINT last_project_folders_mode_check CHECK (((mode)::text = ANY (ARRAY[('inactive'::character varying)::text, ('manual'::character varying)::text, ('automatic'::character varying)::text])))
);


--
-- Name: TABLE last_project_folders; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.last_project_folders IS 'This table contains the last used project folder IDs for a project storage per mode.';


--
-- Name: last_project_folders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.last_project_folders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: last_project_folders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.last_project_folders_id_seq OWNED BY public.last_project_folders.id;


--
-- Name: ldap_auth_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ldap_auth_sources (
    id bigint NOT NULL,
    name character varying(60) DEFAULT ''::character varying NOT NULL,
    host character varying(60),
    port integer,
    account character varying,
    account_password character varying DEFAULT ''::character varying,
    base_dn character varying,
    attr_login character varying(30),
    attr_firstname character varying(30),
    attr_lastname character varying(30),
    attr_mail character varying(30),
    onthefly_register boolean DEFAULT false NOT NULL,
    attr_admin character varying,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    tls_mode integer DEFAULT 0 NOT NULL,
    filter_string text,
    verify_peer boolean DEFAULT true NOT NULL,
    tls_certificate_string text
);


--
-- Name: ldap_auth_sources_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ldap_auth_sources_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ldap_auth_sources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ldap_auth_sources_id_seq OWNED BY public.ldap_auth_sources.id;


--
-- Name: ldap_groups_memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ldap_groups_memberships (
    id bigint NOT NULL,
    user_id bigint,
    group_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: ldap_groups_memberships_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ldap_groups_memberships_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ldap_groups_memberships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ldap_groups_memberships_id_seq OWNED BY public.ldap_groups_memberships.id;


--
-- Name: ldap_groups_synchronized_filters; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ldap_groups_synchronized_filters (
    id bigint NOT NULL,
    name character varying,
    group_name_attribute character varying,
    filter_string character varying,
    ldap_auth_source_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    base_dn text,
    sync_users boolean DEFAULT false NOT NULL
);


--
-- Name: ldap_groups_synchronized_filters_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ldap_groups_synchronized_filters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ldap_groups_synchronized_filters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ldap_groups_synchronized_filters_id_seq OWNED BY public.ldap_groups_synchronized_filters.id;


--
-- Name: ldap_groups_synchronized_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ldap_groups_synchronized_groups (
    id bigint NOT NULL,
    group_id bigint,
    ldap_auth_source_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    dn text,
    users_count integer DEFAULT 0 NOT NULL,
    filter_id bigint,
    sync_users boolean DEFAULT false NOT NULL
);


--
-- Name: ldap_groups_synchronized_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ldap_groups_synchronized_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ldap_groups_synchronized_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ldap_groups_synchronized_groups_id_seq OWNED BY public.ldap_groups_synchronized_groups.id;


--
-- Name: material_budget_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.material_budget_items (
    id bigint NOT NULL,
    budget_id bigint NOT NULL,
    units double precision NOT NULL,
    cost_type_id bigint,
    comments character varying DEFAULT ''::character varying NOT NULL,
    amount numeric(15,4)
);


--
-- Name: material_budget_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.material_budget_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: material_budget_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.material_budget_items_id_seq OWNED BY public.material_budget_items.id;


--
-- Name: mcp_configurations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_configurations (
    id bigint NOT NULL,
    identifier character varying NOT NULL,
    title character varying NOT NULL,
    description character varying NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: mcp_configurations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.mcp_configurations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: mcp_configurations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.mcp_configurations_id_seq OWNED BY public.mcp_configurations.id;


--
-- Name: meeting_agenda_item_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meeting_agenda_item_journals (
    id bigint NOT NULL,
    journal_id integer,
    agenda_item_id integer,
    author_id integer,
    title character varying,
    notes text,
    "position" integer,
    duration_in_minutes integer,
    work_package_id integer,
    item_type smallint,
    presenter_id bigint
);


--
-- Name: meeting_agenda_item_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.meeting_agenda_item_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meeting_agenda_item_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.meeting_agenda_item_journals_id_seq OWNED BY public.meeting_agenda_item_journals.id;


--
-- Name: meeting_agenda_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meeting_agenda_items (
    id bigint NOT NULL,
    meeting_id bigint,
    author_id bigint,
    title character varying,
    notes text,
    "position" integer,
    duration_in_minutes integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    work_package_id bigint,
    item_type smallint DEFAULT 0,
    lock_version integer DEFAULT 0 NOT NULL,
    presenter_id bigint,
    meeting_section_id bigint
);


--
-- Name: meeting_agenda_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.meeting_agenda_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meeting_agenda_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.meeting_agenda_items_id_seq OWNED BY public.meeting_agenda_items.id;


--
-- Name: meeting_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meeting_journals (
    id bigint NOT NULL,
    title character varying,
    author_id bigint,
    project_id bigint,
    location character varying,
    start_time timestamp with time zone,
    duration double precision,
    state integer DEFAULT 0 NOT NULL
);


--
-- Name: meeting_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.meeting_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meeting_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.meeting_journals_id_seq OWNED BY public.meeting_journals.id;


--
-- Name: meeting_outcomes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meeting_outcomes (
    id bigint NOT NULL,
    notes text,
    meeting_agenda_item_id bigint,
    work_package_id bigint,
    kind integer DEFAULT 0 NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    author_id bigint
);


--
-- Name: meeting_outcomes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.meeting_outcomes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meeting_outcomes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.meeting_outcomes_id_seq OWNED BY public.meeting_outcomes.id;


--
-- Name: meeting_participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meeting_participants (
    id bigint NOT NULL,
    user_id bigint,
    meeting_id bigint,
    email character varying,
    name character varying,
    invited boolean,
    attended boolean,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    participation_status character varying DEFAULT 'needs-action'::character varying NOT NULL,
    comment text
);


--
-- Name: meeting_participants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.meeting_participants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meeting_participants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.meeting_participants_id_seq OWNED BY public.meeting_participants.id;


--
-- Name: meeting_sections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meeting_sections (
    id bigint NOT NULL,
    "position" integer,
    title character varying,
    meeting_id bigint NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    backlog boolean DEFAULT false NOT NULL
);


--
-- Name: meeting_sections_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.meeting_sections_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meeting_sections_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.meeting_sections_id_seq OWNED BY public.meeting_sections.id;


--
-- Name: meetings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.meetings (
    id bigint NOT NULL,
    title character varying,
    author_id bigint,
    project_id bigint,
    location character varying,
    start_time timestamp with time zone,
    duration double precision,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    state integer DEFAULT 0 NOT NULL,
    lock_version integer DEFAULT 0 NOT NULL,
    recurring_meeting_id bigint,
    template boolean DEFAULT false NOT NULL,
    uid character varying,
    notify boolean DEFAULT true NOT NULL
);


--
-- Name: meetings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.meetings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: meetings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.meetings_id_seq OWNED BY public.meetings.id;


--
-- Name: member_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_roles (
    id bigint NOT NULL,
    member_id bigint NOT NULL,
    role_id bigint NOT NULL,
    inherited_from bigint
);


--
-- Name: member_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: member_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_roles_id_seq OWNED BY public.member_roles.id;


--
-- Name: members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.members (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    project_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    entity_type character varying,
    entity_id bigint
);


--
-- Name: members_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.members_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.members_id_seq OWNED BY public.members.id;


--
-- Name: menu_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.menu_items (
    id bigint NOT NULL,
    name character varying,
    title character varying,
    parent_id bigint,
    options text,
    navigatable_id bigint,
    type character varying
);


--
-- Name: menu_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.menu_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: menu_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.menu_items_id_seq OWNED BY public.menu_items.id;


--
-- Name: message_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_journals (
    id bigint NOT NULL,
    forum_id bigint NOT NULL,
    parent_id bigint,
    subject character varying NOT NULL,
    content text,
    author_id bigint,
    locked boolean,
    sticky integer
);


--
-- Name: message_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.message_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: message_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.message_journals_id_seq OWNED BY public.message_journals.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id bigint NOT NULL,
    forum_id bigint NOT NULL,
    parent_id bigint,
    subject character varying DEFAULT ''::character varying NOT NULL,
    content text,
    author_id bigint,
    replies_count integer DEFAULT 0 NOT NULL,
    last_reply_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    locked boolean DEFAULT false,
    sticky integer DEFAULT 0,
    sticked_on timestamp with time zone
);


--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.messages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: news; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.news (
    id bigint NOT NULL,
    project_id bigint,
    title character varying DEFAULT ''::character varying NOT NULL,
    summary character varying DEFAULT ''::character varying,
    description text,
    author_id bigint NOT NULL,
    created_at timestamp with time zone,
    comments_count integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone
);


--
-- Name: news_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.news_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: news_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.news_id_seq OWNED BY public.news.id;


--
-- Name: news_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.news_journals (
    id bigint NOT NULL,
    project_id bigint,
    title character varying NOT NULL,
    summary character varying,
    description text,
    author_id bigint NOT NULL,
    comments_count integer NOT NULL
);


--
-- Name: news_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.news_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: news_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.news_journals_id_seq OWNED BY public.news_journals.id;


--
-- Name: non_working_days; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.non_working_days (
    id bigint NOT NULL,
    name character varying NOT NULL,
    date date NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: non_working_days_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.non_working_days_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: non_working_days_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.non_working_days_id_seq OWNED BY public.non_working_days.id;


--
-- Name: notification_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_settings (
    id bigint NOT NULL,
    project_id bigint,
    user_id bigint NOT NULL,
    watched boolean DEFAULT true,
    mentioned boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    work_package_commented boolean DEFAULT false,
    work_package_created boolean DEFAULT false,
    work_package_processed boolean DEFAULT false,
    work_package_prioritized boolean DEFAULT false,
    work_package_scheduled boolean DEFAULT false,
    news_added boolean DEFAULT false,
    news_commented boolean DEFAULT false,
    document_added boolean DEFAULT false,
    forum_messages boolean DEFAULT false,
    wiki_page_added boolean DEFAULT false,
    wiki_page_updated boolean DEFAULT false,
    membership_added boolean DEFAULT false,
    membership_updated boolean DEFAULT false,
    start_date integer DEFAULT 1,
    due_date integer DEFAULT 1,
    overdue integer,
    assignee boolean DEFAULT true NOT NULL,
    responsible boolean DEFAULT true NOT NULL,
    shared boolean DEFAULT true NOT NULL
);


--
-- Name: notification_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notification_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notification_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notification_settings_id_seq OWNED BY public.notification_settings.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id bigint NOT NULL,
    subject text,
    read_ian boolean DEFAULT false,
    reason smallint,
    recipient_id bigint NOT NULL,
    actor_id bigint,
    resource_type character varying NOT NULL,
    resource_id bigint NOT NULL,
    journal_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    mail_reminder_sent boolean DEFAULT false,
    mail_alert_sent boolean
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: oauth_access_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_access_grants (
    id bigint NOT NULL,
    resource_owner_id bigint NOT NULL,
    application_id bigint NOT NULL,
    token character varying NOT NULL,
    expires_in integer NOT NULL,
    redirect_uri text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    scopes character varying,
    code_challenge character varying,
    code_challenge_method character varying
);


--
-- Name: oauth_access_grants_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oauth_access_grants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oauth_access_grants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oauth_access_grants_id_seq OWNED BY public.oauth_access_grants.id;


--
-- Name: oauth_access_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_access_tokens (
    id bigint NOT NULL,
    resource_owner_id bigint,
    application_id bigint,
    token character varying NOT NULL,
    refresh_token character varying,
    expires_in integer,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    scopes character varying,
    previous_refresh_token character varying DEFAULT ''::character varying NOT NULL
);


--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oauth_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oauth_access_tokens_id_seq OWNED BY public.oauth_access_tokens.id;


--
-- Name: oauth_applications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_applications (
    id bigint NOT NULL,
    name character varying NOT NULL,
    uid character varying NOT NULL,
    secret character varying NOT NULL,
    owner_type character varying,
    owner_id bigint,
    client_credentials_user_id bigint,
    redirect_uri text NOT NULL,
    scopes character varying DEFAULT ''::character varying NOT NULL,
    confidential boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    integration_type character varying,
    integration_id bigint,
    enabled boolean DEFAULT true NOT NULL,
    builtin boolean DEFAULT false NOT NULL
);


--
-- Name: oauth_applications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oauth_applications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oauth_applications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oauth_applications_id_seq OWNED BY public.oauth_applications.id;


--
-- Name: oauth_client_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_client_tokens (
    id bigint NOT NULL,
    oauth_client_id bigint NOT NULL,
    user_id bigint NOT NULL,
    access_token character varying,
    refresh_token character varying,
    token_type character varying,
    expires_in integer,
    scope character varying,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    lock_version integer DEFAULT 0 NOT NULL
);


--
-- Name: oauth_client_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oauth_client_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oauth_client_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oauth_client_tokens_id_seq OWNED BY public.oauth_client_tokens.id;


--
-- Name: oauth_clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_clients (
    id bigint NOT NULL,
    client_id character varying NOT NULL,
    client_secret character varying,
    integration_type character varying NOT NULL,
    integration_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: oauth_clients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oauth_clients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oauth_clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oauth_clients_id_seq OWNED BY public.oauth_clients.id;


--
-- Name: oidc_group_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oidc_group_links (
    id bigint NOT NULL,
    group_id bigint NOT NULL,
    auth_provider_id bigint NOT NULL,
    oidc_group_name character varying NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: oidc_group_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oidc_group_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oidc_group_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oidc_group_links_id_seq OWNED BY public.oidc_group_links.id;


--
-- Name: oidc_group_memberships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oidc_group_memberships (
    id bigint NOT NULL,
    auth_provider_id bigint NOT NULL,
    group_user_id bigint NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: oidc_group_memberships_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oidc_group_memberships_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oidc_group_memberships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oidc_group_memberships_id_seq OWNED BY public.oidc_group_memberships.id;


--
-- Name: oidc_user_session_links; Type: TABLE; Schema: public; Owner: -
--

CREATE UNLOGGED TABLE public.oidc_user_session_links (
    id bigint NOT NULL,
    oidc_session character varying NOT NULL,
    session_id bigint,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: oidc_user_session_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE UNLOGGED SEQUENCE public.oidc_user_session_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oidc_user_session_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oidc_user_session_links_id_seq OWNED BY public.oidc_user_session_links.id;


--
-- Name: oidc_user_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oidc_user_tokens (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    access_token character varying NOT NULL,
    refresh_token character varying,
    audiences jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    expires_at timestamp(0) with time zone
);


--
-- Name: oidc_user_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.oidc_user_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: oidc_user_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.oidc_user_tokens_id_seq OWNED BY public.oidc_user_tokens.id;


--
-- Name: ordered_work_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ordered_work_packages (
    id bigint NOT NULL,
    "position" integer NOT NULL,
    query_id bigint,
    work_package_id bigint
);


--
-- Name: ordered_work_packages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ordered_work_packages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ordered_work_packages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ordered_work_packages_id_seq OWNED BY public.ordered_work_packages.id;


--
-- Name: paper_trail_audits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.paper_trail_audits (
    id bigint NOT NULL,
    item_type character varying NOT NULL,
    item_id bigint NOT NULL,
    event character varying NOT NULL,
    whodunnit character varying,
    stack text,
    object jsonb,
    object_changes jsonb,
    created_at timestamp(6) with time zone
);


--
-- Name: paper_trail_audits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.paper_trail_audits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: paper_trail_audits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.paper_trail_audits_id_seq OWNED BY public.paper_trail_audits.id;


--
-- Name: project_custom_field_project_mappings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_custom_field_project_mappings (
    id bigint NOT NULL,
    custom_field_id bigint,
    project_id bigint,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    creation_wizard boolean DEFAULT true NOT NULL
);


--
-- Name: project_custom_field_project_mappings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_custom_field_project_mappings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_custom_field_project_mappings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_custom_field_project_mappings_id_seq OWNED BY public.project_custom_field_project_mappings.id;


--
-- Name: project_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_journals (
    id bigint NOT NULL,
    name character varying NOT NULL,
    description text,
    public boolean NOT NULL,
    parent_id bigint,
    identifier character varying NOT NULL,
    active boolean NOT NULL,
    templated boolean NOT NULL,
    status_code integer,
    status_explanation text,
    workspace_type character varying NOT NULL
);


--
-- Name: project_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_journals_id_seq OWNED BY public.project_journals.id;


--
-- Name: project_phase_definitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_phase_definitions (
    id bigint NOT NULL,
    name character varying,
    "position" integer,
    color_id bigint,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    start_gate boolean DEFAULT false NOT NULL,
    start_gate_name character varying,
    finish_gate boolean DEFAULT false NOT NULL,
    finish_gate_name character varying
);


--
-- Name: project_phase_definitions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_phase_definitions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_phase_definitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_phase_definitions_id_seq OWNED BY public.project_phase_definitions.id;


--
-- Name: project_phase_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_phase_journals (
    id bigint NOT NULL,
    journal_id bigint NOT NULL,
    phase_id bigint NOT NULL,
    start_date date,
    finish_date date,
    active boolean DEFAULT false NOT NULL,
    duration integer
);


--
-- Name: project_phase_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_phase_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_phase_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_phase_journals_id_seq OWNED BY public.project_phase_journals.id;


--
-- Name: project_phases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_phases (
    id bigint NOT NULL,
    start_date date,
    finish_date date,
    active boolean DEFAULT false NOT NULL,
    project_id bigint NOT NULL,
    definition_id bigint NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    duration integer
);


--
-- Name: project_phases_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_phases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_phases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_phases_id_seq OWNED BY public.project_phases.id;


--
-- Name: project_queries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_queries (
    id bigint NOT NULL,
    name character varying NOT NULL,
    user_id bigint NOT NULL,
    filters json DEFAULT '[]'::json,
    selects json DEFAULT '[]'::json,
    orders json DEFAULT '[]'::json,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    public boolean DEFAULT false NOT NULL
);


--
-- Name: project_queries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_queries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_queries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_queries_id_seq OWNED BY public.project_queries.id;


--
-- Name: project_storages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_storages (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    storage_id bigint NOT NULL,
    creator_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    project_folder_id character varying,
    project_folder_mode character varying NOT NULL,
    CONSTRAINT project_storages_project_folder_mode_check CHECK (((project_folder_mode)::text = ANY (ARRAY[('inactive'::character varying)::text, ('manual'::character varying)::text, ('automatic'::character varying)::text])))
);


--
-- Name: project_storages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_storages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_storages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_storages_id_seq OWNED BY public.project_storages.id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    description text,
    public boolean DEFAULT true NOT NULL,
    parent_id bigint,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    identifier character varying NOT NULL,
    lft integer,
    rgt integer,
    active boolean DEFAULT true NOT NULL,
    templated boolean DEFAULT false NOT NULL,
    status_code integer,
    status_explanation text,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    workspace_type character varying NOT NULL,
    template_id bigint
);


--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.id;


--
-- Name: projects_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects_types (
    project_id bigint NOT NULL,
    type_id bigint NOT NULL
);


--
-- Name: queries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.queries (
    id bigint NOT NULL,
    project_id bigint,
    name character varying NOT NULL,
    filters text,
    user_id bigint NOT NULL,
    public boolean DEFAULT false NOT NULL,
    column_names text,
    sort_criteria text,
    group_by character varying,
    display_sums boolean DEFAULT false NOT NULL,
    timeline_visible boolean DEFAULT false,
    show_hierarchies boolean DEFAULT false,
    timeline_zoom_level integer DEFAULT 5,
    timeline_labels text,
    highlighting_mode text,
    highlighted_attributes text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    display_representation text,
    starred boolean DEFAULT false,
    include_subprojects boolean NOT NULL,
    timestamps character varying
);


--
-- Name: queries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.queries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: queries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.queries_id_seq OWNED BY public.queries.id;


--
-- Name: rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rates (
    id bigint NOT NULL,
    valid_from date NOT NULL,
    rate numeric(15,4) NOT NULL,
    type character varying NOT NULL,
    project_id bigint,
    user_id bigint,
    cost_type_id bigint
);


--
-- Name: rates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rates_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rates_id_seq OWNED BY public.rates.id;


--
-- Name: recaptcha_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recaptcha_entries (
    id integer NOT NULL,
    user_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    version integer NOT NULL
);


--
-- Name: recaptcha_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.recaptcha_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: recaptcha_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.recaptcha_entries_id_seq OWNED BY public.recaptcha_entries.id;


--
-- Name: recurring_meeting_interim_responses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recurring_meeting_interim_responses (
    id bigint NOT NULL,
    recurring_meeting_id bigint,
    user_id bigint,
    start_time timestamp(6) with time zone,
    participation_status character varying,
    comment text,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: recurring_meeting_interim_responses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.recurring_meeting_interim_responses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: recurring_meeting_interim_responses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.recurring_meeting_interim_responses_id_seq OWNED BY public.recurring_meeting_interim_responses.id;


--
-- Name: recurring_meetings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recurring_meetings (
    id bigint NOT NULL,
    start_time timestamp(6) with time zone,
    end_date date,
    title text,
    frequency integer DEFAULT 0 NOT NULL,
    end_after integer DEFAULT 0 NOT NULL,
    iterations integer,
    project_id bigint,
    author_id bigint,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    "interval" integer DEFAULT 1 NOT NULL,
    time_zone character varying NOT NULL,
    uid character varying,
    current_schedule_start timestamp(6) with time zone NOT NULL
);


--
-- Name: recurring_meetings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.recurring_meetings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: recurring_meetings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.recurring_meetings_id_seq OWNED BY public.recurring_meetings.id;


--
-- Name: relations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.relations (
    id bigint NOT NULL,
    from_id integer NOT NULL,
    to_id integer NOT NULL,
    lag integer,
    description text,
    relation_type character varying
);


--
-- Name: relations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.relations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: relations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.relations_id_seq OWNED BY public.relations.id;


--
-- Name: reminder_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reminder_notifications (
    id bigint NOT NULL,
    reminder_id bigint,
    notification_id bigint,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: reminder_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reminder_notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reminder_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reminder_notifications_id_seq OWNED BY public.reminder_notifications.id;


--
-- Name: reminders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reminders (
    id bigint NOT NULL,
    remindable_type character varying NOT NULL,
    remindable_id bigint NOT NULL,
    creator_id bigint NOT NULL,
    remind_at timestamp(6) with time zone NOT NULL,
    completed_at timestamp(6) with time zone,
    job_id character varying,
    note text,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: reminders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reminders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reminders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reminders_id_seq OWNED BY public.reminders.id;


--
-- Name: remote_identities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.remote_identities (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    auth_source_id bigint NOT NULL,
    origin_user_id character varying NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    auth_source_type character varying NOT NULL,
    integration_type character varying NOT NULL,
    integration_id bigint NOT NULL
);


--
-- Name: remote_identities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.remote_identities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: remote_identities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.remote_identities_id_seq OWNED BY public.remote_identities.id;


--
-- Name: repositories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repositories (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    url character varying DEFAULT ''::character varying NOT NULL,
    login character varying(60) DEFAULT ''::character varying,
    password character varying DEFAULT ''::character varying,
    root_url character varying DEFAULT ''::character varying,
    type character varying,
    path_encoding character varying(64),
    log_encoding character varying(64),
    scm_type character varying NOT NULL,
    required_storage_bytes bigint DEFAULT 0 NOT NULL,
    storage_updated_at timestamp with time zone
);


--
-- Name: repositories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.repositories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repositories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.repositories_id_seq OWNED BY public.repositories.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    id bigint NOT NULL,
    permission character varying,
    role_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: role_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.role_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: role_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.role_permissions_id_seq OWNED BY public.role_permissions.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    "position" integer DEFAULT 1,
    builtin integer DEFAULT 0 NOT NULL,
    type character varying(30) DEFAULT 'Role'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: scheduled_meetings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scheduled_meetings (
    id bigint NOT NULL,
    recurring_meeting_id bigint NOT NULL,
    meeting_id bigint,
    start_time timestamp(6) with time zone NOT NULL,
    cancelled boolean DEFAULT false NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: scheduled_meetings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.scheduled_meetings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: scheduled_meetings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.scheduled_meetings_id_seq OWNED BY public.scheduled_meetings.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


--
-- Name: scim_clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scim_clients (
    id bigint NOT NULL,
    name character varying NOT NULL,
    auth_provider_id bigint NOT NULL,
    authentication_method integer NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: scim_clients_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.scim_clients_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: scim_clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.scim_clients_id_seq OWNED BY public.scim_clients.id;


--
-- Name: service_account_associations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_account_associations (
    id bigint NOT NULL,
    service_account_id bigint NOT NULL,
    service_id bigint NOT NULL,
    service_type character varying NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: service_account_associations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.service_account_associations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: service_account_associations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.service_account_associations_id_seq OWNED BY public.service_account_associations.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE UNLOGGED TABLE public.sessions (
    id bigint NOT NULL,
    session_id character varying NOT NULL,
    data text,
    updated_at timestamp with time zone,
    user_id bigint
);


--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE UNLOGGED SEQUENCE public.sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    value text,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.statuses (
    id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    is_closed boolean DEFAULT false NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    "position" integer DEFAULT 1,
    default_done_ratio integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    color_id bigint,
    is_readonly boolean DEFAULT false,
    excluded_from_totals boolean DEFAULT false NOT NULL
);


--
-- Name: statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.statuses_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.statuses_id_seq OWNED BY public.statuses.id;


--
-- Name: storages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storages (
    id bigint NOT NULL,
    provider_type character varying NOT NULL,
    name character varying NOT NULL,
    host character varying,
    creator_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    provider_fields jsonb DEFAULT '{}'::jsonb NOT NULL,
    health_status character varying DEFAULT 'pending'::character varying NOT NULL,
    health_changed_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    health_reason character varying,
    health_checked_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT storages_health_status_check CHECK (((health_status)::text = ANY (ARRAY[('pending'::character varying)::text, ('healthy'::character varying)::text, ('unhealthy'::character varying)::text])))
);


--
-- Name: storages_file_links_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storages_file_links_journals (
    id bigint NOT NULL,
    journal_id bigint NOT NULL,
    file_link_id bigint NOT NULL,
    link_name character varying NOT NULL,
    storage_name character varying
);


--
-- Name: storages_file_links_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.storages_file_links_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: storages_file_links_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.storages_file_links_journals_id_seq OWNED BY public.storages_file_links_journals.id;


--
-- Name: storages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.storages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: storages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.storages_id_seq OWNED BY public.storages.id;


--
-- Name: subproject_template_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subproject_template_assignments (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    template_id bigint NOT NULL,
    workspace_type character varying NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: subproject_template_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.subproject_template_assignments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: subproject_template_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.subproject_template_assignments_id_seq OWNED BY public.subproject_template_assignments.id;


--
-- Name: time_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.time_entries (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    user_id bigint NOT NULL,
    work_package_id bigint,
    hours double precision,
    comments text,
    activity_id bigint,
    spent_on date NOT NULL,
    tyear integer NOT NULL,
    tmonth integer NOT NULL,
    tweek integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    overridden_costs numeric(15,4),
    costs numeric(15,4),
    rate_id bigint,
    logged_by_id bigint NOT NULL,
    ongoing boolean DEFAULT false NOT NULL,
    start_time integer,
    time_zone character varying,
    entity_type character varying,
    entity_id bigint
);


--
-- Name: time_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.time_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: time_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.time_entries_id_seq OWNED BY public.time_entries.id;


--
-- Name: time_entry_activities_projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.time_entry_activities_projects (
    id bigint NOT NULL,
    activity_id bigint NOT NULL,
    project_id bigint NOT NULL,
    active boolean DEFAULT true
);


--
-- Name: time_entry_activities_projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.time_entry_activities_projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: time_entry_activities_projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.time_entry_activities_projects_id_seq OWNED BY public.time_entry_activities_projects.id;


--
-- Name: time_entry_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.time_entry_journals (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    user_id bigint NOT NULL,
    work_package_id bigint,
    hours double precision,
    comments text,
    activity_id bigint,
    spent_on date NOT NULL,
    tyear integer NOT NULL,
    tmonth integer NOT NULL,
    tweek integer NOT NULL,
    overridden_costs numeric(15,2),
    costs numeric(15,2),
    rate_id bigint,
    logged_by_id bigint NOT NULL,
    start_time integer,
    time_zone character varying,
    entity_type character varying,
    entity_id bigint
);


--
-- Name: time_entry_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.time_entry_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: time_entry_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.time_entry_journals_id_seq OWNED BY public.time_entry_journals.id;


--
-- Name: tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tokens (
    id bigint NOT NULL,
    user_id bigint,
    type character varying,
    value character varying(128) DEFAULT ''::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    expires_on timestamp with time zone,
    data json
);


--
-- Name: tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tokens_id_seq OWNED BY public.tokens.id;


--
-- Name: two_factor_authentication_devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.two_factor_authentication_devices (
    id bigint NOT NULL,
    type character varying,
    "default" boolean DEFAULT false NOT NULL,
    active boolean DEFAULT false NOT NULL,
    channel character varying NOT NULL,
    phone_number character varying,
    identifier character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    last_used_at integer,
    otp_secret text,
    user_id bigint,
    webauthn_external_id character varying,
    webauthn_public_key character varying,
    webauthn_sign_count bigint DEFAULT 0 NOT NULL
);


--
-- Name: two_factor_authentication_devices_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.two_factor_authentication_devices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: two_factor_authentication_devices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.two_factor_authentication_devices_id_seq OWNED BY public.two_factor_authentication_devices.id;


--
-- Name: types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.types (
    id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL,
    "position" integer DEFAULT 1,
    is_in_roadmap boolean DEFAULT true NOT NULL,
    is_milestone boolean DEFAULT false NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    color_id bigint,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    is_standard boolean DEFAULT false NOT NULL,
    attribute_groups text,
    description text,
    patterns text,
    pdf_export_templates_config jsonb DEFAULT '{}'::jsonb
);


--
-- Name: types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.types_id_seq OWNED BY public.types.id;


--
-- Name: user_auth_provider_links; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_auth_provider_links (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    auth_provider_id bigint NOT NULL,
    external_id character varying NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);


--
-- Name: user_auth_provider_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_auth_provider_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_auth_provider_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_auth_provider_links_id_seq OWNED BY public.user_auth_provider_links.id;


--
-- Name: user_passwords; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_passwords (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    hashed_password character varying(128) NOT NULL,
    salt character varying(64),
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    type character varying NOT NULL
);


--
-- Name: user_passwords_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_passwords_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_passwords_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_passwords_id_seq OWNED BY public.user_passwords.id;


--
-- Name: user_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_preferences (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb,
    created_at timestamp(6) with time zone NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL,
    dismissed_enterprise_banners jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: user_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.user_preferences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.user_preferences_id_seq OWNED BY public.user_preferences.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    login character varying(256) DEFAULT ''::character varying NOT NULL,
    firstname character varying DEFAULT ''::character varying NOT NULL,
    lastname character varying DEFAULT ''::character varying NOT NULL,
    mail character varying DEFAULT ''::character varying NOT NULL,
    admin boolean DEFAULT false NOT NULL,
    status integer DEFAULT 1 NOT NULL,
    last_login_on timestamp with time zone,
    language character varying(5) DEFAULT ''::character varying,
    ldap_auth_source_id bigint,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    type character varying,
    identity_url character varying,
    first_login boolean DEFAULT true NOT NULL,
    force_password_change boolean DEFAULT false,
    failed_login_count integer DEFAULT 0,
    last_failed_login_on timestamp with time zone,
    consented_at timestamp with time zone,
    webauthn_id character varying
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: version_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.version_settings (
    id bigint NOT NULL,
    project_id bigint,
    version_id bigint,
    display integer,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: version_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.version_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: version_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.version_settings_id_seq OWNED BY public.version_settings.id;


--
-- Name: versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.versions (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    name character varying DEFAULT ''::character varying NOT NULL COLLATE public.versions_name,
    description character varying DEFAULT ''::character varying,
    effective_date date,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    wiki_page_title character varying,
    status character varying DEFAULT 'open'::character varying,
    sharing character varying DEFAULT 'none'::character varying NOT NULL,
    start_date date
);


--
-- Name: versions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.versions_id_seq OWNED BY public.versions.id;


--
-- Name: views; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.views (
    id bigint NOT NULL,
    query_id bigint NOT NULL,
    options jsonb DEFAULT '{}'::jsonb NOT NULL,
    type character varying NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: views_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.views_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: views_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.views_id_seq OWNED BY public.views.id;


--
-- Name: watchers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.watchers (
    id bigint NOT NULL,
    watchable_type character varying DEFAULT ''::character varying NOT NULL,
    watchable_id bigint NOT NULL,
    user_id bigint
);


--
-- Name: watchers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.watchers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: watchers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.watchers_id_seq OWNED BY public.watchers.id;


--
-- Name: webhooks_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks_events (
    id bigint NOT NULL,
    name character varying,
    webhooks_webhook_id bigint
);


--
-- Name: webhooks_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.webhooks_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: webhooks_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.webhooks_events_id_seq OWNED BY public.webhooks_events.id;


--
-- Name: webhooks_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks_logs (
    id bigint NOT NULL,
    webhooks_webhook_id bigint,
    event_name character varying,
    url character varying,
    request_headers text,
    request_body text,
    response_code integer,
    response_headers text,
    response_body text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: webhooks_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.webhooks_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: webhooks_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.webhooks_logs_id_seq OWNED BY public.webhooks_logs.id;


--
-- Name: webhooks_projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks_projects (
    id bigint NOT NULL,
    project_id bigint,
    webhooks_webhook_id bigint
);


--
-- Name: webhooks_projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.webhooks_projects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: webhooks_projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.webhooks_projects_id_seq OWNED BY public.webhooks_projects.id;


--
-- Name: webhooks_webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks_webhooks (
    id bigint NOT NULL,
    name character varying,
    url text,
    description text NOT NULL,
    secret character varying,
    enabled boolean NOT NULL,
    all_projects boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: webhooks_webhooks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.webhooks_webhooks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: webhooks_webhooks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.webhooks_webhooks_id_seq OWNED BY public.webhooks_webhooks.id;


--
-- Name: wiki_page_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wiki_page_journals (
    id bigint NOT NULL,
    author_id bigint,
    text text
);


--
-- Name: wiki_page_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wiki_page_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wiki_page_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wiki_page_journals_id_seq OWNED BY public.wiki_page_journals.id;


--
-- Name: wiki_pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wiki_pages (
    id bigint NOT NULL,
    wiki_id bigint NOT NULL,
    title character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    protected boolean DEFAULT false NOT NULL,
    parent_id bigint,
    slug character varying NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    author_id bigint NOT NULL,
    text text,
    lock_version integer NOT NULL
);


--
-- Name: wiki_pages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wiki_pages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wiki_pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wiki_pages_id_seq OWNED BY public.wiki_pages.id;


--
-- Name: wiki_redirects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wiki_redirects (
    id bigint NOT NULL,
    wiki_id bigint NOT NULL,
    title character varying,
    redirects_to character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: wiki_redirects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wiki_redirects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wiki_redirects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wiki_redirects_id_seq OWNED BY public.wiki_redirects.id;


--
-- Name: wikis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wikis (
    id bigint NOT NULL,
    project_id bigint NOT NULL,
    start_page character varying NOT NULL,
    status integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- Name: wikis_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.wikis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: wikis_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.wikis_id_seq OWNED BY public.wikis.id;


--
-- Name: work_package_hierarchies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_package_hierarchies (
    ancestor_id integer NOT NULL,
    descendant_id integer NOT NULL,
    generations integer NOT NULL
);


--
-- Name: work_package_journals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_package_journals (
    id bigint NOT NULL,
    type_id bigint NOT NULL,
    project_id bigint NOT NULL,
    subject character varying NOT NULL,
    description text,
    due_date date,
    category_id bigint,
    status_id bigint NOT NULL,
    assigned_to_id bigint,
    priority_id bigint NOT NULL,
    version_id bigint,
    author_id bigint NOT NULL,
    done_ratio integer,
    estimated_hours double precision,
    start_date date,
    parent_id bigint,
    responsible_id bigint,
    derived_estimated_hours double precision,
    schedule_manually boolean,
    duration integer,
    ignore_non_working_days boolean NOT NULL,
    derived_remaining_hours double precision,
    derived_done_ratio integer,
    story_points integer,
    remaining_hours double precision,
    budget_id integer,
    project_phase_definition_id bigint
);


--
-- Name: work_package_journals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_package_journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_package_journals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_package_journals_id_seq OWNED BY public.work_package_journals.id;


--
-- Name: work_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_packages (
    id bigint NOT NULL,
    type_id bigint NOT NULL,
    project_id bigint NOT NULL,
    subject character varying DEFAULT ''::character varying NOT NULL,
    description text,
    due_date date,
    category_id bigint,
    status_id bigint NOT NULL,
    assigned_to_id bigint,
    priority_id bigint,
    version_id bigint,
    author_id bigint NOT NULL,
    lock_version integer DEFAULT 0 NOT NULL,
    done_ratio integer,
    estimated_hours double precision,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    start_date date,
    responsible_id bigint,
    derived_estimated_hours double precision,
    schedule_manually boolean DEFAULT true NOT NULL,
    parent_id bigint,
    duration integer,
    ignore_non_working_days boolean DEFAULT false NOT NULL,
    derived_remaining_hours double precision,
    derived_done_ratio integer,
    "position" integer,
    story_points integer,
    remaining_hours double precision,
    budget_id integer,
    project_phase_definition_id bigint,
    CONSTRAINT work_packages_due_larger_start_date CHECK ((due_date >= start_date))
);


--
-- Name: work_packages_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.work_packages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: work_packages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.work_packages_id_seq OWNED BY public.work_packages.id;


--
-- Name: workflows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflows (
    id bigint NOT NULL,
    type_id bigint NOT NULL,
    old_status_id bigint NOT NULL,
    new_status_id bigint NOT NULL,
    role_id bigint NOT NULL,
    assignee boolean DEFAULT false NOT NULL,
    author boolean DEFAULT false NOT NULL
);


--
-- Name: workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.workflows_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.workflows_id_seq OWNED BY public.workflows.id;


--
-- Name: announcements id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements ALTER COLUMN id SET DEFAULT nextval('public.announcements_id_seq'::regclass);


--
-- Name: attachable_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachable_journals ALTER COLUMN id SET DEFAULT nextval('public.attachable_journals_id_seq'::regclass);


--
-- Name: attachment_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachment_journals ALTER COLUMN id SET DEFAULT nextval('public.attachment_journals_id_seq'::regclass);


--
-- Name: attachments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments ALTER COLUMN id SET DEFAULT nextval('public.attachments_id_seq'::regclass);


--
-- Name: attribute_help_texts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute_help_texts ALTER COLUMN id SET DEFAULT nextval('public.attribute_help_texts_id_seq'::regclass);


--
-- Name: auth_providers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_providers ALTER COLUMN id SET DEFAULT nextval('public.auth_providers_id_seq'::regclass);


--
-- Name: autologin_session_links id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.autologin_session_links ALTER COLUMN id SET DEFAULT nextval('public.autologin_session_links_id_seq'::regclass);


--
-- Name: bcf_comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_comments ALTER COLUMN id SET DEFAULT nextval('public.bcf_comments_id_seq'::regclass);


--
-- Name: bcf_issues id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_issues ALTER COLUMN id SET DEFAULT nextval('public.bcf_issues_id_seq'::regclass);


--
-- Name: bcf_viewpoints id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_viewpoints ALTER COLUMN id SET DEFAULT nextval('public.bcf_viewpoints_id_seq'::regclass);


--
-- Name: budget_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_journals ALTER COLUMN id SET DEFAULT nextval('public.budget_journals_id_seq'::regclass);


--
-- Name: budgets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budgets ALTER COLUMN id SET DEFAULT nextval('public.budgets_id_seq'::regclass);


--
-- Name: calculated_value_errors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calculated_value_errors ALTER COLUMN id SET DEFAULT nextval('public.calculated_value_errors_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: changes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changes ALTER COLUMN id SET DEFAULT nextval('public.changes_id_seq'::regclass);


--
-- Name: changeset_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changeset_journals ALTER COLUMN id SET DEFAULT nextval('public.changeset_journals_id_seq'::regclass);


--
-- Name: changesets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changesets ALTER COLUMN id SET DEFAULT nextval('public.changesets_id_seq'::regclass);


--
-- Name: colors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colors ALTER COLUMN id SET DEFAULT nextval('public.colors_id_seq'::regclass);


--
-- Name: comments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments ALTER COLUMN id SET DEFAULT nextval('public.comments_id_seq'::regclass);


--
-- Name: cost_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_entries ALTER COLUMN id SET DEFAULT nextval('public.cost_entries_id_seq'::regclass);


--
-- Name: cost_queries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_queries ALTER COLUMN id SET DEFAULT nextval('public.cost_queries_id_seq'::regclass);


--
-- Name: cost_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_types ALTER COLUMN id SET DEFAULT nextval('public.cost_types_id_seq'::regclass);


--
-- Name: custom_actions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions ALTER COLUMN id SET DEFAULT nextval('public.custom_actions_id_seq'::regclass);


--
-- Name: custom_actions_projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_projects ALTER COLUMN id SET DEFAULT nextval('public.custom_actions_projects_id_seq'::regclass);


--
-- Name: custom_actions_roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_roles ALTER COLUMN id SET DEFAULT nextval('public.custom_actions_roles_id_seq'::regclass);


--
-- Name: custom_actions_statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_statuses ALTER COLUMN id SET DEFAULT nextval('public.custom_actions_statuses_id_seq'::regclass);


--
-- Name: custom_actions_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_types ALTER COLUMN id SET DEFAULT nextval('public.custom_actions_types_id_seq'::regclass);


--
-- Name: custom_field_sections id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_field_sections ALTER COLUMN id SET DEFAULT nextval('public.custom_field_sections_id_seq'::regclass);


--
-- Name: custom_fields id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_fields ALTER COLUMN id SET DEFAULT nextval('public.custom_fields_id_seq'::regclass);


--
-- Name: custom_fields_projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_fields_projects ALTER COLUMN id SET DEFAULT nextval('public.custom_fields_projects_id_seq'::regclass);


--
-- Name: custom_fields_roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_fields_roles ALTER COLUMN id SET DEFAULT nextval('public.custom_fields_roles_id_seq'::regclass);


--
-- Name: custom_options id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_options ALTER COLUMN id SET DEFAULT nextval('public.custom_options_id_seq'::regclass);


--
-- Name: custom_styles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_styles ALTER COLUMN id SET DEFAULT nextval('public.custom_styles_id_seq'::regclass);


--
-- Name: custom_values id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_values ALTER COLUMN id SET DEFAULT nextval('public.custom_values_id_seq'::regclass);


--
-- Name: customizable_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customizable_journals ALTER COLUMN id SET DEFAULT nextval('public.customizable_journals_id_seq'::regclass);


--
-- Name: deploy_status_checks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deploy_status_checks ALTER COLUMN id SET DEFAULT nextval('public.deploy_status_checks_id_seq'::regclass);


--
-- Name: deploy_targets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deploy_targets ALTER COLUMN id SET DEFAULT nextval('public.deploy_targets_id_seq'::regclass);


--
-- Name: design_colors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.design_colors ALTER COLUMN id SET DEFAULT nextval('public.design_colors_id_seq'::regclass);


--
-- Name: document_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_journals ALTER COLUMN id SET DEFAULT nextval('public.document_journals_id_seq'::regclass);


--
-- Name: document_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_types ALTER COLUMN id SET DEFAULT nextval('public.document_types_id_seq'::regclass);


--
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- Name: emoji_reactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.emoji_reactions ALTER COLUMN id SET DEFAULT nextval('public.emoji_reactions_id_seq'::regclass);


--
-- Name: enabled_modules id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enabled_modules ALTER COLUMN id SET DEFAULT nextval('public.enabled_modules_id_seq'::regclass);


--
-- Name: enterprise_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enterprise_tokens ALTER COLUMN id SET DEFAULT nextval('public.enterprise_tokens_id_seq'::regclass);


--
-- Name: enumerations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enumerations ALTER COLUMN id SET DEFAULT nextval('public.enumerations_id_seq'::regclass);


--
-- Name: export_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.export_settings ALTER COLUMN id SET DEFAULT nextval('public.export_settings_id_seq'::regclass);


--
-- Name: exports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exports ALTER COLUMN id SET DEFAULT nextval('public.exports_id_seq'::regclass);


--
-- Name: favorites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorites ALTER COLUMN id SET DEFAULT nextval('public.favorites_id_seq'::regclass);


--
-- Name: file_links id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_links ALTER COLUMN id SET DEFAULT nextval('public.file_links_id_seq'::regclass);


--
-- Name: forums id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forums ALTER COLUMN id SET DEFAULT nextval('public.forums_id_seq'::regclass);


--
-- Name: github_check_runs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_check_runs ALTER COLUMN id SET DEFAULT nextval('public.github_check_runs_id_seq'::regclass);


--
-- Name: github_pull_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_pull_requests ALTER COLUMN id SET DEFAULT nextval('public.github_pull_requests_id_seq'::regclass);


--
-- Name: github_users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_users ALTER COLUMN id SET DEFAULT nextval('public.github_users_id_seq'::regclass);


--
-- Name: gitlab_issues id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gitlab_issues ALTER COLUMN id SET DEFAULT nextval('public.gitlab_issues_id_seq'::regclass);


--
-- Name: gitlab_merge_requests id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gitlab_merge_requests ALTER COLUMN id SET DEFAULT nextval('public.gitlab_merge_requests_id_seq'::regclass);


--
-- Name: gitlab_pipelines id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gitlab_pipelines ALTER COLUMN id SET DEFAULT nextval('public.gitlab_pipelines_id_seq'::regclass);


--
-- Name: gitlab_users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gitlab_users ALTER COLUMN id SET DEFAULT nextval('public.gitlab_users_id_seq'::regclass);


--
-- Name: grid_widgets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grid_widgets ALTER COLUMN id SET DEFAULT nextval('public.grid_widgets_id_seq'::regclass);


--
-- Name: grids id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grids ALTER COLUMN id SET DEFAULT nextval('public.grids_id_seq'::regclass);


--
-- Name: group_users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_users ALTER COLUMN id SET DEFAULT nextval('public.group_users_id_seq'::regclass);


--
-- Name: hierarchical_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hierarchical_items ALTER COLUMN id SET DEFAULT nextval('public.hierarchical_items_id_seq'::regclass);


--
-- Name: ical_token_query_assignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ical_token_query_assignments ALTER COLUMN id SET DEFAULT nextval('public.ical_token_query_assignments_id_seq'::regclass);


--
-- Name: ifc_models id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ifc_models ALTER COLUMN id SET DEFAULT nextval('public.ifc_models_id_seq'::regclass);


--
-- Name: job_statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_statuses ALTER COLUMN id SET DEFAULT nextval('public.job_statuses_id_seq'::regclass);


--
-- Name: journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journals ALTER COLUMN id SET DEFAULT nextval('public.journals_id_seq'::regclass);


--
-- Name: labor_budget_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.labor_budget_items ALTER COLUMN id SET DEFAULT nextval('public.labor_budget_items_id_seq'::regclass);


--
-- Name: last_project_folders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.last_project_folders ALTER COLUMN id SET DEFAULT nextval('public.last_project_folders_id_seq'::regclass);


--
-- Name: ldap_auth_sources id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_auth_sources ALTER COLUMN id SET DEFAULT nextval('public.ldap_auth_sources_id_seq'::regclass);


--
-- Name: ldap_groups_memberships id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_groups_memberships ALTER COLUMN id SET DEFAULT nextval('public.ldap_groups_memberships_id_seq'::regclass);


--
-- Name: ldap_groups_synchronized_filters id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_groups_synchronized_filters ALTER COLUMN id SET DEFAULT nextval('public.ldap_groups_synchronized_filters_id_seq'::regclass);


--
-- Name: ldap_groups_synchronized_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_groups_synchronized_groups ALTER COLUMN id SET DEFAULT nextval('public.ldap_groups_synchronized_groups_id_seq'::regclass);


--
-- Name: material_budget_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_budget_items ALTER COLUMN id SET DEFAULT nextval('public.material_budget_items_id_seq'::regclass);


--
-- Name: mcp_configurations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_configurations ALTER COLUMN id SET DEFAULT nextval('public.mcp_configurations_id_seq'::regclass);


--
-- Name: meeting_agenda_item_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_agenda_item_journals ALTER COLUMN id SET DEFAULT nextval('public.meeting_agenda_item_journals_id_seq'::regclass);


--
-- Name: meeting_agenda_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_agenda_items ALTER COLUMN id SET DEFAULT nextval('public.meeting_agenda_items_id_seq'::regclass);


--
-- Name: meeting_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_journals ALTER COLUMN id SET DEFAULT nextval('public.meeting_journals_id_seq'::regclass);


--
-- Name: meeting_outcomes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_outcomes ALTER COLUMN id SET DEFAULT nextval('public.meeting_outcomes_id_seq'::regclass);


--
-- Name: meeting_participants id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_participants ALTER COLUMN id SET DEFAULT nextval('public.meeting_participants_id_seq'::regclass);


--
-- Name: meeting_sections id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_sections ALTER COLUMN id SET DEFAULT nextval('public.meeting_sections_id_seq'::regclass);


--
-- Name: meetings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meetings ALTER COLUMN id SET DEFAULT nextval('public.meetings_id_seq'::regclass);


--
-- Name: member_roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_roles ALTER COLUMN id SET DEFAULT nextval('public.member_roles_id_seq'::regclass);


--
-- Name: members id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members ALTER COLUMN id SET DEFAULT nextval('public.members_id_seq'::regclass);


--
-- Name: menu_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_items ALTER COLUMN id SET DEFAULT nextval('public.menu_items_id_seq'::regclass);


--
-- Name: message_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_journals ALTER COLUMN id SET DEFAULT nextval('public.message_journals_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: news id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.news ALTER COLUMN id SET DEFAULT nextval('public.news_id_seq'::regclass);


--
-- Name: news_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.news_journals ALTER COLUMN id SET DEFAULT nextval('public.news_journals_id_seq'::regclass);


--
-- Name: non_working_days id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.non_working_days ALTER COLUMN id SET DEFAULT nextval('public.non_working_days_id_seq'::regclass);


--
-- Name: notification_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_settings ALTER COLUMN id SET DEFAULT nextval('public.notification_settings_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: oauth_access_grants id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_grants ALTER COLUMN id SET DEFAULT nextval('public.oauth_access_grants_id_seq'::regclass);


--
-- Name: oauth_access_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.oauth_access_tokens_id_seq'::regclass);


--
-- Name: oauth_applications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_applications ALTER COLUMN id SET DEFAULT nextval('public.oauth_applications_id_seq'::regclass);


--
-- Name: oauth_client_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client_tokens ALTER COLUMN id SET DEFAULT nextval('public.oauth_client_tokens_id_seq'::regclass);


--
-- Name: oauth_clients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_clients ALTER COLUMN id SET DEFAULT nextval('public.oauth_clients_id_seq'::regclass);


--
-- Name: oidc_group_links id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_group_links ALTER COLUMN id SET DEFAULT nextval('public.oidc_group_links_id_seq'::regclass);


--
-- Name: oidc_group_memberships id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_group_memberships ALTER COLUMN id SET DEFAULT nextval('public.oidc_group_memberships_id_seq'::regclass);


--
-- Name: oidc_user_session_links id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_user_session_links ALTER COLUMN id SET DEFAULT nextval('public.oidc_user_session_links_id_seq'::regclass);


--
-- Name: oidc_user_tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_user_tokens ALTER COLUMN id SET DEFAULT nextval('public.oidc_user_tokens_id_seq'::regclass);


--
-- Name: ordered_work_packages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordered_work_packages ALTER COLUMN id SET DEFAULT nextval('public.ordered_work_packages_id_seq'::regclass);


--
-- Name: paper_trail_audits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paper_trail_audits ALTER COLUMN id SET DEFAULT nextval('public.paper_trail_audits_id_seq'::regclass);


--
-- Name: project_custom_field_project_mappings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_custom_field_project_mappings ALTER COLUMN id SET DEFAULT nextval('public.project_custom_field_project_mappings_id_seq'::regclass);


--
-- Name: project_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_journals ALTER COLUMN id SET DEFAULT nextval('public.project_journals_id_seq'::regclass);


--
-- Name: project_phase_definitions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_phase_definitions ALTER COLUMN id SET DEFAULT nextval('public.project_phase_definitions_id_seq'::regclass);


--
-- Name: project_phase_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_phase_journals ALTER COLUMN id SET DEFAULT nextval('public.project_phase_journals_id_seq'::regclass);


--
-- Name: project_phases id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_phases ALTER COLUMN id SET DEFAULT nextval('public.project_phases_id_seq'::regclass);


--
-- Name: project_queries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_queries ALTER COLUMN id SET DEFAULT nextval('public.project_queries_id_seq'::regclass);


--
-- Name: project_storages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_storages ALTER COLUMN id SET DEFAULT nextval('public.project_storages_id_seq'::regclass);


--
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: queries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.queries ALTER COLUMN id SET DEFAULT nextval('public.queries_id_seq'::regclass);


--
-- Name: rates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rates ALTER COLUMN id SET DEFAULT nextval('public.rates_id_seq'::regclass);


--
-- Name: recaptcha_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recaptcha_entries ALTER COLUMN id SET DEFAULT nextval('public.recaptcha_entries_id_seq'::regclass);


--
-- Name: recurring_meeting_interim_responses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recurring_meeting_interim_responses ALTER COLUMN id SET DEFAULT nextval('public.recurring_meeting_interim_responses_id_seq'::regclass);


--
-- Name: recurring_meetings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recurring_meetings ALTER COLUMN id SET DEFAULT nextval('public.recurring_meetings_id_seq'::regclass);


--
-- Name: relations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relations ALTER COLUMN id SET DEFAULT nextval('public.relations_id_seq'::regclass);


--
-- Name: reminder_notifications id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reminder_notifications ALTER COLUMN id SET DEFAULT nextval('public.reminder_notifications_id_seq'::regclass);


--
-- Name: reminders id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reminders ALTER COLUMN id SET DEFAULT nextval('public.reminders_id_seq'::regclass);


--
-- Name: remote_identities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remote_identities ALTER COLUMN id SET DEFAULT nextval('public.remote_identities_id_seq'::regclass);


--
-- Name: repositories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositories ALTER COLUMN id SET DEFAULT nextval('public.repositories_id_seq'::regclass);


--
-- Name: role_permissions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions ALTER COLUMN id SET DEFAULT nextval('public.role_permissions_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: scheduled_meetings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_meetings ALTER COLUMN id SET DEFAULT nextval('public.scheduled_meetings_id_seq'::regclass);


--
-- Name: scim_clients id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scim_clients ALTER COLUMN id SET DEFAULT nextval('public.scim_clients_id_seq'::regclass);


--
-- Name: service_account_associations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_account_associations ALTER COLUMN id SET DEFAULT nextval('public.service_account_associations_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statuses ALTER COLUMN id SET DEFAULT nextval('public.statuses_id_seq'::regclass);


--
-- Name: storages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storages ALTER COLUMN id SET DEFAULT nextval('public.storages_id_seq'::regclass);


--
-- Name: storages_file_links_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storages_file_links_journals ALTER COLUMN id SET DEFAULT nextval('public.storages_file_links_journals_id_seq'::regclass);


--
-- Name: subproject_template_assignments id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subproject_template_assignments ALTER COLUMN id SET DEFAULT nextval('public.subproject_template_assignments_id_seq'::regclass);


--
-- Name: time_entries id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries ALTER COLUMN id SET DEFAULT nextval('public.time_entries_id_seq'::regclass);


--
-- Name: time_entry_activities_projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entry_activities_projects ALTER COLUMN id SET DEFAULT nextval('public.time_entry_activities_projects_id_seq'::regclass);


--
-- Name: time_entry_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entry_journals ALTER COLUMN id SET DEFAULT nextval('public.time_entry_journals_id_seq'::regclass);


--
-- Name: tokens id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens ALTER COLUMN id SET DEFAULT nextval('public.tokens_id_seq'::regclass);


--
-- Name: two_factor_authentication_devices id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.two_factor_authentication_devices ALTER COLUMN id SET DEFAULT nextval('public.two_factor_authentication_devices_id_seq'::regclass);


--
-- Name: types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.types ALTER COLUMN id SET DEFAULT nextval('public.types_id_seq'::regclass);


--
-- Name: user_auth_provider_links id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_auth_provider_links ALTER COLUMN id SET DEFAULT nextval('public.user_auth_provider_links_id_seq'::regclass);


--
-- Name: user_passwords id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_passwords ALTER COLUMN id SET DEFAULT nextval('public.user_passwords_id_seq'::regclass);


--
-- Name: user_preferences id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_preferences ALTER COLUMN id SET DEFAULT nextval('public.user_preferences_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: version_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version_settings ALTER COLUMN id SET DEFAULT nextval('public.version_settings_id_seq'::regclass);


--
-- Name: versions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.versions ALTER COLUMN id SET DEFAULT nextval('public.versions_id_seq'::regclass);


--
-- Name: views id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.views ALTER COLUMN id SET DEFAULT nextval('public.views_id_seq'::regclass);


--
-- Name: watchers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchers ALTER COLUMN id SET DEFAULT nextval('public.watchers_id_seq'::regclass);


--
-- Name: webhooks_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_events ALTER COLUMN id SET DEFAULT nextval('public.webhooks_events_id_seq'::regclass);


--
-- Name: webhooks_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_logs ALTER COLUMN id SET DEFAULT nextval('public.webhooks_logs_id_seq'::regclass);


--
-- Name: webhooks_projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_projects ALTER COLUMN id SET DEFAULT nextval('public.webhooks_projects_id_seq'::regclass);


--
-- Name: webhooks_webhooks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_webhooks ALTER COLUMN id SET DEFAULT nextval('public.webhooks_webhooks_id_seq'::regclass);


--
-- Name: wiki_page_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_page_journals ALTER COLUMN id SET DEFAULT nextval('public.wiki_page_journals_id_seq'::regclass);


--
-- Name: wiki_pages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_pages ALTER COLUMN id SET DEFAULT nextval('public.wiki_pages_id_seq'::regclass);


--
-- Name: wiki_redirects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_redirects ALTER COLUMN id SET DEFAULT nextval('public.wiki_redirects_id_seq'::regclass);


--
-- Name: wikis id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wikis ALTER COLUMN id SET DEFAULT nextval('public.wikis_id_seq'::regclass);


--
-- Name: work_package_journals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_package_journals ALTER COLUMN id SET DEFAULT nextval('public.work_package_journals_id_seq'::regclass);


--
-- Name: work_packages id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_packages ALTER COLUMN id SET DEFAULT nextval('public.work_packages_id_seq'::regclass);


--
-- Name: workflows id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows ALTER COLUMN id SET DEFAULT nextval('public.workflows_id_seq'::regclass);


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.announcements (id, text, show_until, active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
environment	production	2026-04-10 07:15:43.600748+00	2026-04-10 07:15:43.600751+00
schema_sha1	59e112f95b4ee72b07af7d0a399c1fe06b3f3376	2026-04-10 07:15:43.605859+00	2026-04-10 07:15:43.605861+00
\.


--
-- Data for Name: attachable_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachable_journals (id, journal_id, attachment_id, filename) FROM stdin;
\.


--
-- Data for Name: attachment_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachment_journals (id, container_id, container_type, filename, disk_filename, filesize, content_type, digest, downloads, author_id, description) FROM stdin;
1	6	Grids::Grid			455768	image/png	2a53ddc815206499a480d08e38272b8a	0	4	\N
2	7	Grids::Grid			442579	image/png	7b7d591a8dfdaf2900ceecdb9755f39f	0	4	\N
\.


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachments (id, container_id, container_type, filename, disk_filename, filesize, content_type, digest, downloads, author_id, created_at, description, file, fulltext, fulltext_tsv, file_tsv, updated_at, status) FROM stdin;
1	6	Grids::Grid			455768	image/png	2a53ddc815206499a480d08e38272b8a	0	4	2026-04-10 07:16:18.437258+00	\N	demo_project_teaser.png	\N	\N	\N	2026-04-10 07:16:18.437258+00	0
2	7	Grids::Grid			442579	image/png	7b7d591a8dfdaf2900ceecdb9755f39f	0	4	2026-04-10 07:16:18.510751+00	\N	scrum_project_teaser.png	\N	\N	\N	2026-04-10 07:16:18.510751+00	0
\.


--
-- Data for Name: attribute_help_texts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attribute_help_texts (id, help_text, type, attribute_name, created_at, updated_at, caption) FROM stdin;
\.


--
-- Data for Name: auth_providers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_providers (id, type, display_name, slug, available, limit_self_registration, options, creator_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: autologin_session_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.autologin_session_links (id, token_id, session_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bcf_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bcf_comments (id, uuid, journal_id, issue_id, viewpoint_id, reply_to) FROM stdin;
\.


--
-- Data for Name: bcf_issues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bcf_issues (id, uuid, markup, work_package_id, stage, index, labels, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: bcf_viewpoints; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bcf_viewpoints (id, uuid, viewpoint_name, issue_id, json_viewpoint, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: budget_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budget_journals (id, project_id, author_id, subject, description, fixed_date, base_amount) FROM stdin;
\.


--
-- Data for Name: budgets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.budgets (id, project_id, author_id, subject, description, fixed_date, created_at, updated_at, base_amount) FROM stdin;
\.


--
-- Data for Name: calculated_value_errors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calculated_value_errors (id, customized_type, customized_id, custom_field_id, error_code, missing_custom_field_ids, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.categories (id, project_id, name, assigned_to_id, created_at, updated_at) FROM stdin;
1	1	Category 1 (to be changed in Project settings)	\N	2026-04-10 07:16:12.244812+00	2026-04-10 07:16:12.244812+00
2	2	Category 1 (to be changed in Project settings)	\N	2026-04-10 07:16:15.45998+00	2026-04-10 07:16:15.45998+00
\.


--
-- Data for Name: changes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.changes (id, changeset_id, action, path, from_path, from_revision, revision, branch) FROM stdin;
\.


--
-- Data for Name: changeset_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.changeset_journals (id, repository_id, revision, committer, committed_on, comments, commit_date, scmid, user_id) FROM stdin;
\.


--
-- Data for Name: changesets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.changesets (id, repository_id, revision, committer, committed_on, comments, commit_date, scmid, user_id) FROM stdin;
\.


--
-- Data for Name: changesets_work_packages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.changesets_work_packages (changeset_id, work_package_id) FROM stdin;
\.


--
-- Data for Name: colors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.colors (id, name, hexcode, created_at, updated_at) FROM stdin;
1	Blue (dark)	#175A8E	2026-04-10 07:16:07.789013+00	2026-04-10 07:16:07.789013+00
2	Blue	#1A67A3	2026-04-10 07:16:07.795065+00	2026-04-10 07:16:07.795065+00
3	Blue (light)	#00B0F0	2026-04-10 07:16:07.796083+00	2026-04-10 07:16:07.796083+00
4	Green (light)	#35C53F	2026-04-10 07:16:07.796918+00	2026-04-10 07:16:07.796918+00
5	Green (dark)	#339933	2026-04-10 07:16:07.797357+00	2026-04-10 07:16:07.797357+00
6	Yellow	#FFFF00	2026-04-10 07:16:07.797781+00	2026-04-10 07:16:07.797781+00
7	Orange	#FFCC00	2026-04-10 07:16:07.798196+00	2026-04-10 07:16:07.798196+00
8	Red	#FF3300	2026-04-10 07:16:07.798887+00	2026-04-10 07:16:07.798887+00
9	Magenta	#E20074	2026-04-10 07:16:07.799407+00	2026-04-10 07:16:07.799407+00
10	White	#FFFFFF	2026-04-10 07:16:07.799936+00	2026-04-10 07:16:07.799936+00
11	Grey (light)	#F8F8F8	2026-04-10 07:16:07.80047+00	2026-04-10 07:16:07.80047+00
12	Grey	#EAEAEA	2026-04-10 07:16:07.801024+00	2026-04-10 07:16:07.801024+00
13	Grey (dark)	#878787	2026-04-10 07:16:07.802397+00	2026-04-10 07:16:07.802397+00
14	Black	#000000	2026-04-10 07:16:07.803002+00	2026-04-10 07:16:07.803002+00
15	gray-0	#F8F9FA	2026-04-10 07:16:07.805142+00	2026-04-10 07:16:07.805142+00
16	gray-1	#F1F3F5	2026-04-10 07:16:07.805641+00	2026-04-10 07:16:07.805641+00
17	gray-2	#E9ECEF	2026-04-10 07:16:07.806065+00	2026-04-10 07:16:07.806065+00
18	gray-3	#DEE2E6	2026-04-10 07:16:07.806507+00	2026-04-10 07:16:07.806507+00
19	gray-4	#CED4DA	2026-04-10 07:16:07.806915+00	2026-04-10 07:16:07.806915+00
20	gray-5	#ADB5BD	2026-04-10 07:16:07.807339+00	2026-04-10 07:16:07.807339+00
21	gray-6	#868E96	2026-04-10 07:16:07.807848+00	2026-04-10 07:16:07.807848+00
22	gray-7	#495057	2026-04-10 07:16:07.808294+00	2026-04-10 07:16:07.808294+00
23	gray-8	#343A40	2026-04-10 07:16:07.808743+00	2026-04-10 07:16:07.808743+00
24	gray-9	#212529	2026-04-10 07:16:07.809248+00	2026-04-10 07:16:07.809248+00
25	red-0	#FFF5F5	2026-04-10 07:16:07.809728+00	2026-04-10 07:16:07.809728+00
26	red-1	#FFE3E3	2026-04-10 07:16:07.810469+00	2026-04-10 07:16:07.810469+00
27	red-2	#FFC9C9	2026-04-10 07:16:07.81099+00	2026-04-10 07:16:07.81099+00
28	red-3	#FFA8A8	2026-04-10 07:16:07.811567+00	2026-04-10 07:16:07.811567+00
29	red-4	#FF8787	2026-04-10 07:16:07.812101+00	2026-04-10 07:16:07.812101+00
30	red-5	#FF6B6B	2026-04-10 07:16:07.812935+00	2026-04-10 07:16:07.812935+00
31	red-6	#FA5252	2026-04-10 07:16:07.81343+00	2026-04-10 07:16:07.81343+00
32	red-7	#F03E3E	2026-04-10 07:16:07.813858+00	2026-04-10 07:16:07.813858+00
33	red-8	#E03131	2026-04-10 07:16:07.814806+00	2026-04-10 07:16:07.814806+00
34	red-9	#C92A2A	2026-04-10 07:16:07.81563+00	2026-04-10 07:16:07.81563+00
35	pink-0	#FFF0F6	2026-04-10 07:16:07.816373+00	2026-04-10 07:16:07.816373+00
36	pink-1	#FFDEEB	2026-04-10 07:16:07.816896+00	2026-04-10 07:16:07.816896+00
37	pink-2	#FCC2D7	2026-04-10 07:16:07.817373+00	2026-04-10 07:16:07.817373+00
38	pink-3	#FAA2C1	2026-04-10 07:16:07.818688+00	2026-04-10 07:16:07.818688+00
39	pink-4	#F783AC	2026-04-10 07:16:07.8208+00	2026-04-10 07:16:07.8208+00
40	pink-5	#F06595	2026-04-10 07:16:07.821343+00	2026-04-10 07:16:07.821343+00
41	pink-6	#E64980	2026-04-10 07:16:07.821945+00	2026-04-10 07:16:07.821945+00
42	pink-7	#D6336C	2026-04-10 07:16:07.822533+00	2026-04-10 07:16:07.822533+00
43	pink-8	#C2255C	2026-04-10 07:16:07.823087+00	2026-04-10 07:16:07.823087+00
44	pink-9	#A61E4D	2026-04-10 07:16:07.823608+00	2026-04-10 07:16:07.823608+00
45	grape-0	#F8F0FC	2026-04-10 07:16:07.824159+00	2026-04-10 07:16:07.824159+00
46	grape-1	#F3D9FA	2026-04-10 07:16:07.824594+00	2026-04-10 07:16:07.824594+00
47	grape-2	#EEBEFA	2026-04-10 07:16:07.825389+00	2026-04-10 07:16:07.825389+00
48	grape-3	#E599F7	2026-04-10 07:16:07.825834+00	2026-04-10 07:16:07.825834+00
49	grape-4	#DA77F2	2026-04-10 07:16:07.826398+00	2026-04-10 07:16:07.826398+00
50	grape-5	#CC5DE8	2026-04-10 07:16:07.826862+00	2026-04-10 07:16:07.826862+00
51	grape-6	#BE4BDB	2026-04-10 07:16:07.827317+00	2026-04-10 07:16:07.827317+00
52	grape-7	#AE3EC9	2026-04-10 07:16:07.827856+00	2026-04-10 07:16:07.827856+00
53	grape-8	#9C36B5	2026-04-10 07:16:07.828466+00	2026-04-10 07:16:07.828466+00
54	grape-9	#862E9C	2026-04-10 07:16:07.828932+00	2026-04-10 07:16:07.828932+00
55	violet-0	#F3F0FF	2026-04-10 07:16:07.829437+00	2026-04-10 07:16:07.829437+00
56	violet-1	#E5DBFF	2026-04-10 07:16:07.82986+00	2026-04-10 07:16:07.82986+00
57	violet-2	#D0BFFF	2026-04-10 07:16:07.83031+00	2026-04-10 07:16:07.83031+00
58	violet-3	#B197FC	2026-04-10 07:16:07.830807+00	2026-04-10 07:16:07.830807+00
59	violet-4	#9775FA	2026-04-10 07:16:07.831316+00	2026-04-10 07:16:07.831316+00
60	violet-5	#845EF7	2026-04-10 07:16:07.83223+00	2026-04-10 07:16:07.83223+00
61	violet-6	#7950F2	2026-04-10 07:16:07.832767+00	2026-04-10 07:16:07.832767+00
62	violet-7	#7048E8	2026-04-10 07:16:07.833229+00	2026-04-10 07:16:07.833229+00
63	violet-8	#6741D9	2026-04-10 07:16:07.833664+00	2026-04-10 07:16:07.833664+00
64	violet-9	#5F3DC4	2026-04-10 07:16:07.834079+00	2026-04-10 07:16:07.834079+00
65	indigo-0	#EDF2FF	2026-04-10 07:16:07.834518+00	2026-04-10 07:16:07.834518+00
66	indigo-1	#DBE4FF	2026-04-10 07:16:07.834929+00	2026-04-10 07:16:07.834929+00
67	indigo-2	#BAC8FF	2026-04-10 07:16:07.835336+00	2026-04-10 07:16:07.835336+00
68	indigo-3	#91A7FF	2026-04-10 07:16:07.836436+00	2026-04-10 07:16:07.836436+00
69	indigo-4	#748FFC	2026-04-10 07:16:07.836971+00	2026-04-10 07:16:07.836971+00
70	indigo-5	#5C7CFA	2026-04-10 07:16:07.837418+00	2026-04-10 07:16:07.837418+00
71	indigo-6	#4C6EF5	2026-04-10 07:16:07.837894+00	2026-04-10 07:16:07.837894+00
72	indigo-7	#4263EB	2026-04-10 07:16:07.838326+00	2026-04-10 07:16:07.838326+00
73	indigo-8	#3B5BDB	2026-04-10 07:16:07.838773+00	2026-04-10 07:16:07.838773+00
74	indigo-9	#364FC7	2026-04-10 07:16:07.839215+00	2026-04-10 07:16:07.839215+00
75	blue-0	#E7F5FF	2026-04-10 07:16:07.839666+00	2026-04-10 07:16:07.839666+00
76	blue-1	#D0EBFF	2026-04-10 07:16:07.840169+00	2026-04-10 07:16:07.840169+00
77	blue-2	#A5D8FF	2026-04-10 07:16:07.840612+00	2026-04-10 07:16:07.840612+00
78	blue-3	#74C0FC	2026-04-10 07:16:07.841013+00	2026-04-10 07:16:07.841013+00
79	blue-4	#4DABF7	2026-04-10 07:16:07.841412+00	2026-04-10 07:16:07.841412+00
80	blue-5	#339AF0	2026-04-10 07:16:07.841944+00	2026-04-10 07:16:07.841944+00
81	blue-6	#228BE6	2026-04-10 07:16:07.842435+00	2026-04-10 07:16:07.842435+00
82	blue-7	#1C7ED6	2026-04-10 07:16:07.843036+00	2026-04-10 07:16:07.843036+00
83	blue-8	#1971C2	2026-04-10 07:16:07.843495+00	2026-04-10 07:16:07.843495+00
84	blue-9	#1864AB	2026-04-10 07:16:07.843937+00	2026-04-10 07:16:07.843937+00
85	cyan-0	#E3FAFC	2026-04-10 07:16:07.844572+00	2026-04-10 07:16:07.844572+00
86	cyan-1	#C5F6FA	2026-04-10 07:16:07.844995+00	2026-04-10 07:16:07.844995+00
87	cyan-2	#99E9F2	2026-04-10 07:16:07.8454+00	2026-04-10 07:16:07.8454+00
88	cyan-3	#66D9E8	2026-04-10 07:16:07.845815+00	2026-04-10 07:16:07.845815+00
89	cyan-4	#3BC9DB	2026-04-10 07:16:07.846474+00	2026-04-10 07:16:07.846474+00
90	cyan-5	#22B8CF	2026-04-10 07:16:07.846931+00	2026-04-10 07:16:07.846931+00
91	cyan-6	#15AABF	2026-04-10 07:16:07.847466+00	2026-04-10 07:16:07.847466+00
92	cyan-7	#1098AD	2026-04-10 07:16:07.848114+00	2026-04-10 07:16:07.848114+00
93	cyan-8	#0C8599	2026-04-10 07:16:07.848747+00	2026-04-10 07:16:07.848747+00
94	cyan-9	#0B7285	2026-04-10 07:16:07.850187+00	2026-04-10 07:16:07.850187+00
95	teal-0	#E6FCF5	2026-04-10 07:16:07.851881+00	2026-04-10 07:16:07.851881+00
96	teal-1	#C3FAE8	2026-04-10 07:16:07.853815+00	2026-04-10 07:16:07.853815+00
97	teal-2	#96F2D7	2026-04-10 07:16:07.854559+00	2026-04-10 07:16:07.854559+00
98	teal-3	#63E6BE	2026-04-10 07:16:07.856131+00	2026-04-10 07:16:07.856131+00
99	teal-4	#38D9A9	2026-04-10 07:16:07.85769+00	2026-04-10 07:16:07.85769+00
100	teal-5	#20C997	2026-04-10 07:16:07.858327+00	2026-04-10 07:16:07.858327+00
101	teal-6	#12B886	2026-04-10 07:16:07.858833+00	2026-04-10 07:16:07.858833+00
102	teal-7	#0CA678	2026-04-10 07:16:07.861106+00	2026-04-10 07:16:07.861106+00
103	teal-8	#099268	2026-04-10 07:16:07.861732+00	2026-04-10 07:16:07.861732+00
104	teal-9	#087F5B	2026-04-10 07:16:07.862684+00	2026-04-10 07:16:07.862684+00
105	green-0	#EBFBEE	2026-04-10 07:16:07.863391+00	2026-04-10 07:16:07.863391+00
106	green-1	#D3F9D8	2026-04-10 07:16:07.863906+00	2026-04-10 07:16:07.863906+00
107	green-2	#B2F2BB	2026-04-10 07:16:07.864337+00	2026-04-10 07:16:07.864337+00
108	green-3	#8CE99A	2026-04-10 07:16:07.864781+00	2026-04-10 07:16:07.864781+00
109	green-4	#69DB7C	2026-04-10 07:16:07.86538+00	2026-04-10 07:16:07.86538+00
110	green-5	#51CF66	2026-04-10 07:16:07.865858+00	2026-04-10 07:16:07.865858+00
111	green-6	#40C057	2026-04-10 07:16:07.8663+00	2026-04-10 07:16:07.8663+00
112	green-7	#37B24D	2026-04-10 07:16:07.866733+00	2026-04-10 07:16:07.866733+00
113	green-8	#2F9E44	2026-04-10 07:16:07.867187+00	2026-04-10 07:16:07.867187+00
114	green-9	#2B8A3E	2026-04-10 07:16:07.867602+00	2026-04-10 07:16:07.867602+00
115	lime-0	#F4FCE3	2026-04-10 07:16:07.868108+00	2026-04-10 07:16:07.868108+00
116	lime-1	#E9FAC8	2026-04-10 07:16:07.868543+00	2026-04-10 07:16:07.868543+00
117	lime-2	#D8F5A2	2026-04-10 07:16:07.868954+00	2026-04-10 07:16:07.868954+00
118	lime-3	#C0EB75	2026-04-10 07:16:07.869359+00	2026-04-10 07:16:07.869359+00
119	lime-4	#A9E34B	2026-04-10 07:16:07.869997+00	2026-04-10 07:16:07.869997+00
120	lime-5	#94D82D	2026-04-10 07:16:07.872541+00	2026-04-10 07:16:07.872541+00
121	lime-6	#82C91E	2026-04-10 07:16:07.873059+00	2026-04-10 07:16:07.873059+00
122	lime-7	#74B816	2026-04-10 07:16:07.873519+00	2026-04-10 07:16:07.873519+00
123	lime-8	#66A80F	2026-04-10 07:16:07.873967+00	2026-04-10 07:16:07.873967+00
124	lime-9	#5C940D	2026-04-10 07:16:07.874397+00	2026-04-10 07:16:07.874397+00
125	yellow-0	#FFF9DB	2026-04-10 07:16:07.875185+00	2026-04-10 07:16:07.875185+00
126	yellow-1	#FFF3BF	2026-04-10 07:16:07.875638+00	2026-04-10 07:16:07.875638+00
127	yellow-2	#FFEC99	2026-04-10 07:16:07.876193+00	2026-04-10 07:16:07.876193+00
128	yellow-3	#FFE066	2026-04-10 07:16:07.876684+00	2026-04-10 07:16:07.876684+00
129	yellow-4	#FFD43B	2026-04-10 07:16:07.877267+00	2026-04-10 07:16:07.877267+00
130	yellow-5	#FCC419	2026-04-10 07:16:07.877697+00	2026-04-10 07:16:07.877697+00
131	yellow-6	#FAB005	2026-04-10 07:16:07.878258+00	2026-04-10 07:16:07.878258+00
132	yellow-7	#F59F00	2026-04-10 07:16:07.878771+00	2026-04-10 07:16:07.878771+00
133	yellow-8	#F08C00	2026-04-10 07:16:07.879209+00	2026-04-10 07:16:07.879209+00
134	yellow-9	#E67700	2026-04-10 07:16:07.879628+00	2026-04-10 07:16:07.879628+00
135	orange-0	#FFF4E6	2026-04-10 07:16:07.88007+00	2026-04-10 07:16:07.88007+00
136	orange-1	#FFE8CC	2026-04-10 07:16:07.880476+00	2026-04-10 07:16:07.880476+00
137	orange-2	#FFD8A8	2026-04-10 07:16:07.880909+00	2026-04-10 07:16:07.880909+00
138	orange-3	#FFC078	2026-04-10 07:16:07.881327+00	2026-04-10 07:16:07.881327+00
139	orange-4	#FFA94D	2026-04-10 07:16:07.881941+00	2026-04-10 07:16:07.881941+00
140	orange-5	#FF922B	2026-04-10 07:16:07.882655+00	2026-04-10 07:16:07.882655+00
141	orange-6	#FD7E14	2026-04-10 07:16:07.883206+00	2026-04-10 07:16:07.883206+00
142	orange-7	#F76707	2026-04-10 07:16:07.883651+00	2026-04-10 07:16:07.883651+00
143	orange-8	#E8590C	2026-04-10 07:16:07.884106+00	2026-04-10 07:16:07.884106+00
144	orange-9	#D9480F	2026-04-10 07:16:07.884662+00	2026-04-10 07:16:07.884662+00
145	PM2 Orange	#F7983A	2026-04-10 07:16:07.888548+00	2026-04-10 07:16:07.888548+00
146	PM2 Red	#F05823	2026-04-10 07:16:07.889214+00	2026-04-10 07:16:07.889214+00
147	PM2 Magenta	#EC038A	2026-04-10 07:16:07.889724+00	2026-04-10 07:16:07.889724+00
148	PM2 Green Yellow	#B1D13A	2026-04-10 07:16:07.890224+00	2026-04-10 07:16:07.890224+00
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comments (id, commented_type, commented_id, author_id, comments, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: cost_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_entries (id, user_id, project_id, work_package_id, cost_type_id, units, spent_on, created_at, updated_at, comments, blocked, overridden_costs, costs, rate_id, tyear, tmonth, tweek, logged_by_id, entity_type, entity_id) FROM stdin;
\.


--
-- Data for Name: cost_queries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_queries (id, user_id, project_id, name, is_public, created_at, updated_at, serialized) FROM stdin;
\.


--
-- Data for Name: cost_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_types (id, name, unit, unit_plural, "default", deleted_at) FROM stdin;
\.


--
-- Data for Name: custom_actions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_actions (id, name, actions, description, "position") FROM stdin;
\.


--
-- Data for Name: custom_actions_projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_actions_projects (id, project_id, custom_action_id) FROM stdin;
\.


--
-- Data for Name: custom_actions_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_actions_roles (id, role_id, custom_action_id) FROM stdin;
\.


--
-- Data for Name: custom_actions_statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_actions_statuses (id, status_id, custom_action_id) FROM stdin;
\.


--
-- Data for Name: custom_actions_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_actions_types (id, type_id, custom_action_id) FROM stdin;
\.


--
-- Data for Name: custom_field_sections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_field_sections (id, "position", name, type, created_at, updated_at, display_representation) FROM stdin;
1	1	Project attributes	ProjectCustomFieldSection	2026-04-10 07:16:11.010227+00	2026-04-10 07:16:11.010227+00	{}
\.


--
-- Data for Name: custom_fields; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_fields (id, type, field_format, regexp, min_length, max_length, is_required, is_for_all, is_filter, "position", searchable, editable, admin_only, multi_value, default_value, name, created_at, updated_at, content_right_to_left, allow_non_open_versions, custom_field_section_id, position_in_custom_field_section, formula) FROM stdin;
\.


--
-- Data for Name: custom_fields_projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_fields_projects (id, custom_field_id, project_id) FROM stdin;
\.


--
-- Data for Name: custom_fields_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_fields_roles (id, custom_field_id, role_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: custom_fields_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_fields_types (custom_field_id, type_id) FROM stdin;
\.


--
-- Data for Name: custom_options; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_options (id, custom_field_id, "position", default_value, value, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: custom_styles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_styles (id, logo, created_at, updated_at, favicon, touch_icon, theme, theme_logo, export_logo, export_cover, export_cover_text_color, export_footer, export_font_regular, export_font_bold, export_font_italic, export_font_bold_italic, logo_mobile) FROM stdin;
\.


--
-- Data for Name: custom_values; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_values (id, customized_type, customized_id, custom_field_id, value) FROM stdin;
\.


--
-- Data for Name: customizable_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customizable_journals (id, journal_id, custom_field_id, value) FROM stdin;
\.


--
-- Data for Name: deploy_status_checks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.deploy_status_checks (id, deploy_target_id, github_pull_request_id, core_sha, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: deploy_targets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.deploy_targets (id, type, host, options, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: design_colors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.design_colors (id, variable, hexcode, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: document_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_journals (id, project_id, category_id, title, description, content_binary) FROM stdin;
\.


--
-- Data for Name: document_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_types (id, name, "position", is_default, created_at, updated_at, active, documents_count) FROM stdin;
1	Note	1	t	2026-04-10 07:16:11.099916+00	2026-04-10 07:16:11.099916+00	t	0
2	Idea	2	f	2026-04-10 07:16:11.109659+00	2026-04-10 07:16:11.109659+00	t	0
3	Proposal	3	f	2026-04-10 07:16:11.115875+00	2026-04-10 07:16:11.115875+00	t	0
4	Specification	4	f	2026-04-10 07:16:11.119617+00	2026-04-10 07:16:11.119617+00	t	0
5	Report	5	f	2026-04-10 07:16:11.122976+00	2026-04-10 07:16:11.122976+00	t	0
6	Documentation	6	f	2026-04-10 07:16:11.131023+00	2026-04-10 07:16:11.131023+00	t	0
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documents (id, project_id, category_id, title, description, created_at, updated_at, type_id, kind, content_binary) FROM stdin;
\.


--
-- Data for Name: done_statuses_for_project; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.done_statuses_for_project (project_id, status_id) FROM stdin;
\.


--
-- Data for Name: emoji_reactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.emoji_reactions (id, user_id, reactable_type, reactable_id, reaction, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: enabled_modules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.enabled_modules (id, project_id, name) FROM stdin;
1	1	work_package_tracking
2	1	news
3	1	gantt
4	1	wiki
5	1	board_view
6	1	team_planner_view
7	1	meetings
8	1	documents
9	2	backlogs
10	2	news
11	2	wiki
12	2	work_package_tracking
13	2	gantt
14	2	board_view
15	2	documents
16	3	calendar
17	3	board_view
18	3	work_package_tracking
19	3	gantt
20	3	news
21	3	costs
22	3	wiki
23	3	documents
24	3	reporting_module
25	3	backlogs
26	3	meetings
\.


--
-- Data for Name: enterprise_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.enterprise_tokens (id, encoded_token, created_at, updated_at, valid_from, valid_until) FROM stdin;
\.


--
-- Data for Name: enumerations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.enumerations (id, name, "position", is_default, type, active, project_id, parent_id, created_at, updated_at, color_id) FROM stdin;
1	Management	1	t	TimeEntryActivity	t	\N	\N	2026-04-10 07:16:07.716178+00	2026-04-10 07:16:07.716178+00	\N
2	Specification	2	f	TimeEntryActivity	t	\N	\N	2026-04-10 07:16:07.731178+00	2026-04-10 07:16:07.731178+00	\N
3	Development	3	f	TimeEntryActivity	t	\N	\N	2026-04-10 07:16:07.74261+00	2026-04-10 07:16:07.74261+00	\N
4	Testing	4	f	TimeEntryActivity	t	\N	\N	2026-04-10 07:16:07.750982+00	2026-04-10 07:16:07.750982+00	\N
5	Support	5	f	TimeEntryActivity	t	\N	\N	2026-04-10 07:16:07.759465+00	2026-04-10 07:16:07.759465+00	\N
6	Other	6	f	TimeEntryActivity	t	\N	\N	2026-04-10 07:16:07.769017+00	2026-04-10 07:16:07.769017+00	\N
7	Low	1	f	IssuePriority	t	\N	\N	2026-04-10 07:16:09.666798+00	2026-04-10 07:16:09.666798+00	86
8	Normal	2	t	IssuePriority	t	\N	\N	2026-04-10 07:16:09.685856+00	2026-04-10 07:16:09.685856+00	78
9	High	3	f	IssuePriority	t	\N	\N	2026-04-10 07:16:09.695935+00	2026-04-10 07:16:09.695935+00	132
10	Immediate	4	f	IssuePriority	t	\N	\N	2026-04-10 07:16:09.705551+00	2026-04-10 07:16:09.705551+00	50
\.


--
-- Data for Name: export_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.export_settings (id, query_id, format, settings, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: exports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.exports (id, created_at, updated_at, type) FROM stdin;
\.


--
-- Data for Name: favorites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.favorites (id, user_id, favorited_type, favorited_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: file_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file_links (id, storage_id, creator_id, container_id, container_type, origin_id, origin_name, origin_created_by_name, origin_last_modified_by_name, origin_mime_type, origin_created_at, origin_updated_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: forums; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.forums (id, project_id, name, description, "position", topics_count, messages_count, last_message_id) FROM stdin;
\.


--
-- Data for Name: github_check_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.github_check_runs (id, github_pull_request_id, github_id, github_html_url, app_id, github_app_owner_avatar_url, status, name, conclusion, output_title, output_summary, details_url, started_at, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: github_pull_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.github_pull_requests (id, github_user_id, merged_by_id, github_id, number, github_html_url, state, repository, github_updated_at, title, body, draft, merged, merged_at, comments_count, review_comments_count, additions_count, deletions_count, changed_files_count, labels, created_at, updated_at, repository_html_url, merge_commit_sha) FROM stdin;
\.


--
-- Data for Name: github_pull_requests_work_packages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.github_pull_requests_work_packages (github_pull_request_id, work_package_id) FROM stdin;
\.


--
-- Data for Name: github_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.github_users (id, github_id, github_login, github_html_url, github_avatar_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: gitlab_issues; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gitlab_issues (id, gitlab_user_id, gitlab_id, number, gitlab_html_url, state, repository, gitlab_updated_at, title, body, labels, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: gitlab_issues_work_packages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gitlab_issues_work_packages (gitlab_issue_id, work_package_id) FROM stdin;
\.


--
-- Data for Name: gitlab_merge_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gitlab_merge_requests (id, gitlab_user_id, merged_by_id, gitlab_id, number, gitlab_html_url, state, repository, gitlab_updated_at, title, body, draft, merged, merged_at, labels, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: gitlab_merge_requests_work_packages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gitlab_merge_requests_work_packages (gitlab_merge_request_id, work_package_id) FROM stdin;
\.


--
-- Data for Name: gitlab_pipelines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gitlab_pipelines (id, gitlab_merge_request_id, gitlab_id, gitlab_html_url, project_id, gitlab_user_avatar_url, status, name, details_url, ci_details, started_at, completed_at, created_at, updated_at, username, commit_id) FROM stdin;
\.


--
-- Data for Name: gitlab_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gitlab_users (id, gitlab_id, gitlab_name, gitlab_username, gitlab_email, gitlab_avatar_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: good_job_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.good_job_batches (id, created_at, updated_at, description, serialized_properties, on_finish, on_success, on_discard, callback_queue_name, callback_priority, enqueued_at, discarded_at, finished_at, jobs_finished_at) FROM stdin;
\.


--
-- Data for Name: good_job_executions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.good_job_executions (id, created_at, updated_at, active_job_id, job_class, queue_name, serialized_params, scheduled_at, finished_at, error, error_event, error_backtrace, process_id, duration) FROM stdin;
9cbd2aeb-507d-4702-a199-cfe1b7a24063	2026-05-04 08:15:00.086229+00	2026-05-04 08:15:00.130491+00	1dbd4ea4-f935-4d7a-8d20-fe9db1172439	Notifications::ScheduleDateAlertsNotificationsJob	default	{"job_id": "1dbd4ea4-f935-4d7a-8d20-fe9db1172439", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:15:00.029336734Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:15:00.029431+00	2026-05-04 08:15:00.129114+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.042888
530d8e75-6563-4fb8-8c3a-331fd2f099db	2026-05-04 08:15:00.163705+00	2026-05-04 08:15:00.210216+00	38fae816-30c6-4156-985b-1cb3fd42bf0b	Notifications::ScheduleReminderMailsJob	default	{"job_id": "38fae816-30c6-4156-985b-1cb3fd42bf0b", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:15:00.060695732Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:15:00.060795+00	2026-05-04 08:15:00.209829+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.046128
e09e5c60-2d0d-42ea-b69e-b152c3c6f427	2026-05-04 08:30:00.100144+00	2026-05-04 08:30:00.132434+00	fdbecbee-3b82-4e3a-8aa0-ffeaed5c9f96	Notifications::ScheduleDateAlertsNotificationsJob	default	{"job_id": "fdbecbee-3b82-4e3a-8aa0-ffeaed5c9f96", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:30:00.007617614Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:30:00.007625+00	2026-05-04 08:30:00.132146+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.032007
f2491d4a-5590-411e-9d37-8dc8053356c4	2026-05-04 08:30:00.109115+00	2026-05-04 08:30:00.130797+00	c4e1e7ca-f08e-4390-91d9-f9c575100236	LdapGroups::SynchronizationJob	default	{"job_id": "c4e1e7ca-f08e-4390-91d9-f9c575100236", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "LdapGroups::SynchronizationJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:30:00.030248356Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:30:00.030354+00	2026-05-04 08:30:00.130351+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.021242
d462c0ff-2cd1-4fbf-9332-d54f083779cb	2026-05-04 08:30:00.128123+00	2026-05-04 08:30:00.190517+00	71268512-38df-4982-8505-b9a75900af57	Notifications::ScheduleReminderMailsJob	default	{"job_id": "71268512-38df-4982-8505-b9a75900af57", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:30:00.056887100Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:30:00.056899+00	2026-05-04 08:30:00.189036+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.060918
9b6797bd-1f62-4c00-aa0e-00198c98f9d0	2026-05-04 08:45:00.033486+00	2026-05-04 08:45:00.046512+00	2c2e30d0-e344-46f1-9ed9-4d07b3a7325d	Notifications::ScheduleDateAlertsNotificationsJob	default	{"job_id": "2c2e30d0-e344-46f1-9ed9-4d07b3a7325d", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:45:00.005992564Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:45:00.005998+00	2026-05-04 08:45:00.046261+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.012777
91ea54e9-f148-4cda-8d35-28a43f41b6b2	2026-05-04 08:45:00.058173+00	2026-05-04 08:45:00.071507+00	19192ae2-68e1-4387-9687-0c10c4bca0ec	Notifications::ScheduleReminderMailsJob	default	{"job_id": "19192ae2-68e1-4387-9687-0c10c4bca0ec", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:45:00.022360347Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:45:00.022368+00	2026-05-04 08:45:00.071309+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.013136
759ebf3b-44b4-4a6f-bd9b-228ebb35d635	2026-05-04 09:00:00.076695+00	2026-05-04 09:00:00.095701+00	f33292c7-0189-4a2a-bc8e-3f429d58b437	Notifications::ScheduleDateAlertsNotificationsJob	default	{"job_id": "f33292c7-0189-4a2a-bc8e-3f429d58b437", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T09:00:00.004450993Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 09:00:00.004455+00	2026-05-04 09:00:00.095436+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.018742
3dca46eb-b606-4468-bcac-c220bedbbb62	2026-05-04 09:00:00.111994+00	2026-05-04 09:00:00.146135+00	039a6911-0ced-4764-9f2c-2539fa2f90e0	LdapGroups::SynchronizationJob	default	{"job_id": "039a6911-0ced-4764-9f2c-2539fa2f90e0", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "LdapGroups::SynchronizationJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T09:00:00.066249557Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 09:00:00.066254+00	2026-05-04 09:00:00.14582+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.033828
7aae9437-2da3-42fa-be74-6efaefcaedbb	2026-05-04 09:00:00.102007+00	2026-05-04 09:00:00.164353+00	157e6bb5-b3e7-424b-be9a-0184a4bd46cb	Notifications::ScheduleReminderMailsJob	default	{"job_id": "157e6bb5-b3e7-424b-be9a-0184a4bd46cb", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T09:00:00.055289914Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 09:00:00.055295+00	2026-05-04 09:00:00.16406+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.062058
708eb740-9844-405d-a93e-164c7f2074b7	2026-05-04 09:01:00.02164+00	2026-05-04 09:01:00.056573+00	564bb832-fe89-48af-a8a8-21231419f997	Storages::ManageStorageIntegrationsJob	default	{"job_id": "564bb832-fe89-48af-a8a8-21231419f997", "locale": "en", "priority": 7, "timezone": "UTC", "arguments": [], "job_class": "Storages::ManageStorageIntegrationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T09:01:00.007837870Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 09:01:00.007911+00	2026-05-04 09:01:00.056306+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.03467
f3081974-4643-461a-b472-52fe4798bcd2	2026-05-04 09:15:00.065066+00	2026-05-04 09:15:00.082733+00	15e6e993-4383-47bd-a568-b6ccb9d8191e	Notifications::ScheduleDateAlertsNotificationsJob	default	{"job_id": "15e6e993-4383-47bd-a568-b6ccb9d8191e", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T09:15:00.004748995Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 09:15:00.004755+00	2026-05-04 09:15:00.082315+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.017254
939a5bc6-0cdc-4a37-ab75-91a720de357f	2026-05-04 09:15:00.099448+00	2026-05-04 09:15:00.123408+00	6794f311-5766-4672-be3e-bb88e8ecf79b	Notifications::ScheduleReminderMailsJob	default	{"job_id": "6794f311-5766-4672-be3e-bb88e8ecf79b", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T09:15:00.052436214Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 09:15:00.052447+00	2026-05-04 09:15:00.123014+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.023571
267187ee-b76a-4149-bc18-a7caa199ba1d	2026-05-04 09:30:00.061298+00	2026-05-04 09:30:00.118486+00	08467658-4bb7-49c9-9ee8-f8ed7c4fa0ad	Notifications::ScheduleReminderMailsJob	default	{"job_id": "08467658-4bb7-49c9-9ee8-f8ed7c4fa0ad", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T09:30:00.004514474Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 09:30:00.004519+00	2026-05-04 09:30:00.118224+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.056929
d6231069-6e9a-493f-b1f0-68611221fde6	2026-05-04 08:00:00.210913+00	2026-05-04 08:00:00.233824+00	32cd93e8-6dde-4faa-87e0-f850f5e17dba	LdapGroups::SynchronizationJob	default	{"job_id": "32cd93e8-6dde-4faa-87e0-f850f5e17dba", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "LdapGroups::SynchronizationJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:00:00.094905872Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:00:00.09497+00	2026-05-04 08:00:00.233437+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.022529
84c8fbe3-6457-46e0-a011-899380499d6e	2026-05-04 09:30:00.079352+00	2026-05-04 09:30:00.115991+00	b09825d4-ade0-46d4-8781-f5f34a251d3e	Notifications::ScheduleDateAlertsNotificationsJob	default	{"job_id": "b09825d4-ade0-46d4-8781-f5f34a251d3e", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T09:30:00.016353358Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 09:30:00.016362+00	2026-05-04 09:30:00.115695+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.036315
08eea1d0-0a12-44a7-a210-a81460283f3a	2026-05-04 09:30:00.094414+00	2026-05-04 09:30:00.123915+00	d9181d01-1078-4041-8e1e-2fd9314a122b	LdapGroups::SynchronizationJob	default	{"job_id": "d9181d01-1078-4041-8e1e-2fd9314a122b", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "LdapGroups::SynchronizationJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T09:30:00.026330604Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 09:30:00.026338+00	2026-05-04 09:30:00.123701+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.029289
9602bccc-8b04-4211-ac8d-c371623b31c9	2026-05-04 09:45:00.059392+00	2026-05-04 09:45:00.095392+00	133c3af5-19a6-4f31-bf95-9ce435094430	Notifications::ScheduleReminderMailsJob	default	{"job_id": "133c3af5-19a6-4f31-bf95-9ce435094430", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T09:45:00.009673941Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 09:45:00.0097+00	2026-05-04 09:45:00.09476+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.035373
6b3d752f-8364-44df-b956-7bb1b07a3535	2026-05-04 09:45:00.119616+00	2026-05-04 09:45:00.154778+00	93fac2ce-341c-4bc9-b6f5-8bc59af28750	Notifications::ScheduleDateAlertsNotificationsJob	default	{"job_id": "93fac2ce-341c-4bc9-b6f5-8bc59af28750", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T09:45:00.045348699Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 09:45:00.045357+00	2026-05-04 09:45:00.154033+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.034422
6f824c7b-c95c-491d-980d-88dc3cf6e2df	2026-05-04 10:00:00.066853+00	2026-05-04 10:00:00.10786+00	f62cc22d-0f0b-4eb6-a01f-9ecb0346be79	Notifications::ScheduleReminderMailsJob	default	{"job_id": "f62cc22d-0f0b-4eb6-a01f-9ecb0346be79", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T10:00:00.006951359Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 10:00:00.006956+00	2026-05-04 10:00:00.107435+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.04059
d3937161-9a33-4f6c-b6e3-05bda591f1a7	2026-05-04 08:00:00.795531+00	2026-05-04 08:00:01.453179+00	ea5d868d-3578-435b-b7e8-fff0818b6ad4	Mails::ReminderJob	default	{"job_id": "ea5d868d-3578-435b-b7e8-fff0818b6ad4", "locale": "en", "priority": 5, "timezone": "UTC", "arguments": [5], "job_class": "Mails::ReminderJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:00:00.772235520Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:00:00.772587+00	2026-05-04 08:00:01.452741+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.657215
9eb5cab5-e989-41ad-b399-ff1174a555b2	2026-05-04 10:00:00.123445+00	2026-05-04 10:00:00.140443+00	08565e5d-cfc3-4727-bea9-8ccaad0d6de3	LdapGroups::SynchronizationJob	default	{"job_id": "08565e5d-cfc3-4727-bea9-8ccaad0d6de3", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "LdapGroups::SynchronizationJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T10:00:00.050061270Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 10:00:00.050066+00	2026-05-04 10:00:00.140168+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.016724
e09d48f7-d015-4520-9bfb-fa9749c39097	2026-05-04 10:00:00.109894+00	2026-05-04 10:00:00.139449+00	e58dd439-11f0-4a41-9da0-9d8895093396	Notifications::ScheduleDateAlertsNotificationsJob	default	{"job_id": "e58dd439-11f0-4a41-9da0-9d8895093396", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T10:00:00.024675461Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 10:00:00.024682+00	2026-05-04 10:00:00.139083+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.029175
84b3e331-2a79-4de8-a016-a2646cddc041	2026-05-04 10:01:00.033192+00	2026-05-04 10:01:00.053895+00	96fe6122-de86-4c8a-8402-b3b7888365f1	Storages::ManageStorageIntegrationsJob	default	{"job_id": "96fe6122-de86-4c8a-8402-b3b7888365f1", "locale": "en", "priority": 7, "timezone": "UTC", "arguments": [], "job_class": "Storages::ManageStorageIntegrationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T10:01:00.009262909Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 10:01:00.00927+00	2026-05-04 10:01:00.053547+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.020358
5c2ce02a-6777-4e3b-b3c3-91edb3fc2481	2026-05-04 10:15:00.665643+00	2026-05-04 10:15:00.700501+00	b23d8967-2adc-44ee-ba01-d7479d6e191e	Notifications::ScheduleDateAlertsNotificationsJob	default	{"job_id": "b23d8967-2adc-44ee-ba01-d7479d6e191e", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T10:15:00.006439007Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 10:15:00.006445+00	2026-05-04 10:15:00.700117+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.034477
a7ca2b0b-9958-4cb4-9899-d34513c75d6a	2026-05-04 10:15:00.729166+00	2026-05-04 10:15:00.801109+00	80bec2d9-90ee-4e08-ae36-b7b218c27720	Notifications::ScheduleReminderMailsJob	default	{"job_id": "80bec2d9-90ee-4e08-ae36-b7b218c27720", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T10:15:00.028484501Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 10:15:00.028491+00	2026-05-04 10:15:00.800747+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.071585
b682528f-5288-40dc-aba8-c68f183108f8	2026-05-04 10:30:00.073232+00	2026-05-04 10:30:00.095295+00	aa9846e0-5e40-4a12-9626-86798c80c186	Notifications::ScheduleDateAlertsNotificationsJob	default	{"job_id": "aa9846e0-5e40-4a12-9626-86798c80c186", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T10:30:00.008789005Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 10:30:00.008804+00	2026-05-04 10:30:00.094949+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.021723
50b27946-6b93-486d-a97e-cea231e0d92d	2026-05-04 10:30:00.109792+00	2026-05-04 10:30:00.133919+00	0ac429e7-e076-4351-9920-a66aab3f00e1	Notifications::ScheduleReminderMailsJob	default	{"job_id": "0ac429e7-e076-4351-9920-a66aab3f00e1", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T10:30:00.041211071Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 10:30:00.041223+00	2026-05-04 10:30:00.133628+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.023839
040ec786-0b3b-40d7-8d40-d965c066e3e4	2026-05-04 10:30:00.144156+00	2026-05-04 10:30:00.154512+00	f807f473-5231-4c79-83cf-bad418f55ee9	LdapGroups::SynchronizationJob	default	{"job_id": "f807f473-5231-4c79-83cf-bad418f55ee9", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "LdapGroups::SynchronizationJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T10:30:00.055699256Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 10:30:00.055715+00	2026-05-04 10:30:00.154289+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.010134
049be010-3f1d-4612-8b24-a6c0d6f9da51	2026-05-04 10:45:00.036384+00	2026-05-04 10:45:00.051848+00	311eecbf-df5b-4f2a-bae9-4d2c7fd07a17	Notifications::ScheduleReminderMailsJob	default	{"job_id": "311eecbf-df5b-4f2a-bae9-4d2c7fd07a17", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T10:45:00.004736556Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 10:45:00.004742+00	2026-05-04 10:45:00.051649+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.015266
d61d0687-9336-49c2-bfe4-e1f3ec53156e	2026-05-04 10:45:00.063762+00	2026-05-04 10:45:00.07687+00	059ae8f1-de26-4d55-8caa-9b3c60f5aa37	Notifications::ScheduleDateAlertsNotificationsJob	default	{"job_id": "059ae8f1-de26-4d55-8caa-9b3c60f5aa37", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T10:45:00.027509099Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 10:45:00.027516+00	2026-05-04 10:45:00.076646+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.012885
73c84c5d-5094-4ba3-8c2c-55fdab6295e5	2026-05-04 08:00:00.847883+00	2026-05-04 08:00:01.425467+00	ca92fadd-67e0-45f5-82cb-bed61b006629	Mails::ReminderJob	default	{"job_id": "ca92fadd-67e0-45f5-82cb-bed61b006629", "locale": "en", "priority": 5, "timezone": "UTC", "arguments": [7], "job_class": "Mails::ReminderJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:00:00.819575474Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:00:00.81958+00	2026-05-04 08:00:01.425215+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.577334
8dae6dcf-7bb3-4dab-848e-d4cf0a56f37a	2026-05-04 07:50:43.701763+00	2026-05-04 07:50:44.043289+00	81c8dd93-b277-4ade-a430-b27bf696af9c	RecurringMeetings::InitNextOccurrenceJob	default	{"job_id": "81c8dd93-b277-4ade-a430-b27bf696af9c", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [{"_aj_globalid": "gid://open-project/RecurringMeeting/1"}, {"value": "2026-04-27T19:16:14.917368000+02:00", "_aj_serialized": "ActiveJob::Serializers::TimeSerializer"}], "job_class": "RecurringMeetings::InitNextOccurrenceJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T07:50:43.612910235Z", "scheduled_at": "2026-04-20T17:16:14.917368000Z", "provider_job_id": null, "exception_executions": {}}	2026-04-20 17:16:14.917368+00	2026-05-04 07:50:44.042699+00	GoodJob::ActiveJobExtensions::Concurrency::ConcurrencyExceededError: GoodJob::ActiveJobExtensions::Concurrency::ConcurrencyExceededError	3	{}	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.340945
ca993b9c-e004-444a-8f8d-164d4920e803	2026-05-04 08:00:00.251184+00	2026-05-04 08:00:00.915806+00	811763e8-2d18-4744-9461-b8b2adde86fc	Notifications::ScheduleReminderMailsJob	default	{"job_id": "811763e8-2d18-4744-9461-b8b2adde86fc", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:00:00.136737464Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:00:00.136801+00	2026-05-04 08:00:00.91519+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.66401
28a91dc1-8043-4174-824a-3e125bbed384	2026-05-04 08:00:00.822683+00	2026-05-04 08:00:01.420503+00	17ee8bd2-54da-4182-b249-dfa320aa3185	Mails::ReminderJob	default	{"job_id": "17ee8bd2-54da-4182-b249-dfa320aa3185", "locale": "en", "priority": 5, "timezone": "UTC", "arguments": [6], "job_class": "Mails::ReminderJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:00:00.798890575Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:00:00.798964+00	2026-05-04 08:00:01.420069+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.597392
c77e033f-07f4-4562-bde4-bb27c4b27cd8	2026-05-04 07:50:43.1797+00	2026-05-04 07:50:44.526459+00	ba3c630d-92bb-436b-b32d-d149c8c1215e	RecurringMeetings::InitNextOccurrenceJob	default	{"job_id": "ba3c630d-92bb-436b-b32d-d149c8c1215e", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [{"_aj_globalid": "gid://open-project/RecurringMeeting/1"}, {"value": "2026-04-20T19:16:14.917368000+02:00", "_aj_serialized": "ActiveJob::Serializers::TimeSerializer"}], "job_class": "RecurringMeetings::InitNextOccurrenceJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-04-10T07:17:15.463928757Z", "scheduled_at": "2026-04-13T17:16:14.917368000Z", "provider_job_id": null, "exception_executions": {}}	2026-04-13 17:16:14.917368+00	2026-05-04 07:50:44.525291+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:01.341916
f6ad63e4-73fa-4b3c-a018-d621c957e115	2026-05-04 08:00:00.982483+00	2026-05-04 08:00:01.460105+00	027f8f97-20e8-47af-b4dd-6587b5865eb4	Mails::ReminderJob	default	{"job_id": "027f8f97-20e8-47af-b4dd-6587b5865eb4", "locale": "en", "priority": 5, "timezone": "UTC", "arguments": [8], "job_class": "Mails::ReminderJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:00:00.890906476Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:00:00.890912+00	2026-05-04 08:00:01.459267+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.476787
78002605-477e-468b-9674-92ee34ccfb26	2026-05-04 07:50:44.535057+00	2026-05-04 07:50:44.614919+00	0a2fa81a-7497-41d2-9fe4-091152c84414	Notifications::WorkflowJob	default	{"job_id": "0a2fa81a-7497-41d2-9fe4-091152c84414", "locale": "en", "priority": 5, "timezone": "Etc/UTC", "arguments": [{"value": "create_notifications", "_aj_serialized": "ActiveJob::Serializers::SymbolSerializer"}, {"_aj_globalid": "gid://open-project/Journal/62"}, false], "job_class": "Notifications::WorkflowJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T07:50:44.074275148Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 07:50:44.074288+00	2026-05-04 07:50:44.613643+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.078586
cde8f4d1-68cb-4f50-bd7b-74b60a8a7c54	2026-05-04 07:50:47.223919+00	2026-05-04 07:50:47.308105+00	e328862e-0d5e-44db-8070-5a7f6b71bc13	RecurringMeetings::InitNextOccurrenceJob	default	{"job_id": "e328862e-0d5e-44db-8070-5a7f6b71bc13", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [{"_aj_globalid": "gid://open-project/RecurringMeeting/1"}, {"value": "2026-05-04T19:16:14.917368000+02:00", "_aj_serialized": "ActiveJob::Serializers::TimeSerializer"}], "job_class": "RecurringMeetings::InitNextOccurrenceJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T07:50:47.184541108Z", "scheduled_at": "2026-04-27T17:16:14.917368000Z", "provider_job_id": null, "exception_executions": {}}	2026-04-27 17:16:14.917368+00	2026-05-04 07:50:47.307508+00	GoodJob::ActiveJobExtensions::Concurrency::ConcurrencyExceededError: GoodJob::ActiveJobExtensions::Concurrency::ConcurrencyExceededError	3	{}	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.083591
792662c3-9b88-4d16-a541-6c24180c22e9	2026-05-04 07:50:47.126526+00	2026-05-04 07:50:47.576187+00	81c8dd93-b277-4ade-a430-b27bf696af9c	RecurringMeetings::InitNextOccurrenceJob	default	{"job_id": "81c8dd93-b277-4ade-a430-b27bf696af9c", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [{"_aj_globalid": "gid://open-project/RecurringMeeting/1"}, {"value": "2026-04-27T19:16:14.917368000+02:00", "_aj_serialized": "ActiveJob::Serializers::TimeSerializer"}], "job_class": "RecurringMeetings::InitNextOccurrenceJob", "executions": 1, "queue_name": "default", "enqueued_at": "2026-05-04T07:50:44.004648114Z", "scheduled_at": "2026-05-04T07:50:47.110864913Z", "provider_job_id": "81c8dd93-b277-4ade-a430-b27bf696af9c", "exception_executions": {"[GoodJob::ActiveJobExtensions::Concurrency::ConcurrencyExceededError]": 1}}	2026-05-04 07:50:47.110864+00	2026-05-04 07:50:47.575068+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.448543
738cb0db-4fae-4812-8baf-bed41a7e97b3	2026-05-04 07:50:47.585383+00	2026-05-04 07:50:47.646596+00	96c5cbf3-fd57-4a48-8ee1-c8fa79bea0d0	Notifications::WorkflowJob	default	{"job_id": "96c5cbf3-fd57-4a48-8ee1-c8fa79bea0d0", "locale": "en", "priority": 5, "timezone": "Etc/UTC", "arguments": [{"value": "create_notifications", "_aj_serialized": "ActiveJob::Serializers::SymbolSerializer"}, {"_aj_globalid": "gid://open-project/Journal/63"}, false], "job_class": "Notifications::WorkflowJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T07:50:47.340608011Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 07:50:47.340616+00	2026-05-04 07:50:47.643414+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.058032
1caf1982-3634-40a7-865a-7a097568dca8	2026-05-04 07:50:50.337112+00	2026-05-04 07:50:50.670847+00	e328862e-0d5e-44db-8070-5a7f6b71bc13	RecurringMeetings::InitNextOccurrenceJob	default	{"job_id": "e328862e-0d5e-44db-8070-5a7f6b71bc13", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [{"_aj_globalid": "gid://open-project/RecurringMeeting/1"}, {"value": "2026-05-04T19:16:14.917368000+02:00", "_aj_serialized": "ActiveJob::Serializers::TimeSerializer"}], "job_class": "RecurringMeetings::InitNextOccurrenceJob", "executions": 1, "queue_name": "default", "enqueued_at": "2026-05-04T07:50:47.266056107Z", "scheduled_at": "2026-05-04T07:50:50.331018047Z", "provider_job_id": "e328862e-0d5e-44db-8070-5a7f6b71bc13", "exception_executions": {"[GoodJob::ActiveJobExtensions::Concurrency::ConcurrencyExceededError]": 1}}	2026-05-04 07:50:50.331017+00	2026-05-04 07:50:50.670465+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.333354
03ebd29c-11a7-45ed-8142-f8c5b717c4f7	2026-05-04 07:50:50.677826+00	2026-05-04 07:50:50.705514+00	4592f6ed-f8b2-4adc-89ad-0b56d85447ab	Notifications::WorkflowJob	default	{"job_id": "4592f6ed-f8b2-4adc-89ad-0b56d85447ab", "locale": "en", "priority": 5, "timezone": "Etc/UTC", "arguments": [{"value": "create_notifications", "_aj_serialized": "ActiveJob::Serializers::SymbolSerializer"}, {"_aj_globalid": "gid://open-project/Journal/64"}, false], "job_class": "Notifications::WorkflowJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T07:50:50.508737980Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 07:50:50.508855+00	2026-05-04 07:50:50.705232+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.027407
f5eb3b1c-12cb-4ebb-8741-ff4319c9590a	2026-05-04 07:55:47.6312+00	2026-05-04 07:55:47.651777+00	4790c91f-203f-4e77-a183-d59f820a7024	Notifications::WorkflowJob	default	{"job_id": "4790c91f-203f-4e77-a183-d59f820a7024", "locale": "en", "priority": 5, "timezone": "Etc/UTC", "arguments": [{"value": "send_mails", "_aj_serialized": "ActiveJob::Serializers::SymbolSerializer"}], "job_class": "Notifications::WorkflowJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T07:50:44.601519489Z", "scheduled_at": "2026-05-04T07:55:44.601152381Z", "provider_job_id": null, "exception_executions": {}}	2026-05-04 07:55:44.601152+00	2026-05-04 07:55:47.651407+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.02021
e28816e2-754e-48f0-abcf-efe8bb6dde04	2026-05-04 07:55:47.667337+00	2026-05-04 07:55:47.676983+00	8be174eb-6095-441e-a0a4-5f9a87835d33	Notifications::WorkflowJob	default	{"job_id": "8be174eb-6095-441e-a0a4-5f9a87835d33", "locale": "en", "priority": 5, "timezone": "Etc/UTC", "arguments": [{"value": "send_mails", "_aj_serialized": "ActiveJob::Serializers::SymbolSerializer"}], "job_class": "Notifications::WorkflowJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T07:50:47.635136718Z", "scheduled_at": "2026-05-04T07:55:47.634857719Z", "provider_job_id": null, "exception_executions": {}}	2026-05-04 07:55:47.634857+00	2026-05-04 07:55:47.676512+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.009176
591d41c5-b869-416c-abeb-c1775373289e	2026-05-04 07:55:52.991112+00	2026-05-04 07:55:53.011055+00	3225b250-7eb5-4d7e-a6f3-f9980f607060	Notifications::WorkflowJob	default	{"job_id": "3225b250-7eb5-4d7e-a6f3-f9980f607060", "locale": "en", "priority": 5, "timezone": "Etc/UTC", "arguments": [{"value": "send_mails", "_aj_serialized": "ActiveJob::Serializers::SymbolSerializer"}], "job_class": "Notifications::WorkflowJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T07:50:50.698275104Z", "scheduled_at": "2026-05-04T07:55:50.698088938Z", "provider_job_id": null, "exception_executions": {}}	2026-05-04 07:55:50.698088+00	2026-05-04 07:55:53.010582+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.019483
4a6bd261-1c03-4cfe-9319-29710c8a6bee	2026-05-04 08:00:00.101192+00	2026-05-04 08:00:00.186326+00	dc4ec32a-0868-4de0-9a8e-82afd91d6969	Notifications::ScheduleDateAlertsNotificationsJob	default	{"job_id": "dc4ec32a-0868-4de0-9a8e-82afd91d6969", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:00:00.056096395Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:00:00.056169+00	2026-05-04 08:00:00.185782+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.084594
d7eb4c9d-2389-45bf-ba52-c593142ea15b	2026-05-04 08:01:00.030582+00	2026-05-04 08:01:00.058844+00	072d18a6-5d15-4f11-a01d-ee5efaadb260	Storages::ManageStorageIntegrationsJob	default	{"job_id": "072d18a6-5d15-4f11-a01d-ee5efaadb260", "locale": "en", "priority": 7, "timezone": "UTC", "arguments": [], "job_class": "Storages::ManageStorageIntegrationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:01:00.015901586Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:01:00.015985+00	2026-05-04 08:01:00.058496+00	\N	\N	\N	3160498f-c4c0-4930-a103-f4f1d9807a91	00:00:00.027918
\.


--
-- Data for Name: good_job_processes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.good_job_processes (id, created_at, updated_at, state, lock_type) FROM stdin;
aca73442-a483-4339-9034-df8fcf910265	2026-05-04 10:55:27.37221+00	2026-05-04 10:56:58.083647+00	{"pid": 112, "memory": 592867, "hostname": "b4571a2d2baa", "proctitle": "/app/vendor/bundle/ruby/3.4.0/bin/good_job", "schedulers": [{"name": "GoodJob::Scheduler(queues=* max_threads=20)", "queues": "*", "max_cache": 10000, "max_threads": 20, "active_cache": 1, "execution_at": null, "active_threads": 0, "check_queue_at": "2026-05-04T10:56:57.361Z", "available_cache": 9999, "available_threads": 20, "empty_executions_count": 11, "total_executions_count": 0, "errored_executions_count": 0, "succeeded_executions_count": 0}], "cron_enabled": true, "preserve_job_records": true, "database_connection_pool": {"size": 17, "active": 1}, "retry_on_unhandled_error": false, "total_errored_executions_count": 0, "total_succeeded_executions_count": 0}	\N
\.


--
-- Data for Name: good_job_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.good_job_settings (id, created_at, updated_at, key, value) FROM stdin;
\.


--
-- Data for Name: good_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.good_jobs (id, queue_name, priority, serialized_params, scheduled_at, performed_at, finished_at, error, created_at, updated_at, active_job_id, concurrency_key, cron_key, retried_good_job_id, cron_at, batch_id, batch_callback_id, is_discrete, executions_count, job_class, error_event, labels, locked_by_id, locked_at) FROM stdin;
1dbd4ea4-f935-4d7a-8d20-fe9db1172439	default	10	{"job_id": "1dbd4ea4-f935-4d7a-8d20-fe9db1172439", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:15:00.029336734Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:15:00.029431+00	2026-05-04 08:15:00.086229+00	2026-05-04 08:15:00.129114+00	\N	2026-05-04 08:15:00.029431+00	2026-05-04 08:15:00.13248+00	1dbd4ea4-f935-4d7a-8d20-fe9db1172439	Notifications::ScheduleDateAlertsNotificationsJob	Notifications::ScheduleDateAlertsNotificationsJob	\N	2026-05-04 08:15:00+00	\N	\N	\N	1	Notifications::ScheduleDateAlertsNotificationsJob	\N	\N	\N	\N
38fae816-30c6-4156-985b-1cb3fd42bf0b	default	10	{"job_id": "38fae816-30c6-4156-985b-1cb3fd42bf0b", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:15:00.060695732Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:15:00.060795+00	2026-05-04 08:15:00.163705+00	2026-05-04 08:15:00.209829+00	\N	2026-05-04 08:15:00.060795+00	2026-05-04 08:15:00.21172+00	38fae816-30c6-4156-985b-1cb3fd42bf0b	Notifications::ScheduleReminderMailsJob	Notifications::ScheduleReminderMailsJob	\N	2026-05-04 08:15:00+00	\N	\N	\N	1	Notifications::ScheduleReminderMailsJob	\N	\N	\N	\N
c4e1e7ca-f08e-4390-91d9-f9c575100236	default	10	{"job_id": "c4e1e7ca-f08e-4390-91d9-f9c575100236", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "LdapGroups::SynchronizationJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:30:00.030248356Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:30:00.030354+00	2026-05-04 08:30:00.109115+00	2026-05-04 08:30:00.130351+00	\N	2026-05-04 08:30:00.030354+00	2026-05-04 08:30:00.135276+00	c4e1e7ca-f08e-4390-91d9-f9c575100236	\N	LdapGroups::SynchronizationJob	\N	2026-05-04 08:30:00+00	\N	\N	\N	1	LdapGroups::SynchronizationJob	\N	\N	\N	\N
fdbecbee-3b82-4e3a-8aa0-ffeaed5c9f96	default	10	{"job_id": "fdbecbee-3b82-4e3a-8aa0-ffeaed5c9f96", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:30:00.007617614Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:30:00.007625+00	2026-05-04 08:30:00.100144+00	2026-05-04 08:30:00.132146+00	\N	2026-05-04 08:30:00.007625+00	2026-05-04 08:30:00.136199+00	fdbecbee-3b82-4e3a-8aa0-ffeaed5c9f96	Notifications::ScheduleDateAlertsNotificationsJob	Notifications::ScheduleDateAlertsNotificationsJob	\N	2026-05-04 08:30:00+00	\N	\N	\N	1	Notifications::ScheduleDateAlertsNotificationsJob	\N	\N	\N	\N
71268512-38df-4982-8505-b9a75900af57	default	10	{"job_id": "71268512-38df-4982-8505-b9a75900af57", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:30:00.056887100Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:30:00.056899+00	2026-05-04 08:30:00.128123+00	2026-05-04 08:30:00.189036+00	\N	2026-05-04 08:30:00.056899+00	2026-05-04 08:30:00.19268+00	71268512-38df-4982-8505-b9a75900af57	Notifications::ScheduleReminderMailsJob	Notifications::ScheduleReminderMailsJob	\N	2026-05-04 08:30:00+00	\N	\N	\N	1	Notifications::ScheduleReminderMailsJob	\N	\N	\N	\N
2c2e30d0-e344-46f1-9ed9-4d07b3a7325d	default	10	{"job_id": "2c2e30d0-e344-46f1-9ed9-4d07b3a7325d", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:45:00.005992564Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:45:00.005998+00	2026-05-04 08:45:00.033486+00	2026-05-04 08:45:00.046261+00	\N	2026-05-04 08:45:00.005998+00	2026-05-04 08:45:00.047484+00	2c2e30d0-e344-46f1-9ed9-4d07b3a7325d	Notifications::ScheduleDateAlertsNotificationsJob	Notifications::ScheduleDateAlertsNotificationsJob	\N	2026-05-04 08:45:00+00	\N	\N	\N	1	Notifications::ScheduleDateAlertsNotificationsJob	\N	\N	\N	\N
19192ae2-68e1-4387-9687-0c10c4bca0ec	default	10	{"job_id": "19192ae2-68e1-4387-9687-0c10c4bca0ec", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:45:00.022360347Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:45:00.022368+00	2026-05-04 08:45:00.058173+00	2026-05-04 08:45:00.071309+00	\N	2026-05-04 08:45:00.022368+00	2026-05-04 08:45:00.072282+00	19192ae2-68e1-4387-9687-0c10c4bca0ec	Notifications::ScheduleReminderMailsJob	Notifications::ScheduleReminderMailsJob	\N	2026-05-04 08:45:00+00	\N	\N	\N	1	Notifications::ScheduleReminderMailsJob	\N	\N	\N	\N
f33292c7-0189-4a2a-bc8e-3f429d58b437	default	10	{"job_id": "f33292c7-0189-4a2a-bc8e-3f429d58b437", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T09:00:00.004450993Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 09:00:00.004455+00	2026-05-04 09:00:00.076695+00	2026-05-04 09:00:00.095436+00	\N	2026-05-04 09:00:00.004455+00	2026-05-04 09:00:00.096507+00	f33292c7-0189-4a2a-bc8e-3f429d58b437	Notifications::ScheduleDateAlertsNotificationsJob	Notifications::ScheduleDateAlertsNotificationsJob	\N	2026-05-04 09:00:00+00	\N	\N	\N	1	Notifications::ScheduleDateAlertsNotificationsJob	\N	\N	\N	\N
039a6911-0ced-4764-9f2c-2539fa2f90e0	default	10	{"job_id": "039a6911-0ced-4764-9f2c-2539fa2f90e0", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "LdapGroups::SynchronizationJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T09:00:00.066249557Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 09:00:00.066254+00	2026-05-04 09:00:00.111994+00	2026-05-04 09:00:00.14582+00	\N	2026-05-04 09:00:00.066254+00	2026-05-04 09:00:00.147685+00	039a6911-0ced-4764-9f2c-2539fa2f90e0	\N	LdapGroups::SynchronizationJob	\N	2026-05-04 09:00:00+00	\N	\N	\N	1	LdapGroups::SynchronizationJob	\N	\N	\N	\N
157e6bb5-b3e7-424b-be9a-0184a4bd46cb	default	10	{"job_id": "157e6bb5-b3e7-424b-be9a-0184a4bd46cb", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T09:00:00.055289914Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 09:00:00.055295+00	2026-05-04 09:00:00.102007+00	2026-05-04 09:00:00.16406+00	\N	2026-05-04 09:00:00.055295+00	2026-05-04 09:00:00.1655+00	157e6bb5-b3e7-424b-be9a-0184a4bd46cb	Notifications::ScheduleReminderMailsJob	Notifications::ScheduleReminderMailsJob	\N	2026-05-04 09:00:00+00	\N	\N	\N	1	Notifications::ScheduleReminderMailsJob	\N	\N	\N	\N
564bb832-fe89-48af-a8a8-21231419f997	default	7	{"job_id": "564bb832-fe89-48af-a8a8-21231419f997", "locale": "en", "priority": 7, "timezone": "UTC", "arguments": [], "job_class": "Storages::ManageStorageIntegrationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T09:01:00.007837870Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 09:01:00.007911+00	2026-05-04 09:01:00.02164+00	2026-05-04 09:01:00.056306+00	\N	2026-05-04 09:01:00.007911+00	2026-05-04 09:01:00.057341+00	564bb832-fe89-48af-a8a8-21231419f997	Storages::ManageStorageIntegrationsJob	Storages::ManageStorageIntegrationsJob	\N	2026-05-04 09:01:00+00	\N	\N	\N	1	Storages::ManageStorageIntegrationsJob	\N	\N	\N	\N
15e6e993-4383-47bd-a568-b6ccb9d8191e	default	10	{"job_id": "15e6e993-4383-47bd-a568-b6ccb9d8191e", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T09:15:00.004748995Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 09:15:00.004755+00	2026-05-04 09:15:00.065066+00	2026-05-04 09:15:00.082315+00	\N	2026-05-04 09:15:00.004755+00	2026-05-04 09:15:00.08401+00	15e6e993-4383-47bd-a568-b6ccb9d8191e	Notifications::ScheduleDateAlertsNotificationsJob	Notifications::ScheduleDateAlertsNotificationsJob	\N	2026-05-04 09:15:00+00	\N	\N	\N	1	Notifications::ScheduleDateAlertsNotificationsJob	\N	\N	\N	\N
6794f311-5766-4672-be3e-bb88e8ecf79b	default	10	{"job_id": "6794f311-5766-4672-be3e-bb88e8ecf79b", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T09:15:00.052436214Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 09:15:00.052447+00	2026-05-04 09:15:00.099448+00	2026-05-04 09:15:00.123014+00	\N	2026-05-04 09:15:00.052447+00	2026-05-04 09:15:00.12485+00	6794f311-5766-4672-be3e-bb88e8ecf79b	Notifications::ScheduleReminderMailsJob	Notifications::ScheduleReminderMailsJob	\N	2026-05-04 09:15:00+00	\N	\N	\N	1	Notifications::ScheduleReminderMailsJob	\N	\N	\N	\N
b09825d4-ade0-46d4-8781-f5f34a251d3e	default	10	{"job_id": "b09825d4-ade0-46d4-8781-f5f34a251d3e", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T09:30:00.016353358Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 09:30:00.016362+00	2026-05-04 09:30:00.079352+00	2026-05-04 09:30:00.115695+00	\N	2026-05-04 09:30:00.016362+00	2026-05-04 09:30:00.119022+00	b09825d4-ade0-46d4-8781-f5f34a251d3e	Notifications::ScheduleDateAlertsNotificationsJob	Notifications::ScheduleDateAlertsNotificationsJob	\N	2026-05-04 09:30:00+00	\N	\N	\N	1	Notifications::ScheduleDateAlertsNotificationsJob	\N	\N	\N	\N
08467658-4bb7-49c9-9ee8-f8ed7c4fa0ad	default	10	{"job_id": "08467658-4bb7-49c9-9ee8-f8ed7c4fa0ad", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T09:30:00.004514474Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 09:30:00.004519+00	2026-05-04 09:30:00.061298+00	2026-05-04 09:30:00.118224+00	\N	2026-05-04 09:30:00.004519+00	2026-05-04 09:30:00.121865+00	08467658-4bb7-49c9-9ee8-f8ed7c4fa0ad	Notifications::ScheduleReminderMailsJob	Notifications::ScheduleReminderMailsJob	\N	2026-05-04 09:30:00+00	\N	\N	\N	1	Notifications::ScheduleReminderMailsJob	\N	\N	\N	\N
d9181d01-1078-4041-8e1e-2fd9314a122b	default	10	{"job_id": "d9181d01-1078-4041-8e1e-2fd9314a122b", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "LdapGroups::SynchronizationJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T09:30:00.026330604Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 09:30:00.026338+00	2026-05-04 09:30:00.094414+00	2026-05-04 09:30:00.123701+00	\N	2026-05-04 09:30:00.026338+00	2026-05-04 09:30:00.126437+00	d9181d01-1078-4041-8e1e-2fd9314a122b	\N	LdapGroups::SynchronizationJob	\N	2026-05-04 09:30:00+00	\N	\N	\N	1	LdapGroups::SynchronizationJob	\N	\N	\N	\N
133c3af5-19a6-4f31-bf95-9ce435094430	default	10	{"job_id": "133c3af5-19a6-4f31-bf95-9ce435094430", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T09:45:00.009673941Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 09:45:00.0097+00	2026-05-04 09:45:00.059392+00	2026-05-04 09:45:00.09476+00	\N	2026-05-04 09:45:00.0097+00	2026-05-04 09:45:00.097271+00	133c3af5-19a6-4f31-bf95-9ce435094430	Notifications::ScheduleReminderMailsJob	Notifications::ScheduleReminderMailsJob	\N	2026-05-04 09:45:00+00	\N	\N	\N	1	Notifications::ScheduleReminderMailsJob	\N	\N	\N	\N
93fac2ce-341c-4bc9-b6f5-8bc59af28750	default	10	{"job_id": "93fac2ce-341c-4bc9-b6f5-8bc59af28750", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T09:45:00.045348699Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 09:45:00.045357+00	2026-05-04 09:45:00.119616+00	2026-05-04 09:45:00.154033+00	\N	2026-05-04 09:45:00.045357+00	2026-05-04 09:45:00.156771+00	93fac2ce-341c-4bc9-b6f5-8bc59af28750	Notifications::ScheduleDateAlertsNotificationsJob	Notifications::ScheduleDateAlertsNotificationsJob	\N	2026-05-04 09:45:00+00	\N	\N	\N	1	Notifications::ScheduleDateAlertsNotificationsJob	\N	\N	\N	\N
f62cc22d-0f0b-4eb6-a01f-9ecb0346be79	default	10	{"job_id": "f62cc22d-0f0b-4eb6-a01f-9ecb0346be79", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T10:00:00.006951359Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 10:00:00.006956+00	2026-05-04 10:00:00.066853+00	2026-05-04 10:00:00.107435+00	\N	2026-05-04 10:00:00.006956+00	2026-05-04 10:00:00.109207+00	f62cc22d-0f0b-4eb6-a01f-9ecb0346be79	Notifications::ScheduleReminderMailsJob	Notifications::ScheduleReminderMailsJob	\N	2026-05-04 10:00:00+00	\N	\N	\N	1	Notifications::ScheduleReminderMailsJob	\N	\N	\N	\N
08565e5d-cfc3-4727-bea9-8ccaad0d6de3	default	10	{"job_id": "08565e5d-cfc3-4727-bea9-8ccaad0d6de3", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "LdapGroups::SynchronizationJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T10:00:00.050061270Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 10:00:00.050066+00	2026-05-04 10:00:00.123445+00	2026-05-04 10:00:00.140168+00	\N	2026-05-04 10:00:00.050066+00	2026-05-04 10:00:00.141503+00	08565e5d-cfc3-4727-bea9-8ccaad0d6de3	\N	LdapGroups::SynchronizationJob	\N	2026-05-04 10:00:00+00	\N	\N	\N	1	LdapGroups::SynchronizationJob	\N	\N	\N	\N
e58dd439-11f0-4a41-9da0-9d8895093396	default	10	{"job_id": "e58dd439-11f0-4a41-9da0-9d8895093396", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T10:00:00.024675461Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 10:00:00.024682+00	2026-05-04 10:00:00.109894+00	2026-05-04 10:00:00.139083+00	\N	2026-05-04 10:00:00.024682+00	2026-05-04 10:00:00.142335+00	e58dd439-11f0-4a41-9da0-9d8895093396	Notifications::ScheduleDateAlertsNotificationsJob	Notifications::ScheduleDateAlertsNotificationsJob	\N	2026-05-04 10:00:00+00	\N	\N	\N	1	Notifications::ScheduleDateAlertsNotificationsJob	\N	\N	\N	\N
96fe6122-de86-4c8a-8402-b3b7888365f1	default	7	{"job_id": "96fe6122-de86-4c8a-8402-b3b7888365f1", "locale": "en", "priority": 7, "timezone": "UTC", "arguments": [], "job_class": "Storages::ManageStorageIntegrationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T10:01:00.009262909Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 10:01:00.00927+00	2026-05-04 10:01:00.033192+00	2026-05-04 10:01:00.053547+00	\N	2026-05-04 10:01:00.00927+00	2026-05-04 10:01:00.054999+00	96fe6122-de86-4c8a-8402-b3b7888365f1	Storages::ManageStorageIntegrationsJob	Storages::ManageStorageIntegrationsJob	\N	2026-05-04 10:01:00+00	\N	\N	\N	1	Storages::ManageStorageIntegrationsJob	\N	\N	\N	\N
b23d8967-2adc-44ee-ba01-d7479d6e191e	default	10	{"job_id": "b23d8967-2adc-44ee-ba01-d7479d6e191e", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T10:15:00.006439007Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 10:15:00.006445+00	2026-05-04 10:15:00.665643+00	2026-05-04 10:15:00.700117+00	\N	2026-05-04 10:15:00.006445+00	2026-05-04 10:15:00.701809+00	b23d8967-2adc-44ee-ba01-d7479d6e191e	Notifications::ScheduleDateAlertsNotificationsJob	Notifications::ScheduleDateAlertsNotificationsJob	\N	2026-05-04 10:15:00+00	\N	\N	\N	1	Notifications::ScheduleDateAlertsNotificationsJob	\N	\N	\N	\N
80bec2d9-90ee-4e08-ae36-b7b218c27720	default	10	{"job_id": "80bec2d9-90ee-4e08-ae36-b7b218c27720", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T10:15:00.028484501Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 10:15:00.028491+00	2026-05-04 10:15:00.729166+00	2026-05-04 10:15:00.800747+00	\N	2026-05-04 10:15:00.028491+00	2026-05-04 10:15:00.803311+00	80bec2d9-90ee-4e08-ae36-b7b218c27720	Notifications::ScheduleReminderMailsJob	Notifications::ScheduleReminderMailsJob	\N	2026-05-04 10:15:00+00	\N	\N	\N	1	Notifications::ScheduleReminderMailsJob	\N	\N	\N	\N
aa9846e0-5e40-4a12-9626-86798c80c186	default	10	{"job_id": "aa9846e0-5e40-4a12-9626-86798c80c186", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T10:30:00.008789005Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 10:30:00.008804+00	2026-05-04 10:30:00.073232+00	2026-05-04 10:30:00.094949+00	\N	2026-05-04 10:30:00.008804+00	2026-05-04 10:30:00.096612+00	aa9846e0-5e40-4a12-9626-86798c80c186	Notifications::ScheduleDateAlertsNotificationsJob	Notifications::ScheduleDateAlertsNotificationsJob	\N	2026-05-04 10:30:00+00	\N	\N	\N	1	Notifications::ScheduleDateAlertsNotificationsJob	\N	\N	\N	\N
0ac429e7-e076-4351-9920-a66aab3f00e1	default	10	{"job_id": "0ac429e7-e076-4351-9920-a66aab3f00e1", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T10:30:00.041211071Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 10:30:00.041223+00	2026-05-04 10:30:00.109792+00	2026-05-04 10:30:00.133628+00	\N	2026-05-04 10:30:00.041223+00	2026-05-04 10:30:00.135018+00	0ac429e7-e076-4351-9920-a66aab3f00e1	Notifications::ScheduleReminderMailsJob	Notifications::ScheduleReminderMailsJob	\N	2026-05-04 10:30:00+00	\N	\N	\N	1	Notifications::ScheduleReminderMailsJob	\N	\N	\N	\N
f807f473-5231-4c79-83cf-bad418f55ee9	default	10	{"job_id": "f807f473-5231-4c79-83cf-bad418f55ee9", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "LdapGroups::SynchronizationJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T10:30:00.055699256Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 10:30:00.055715+00	2026-05-04 10:30:00.144156+00	2026-05-04 10:30:00.154289+00	\N	2026-05-04 10:30:00.055715+00	2026-05-04 10:30:00.155443+00	f807f473-5231-4c79-83cf-bad418f55ee9	\N	LdapGroups::SynchronizationJob	\N	2026-05-04 10:30:00+00	\N	\N	\N	1	LdapGroups::SynchronizationJob	\N	\N	\N	\N
311eecbf-df5b-4f2a-bae9-4d2c7fd07a17	default	10	{"job_id": "311eecbf-df5b-4f2a-bae9-4d2c7fd07a17", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T10:45:00.004736556Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 10:45:00.004742+00	2026-05-04 10:45:00.036384+00	2026-05-04 10:45:00.051649+00	\N	2026-05-04 10:45:00.004742+00	2026-05-04 10:45:00.052805+00	311eecbf-df5b-4f2a-bae9-4d2c7fd07a17	Notifications::ScheduleReminderMailsJob	Notifications::ScheduleReminderMailsJob	\N	2026-05-04 10:45:00+00	\N	\N	\N	1	Notifications::ScheduleReminderMailsJob	\N	\N	\N	\N
059ae8f1-de26-4d55-8caa-9b3c60f5aa37	default	10	{"job_id": "059ae8f1-de26-4d55-8caa-9b3c60f5aa37", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T10:45:00.027509099Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 10:45:00.027516+00	2026-05-04 10:45:00.063762+00	2026-05-04 10:45:00.076646+00	\N	2026-05-04 10:45:00.027516+00	2026-05-04 10:45:00.077661+00	059ae8f1-de26-4d55-8caa-9b3c60f5aa37	Notifications::ScheduleDateAlertsNotificationsJob	Notifications::ScheduleDateAlertsNotificationsJob	\N	2026-05-04 10:45:00+00	\N	\N	\N	1	Notifications::ScheduleDateAlertsNotificationsJob	\N	\N	\N	\N
ba3c630d-92bb-436b-b32d-d149c8c1215e	default	10	{"job_id": "ba3c630d-92bb-436b-b32d-d149c8c1215e", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [{"_aj_globalid": "gid://open-project/RecurringMeeting/1"}, {"value": "2026-04-20T19:16:14.917368000+02:00", "_aj_serialized": "ActiveJob::Serializers::TimeSerializer"}], "job_class": "RecurringMeetings::InitNextOccurrenceJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-04-10T07:17:15.463928757Z", "scheduled_at": "2026-04-13T17:16:14.917368000Z", "provider_job_id": null, "exception_executions": {}}	2026-04-13 17:16:14.917368+00	2026-05-04 07:50:43.1797+00	2026-05-04 07:50:44.525291+00	\N	2026-04-10 07:17:15.463944+00	2026-05-04 07:50:44.543497+00	ba3c630d-92bb-436b-b32d-d149c8c1215e	RecurringMeetings::InitNextOccurrenceJob-1	\N	\N	\N	\N	\N	\N	1	RecurringMeetings::InitNextOccurrenceJob	\N	\N	\N	\N
0a2fa81a-7497-41d2-9fe4-091152c84414	default	5	{"job_id": "0a2fa81a-7497-41d2-9fe4-091152c84414", "locale": "en", "priority": 5, "timezone": "Etc/UTC", "arguments": [{"value": "create_notifications", "_aj_serialized": "ActiveJob::Serializers::SymbolSerializer"}, {"_aj_globalid": "gid://open-project/Journal/62"}, false], "job_class": "Notifications::WorkflowJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T07:50:44.074275148Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 07:50:44.074288+00	2026-05-04 07:50:44.535057+00	2026-05-04 07:50:44.613643+00	\N	2026-05-04 07:50:44.074288+00	2026-05-04 07:50:44.61731+00	0a2fa81a-7497-41d2-9fe4-091152c84414	\N	\N	\N	\N	\N	\N	\N	1	Notifications::WorkflowJob	\N	\N	\N	\N
81c8dd93-b277-4ade-a430-b27bf696af9c	default	10	{"job_id": "81c8dd93-b277-4ade-a430-b27bf696af9c", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [{"_aj_globalid": "gid://open-project/RecurringMeeting/1"}, {"value": "2026-04-27T19:16:14.917368000+02:00", "_aj_serialized": "ActiveJob::Serializers::TimeSerializer"}], "job_class": "RecurringMeetings::InitNextOccurrenceJob", "executions": 1, "queue_name": "default", "enqueued_at": "2026-05-04T07:50:44.004648114Z", "scheduled_at": "2026-05-04T07:50:47.110864913Z", "provider_job_id": "81c8dd93-b277-4ade-a430-b27bf696af9c", "exception_executions": {"[GoodJob::ActiveJobExtensions::Concurrency::ConcurrencyExceededError]": 1}}	2026-05-04 07:50:47.110864+00	2026-05-04 07:50:47.126526+00	2026-05-04 07:50:47.575068+00	\N	2026-05-04 07:50:44.004689+00	2026-05-04 07:50:47.582995+00	81c8dd93-b277-4ade-a430-b27bf696af9c	RecurringMeetings::InitNextOccurrenceJob-1	\N	\N	\N	\N	\N	\N	2	RecurringMeetings::InitNextOccurrenceJob	\N	\N	\N	\N
96c5cbf3-fd57-4a48-8ee1-c8fa79bea0d0	default	5	{"job_id": "96c5cbf3-fd57-4a48-8ee1-c8fa79bea0d0", "locale": "en", "priority": 5, "timezone": "Etc/UTC", "arguments": [{"value": "create_notifications", "_aj_serialized": "ActiveJob::Serializers::SymbolSerializer"}, {"_aj_globalid": "gid://open-project/Journal/63"}, false], "job_class": "Notifications::WorkflowJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T07:50:47.340608011Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 07:50:47.340616+00	2026-05-04 07:50:47.585383+00	2026-05-04 07:50:47.643414+00	\N	2026-05-04 07:50:47.340616+00	2026-05-04 07:50:47.649466+00	96c5cbf3-fd57-4a48-8ee1-c8fa79bea0d0	\N	\N	\N	\N	\N	\N	\N	1	Notifications::WorkflowJob	\N	\N	\N	\N
e328862e-0d5e-44db-8070-5a7f6b71bc13	default	10	{"job_id": "e328862e-0d5e-44db-8070-5a7f6b71bc13", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [{"_aj_globalid": "gid://open-project/RecurringMeeting/1"}, {"value": "2026-05-04T19:16:14.917368000+02:00", "_aj_serialized": "ActiveJob::Serializers::TimeSerializer"}], "job_class": "RecurringMeetings::InitNextOccurrenceJob", "executions": 1, "queue_name": "default", "enqueued_at": "2026-05-04T07:50:47.266056107Z", "scheduled_at": "2026-05-04T07:50:50.331018047Z", "provider_job_id": "e328862e-0d5e-44db-8070-5a7f6b71bc13", "exception_executions": {"[GoodJob::ActiveJobExtensions::Concurrency::ConcurrencyExceededError]": 1}}	2026-05-04 07:50:50.331017+00	2026-05-04 07:50:50.337112+00	2026-05-04 07:50:50.670465+00	\N	2026-05-04 07:50:47.266074+00	2026-05-04 07:50:50.675916+00	e328862e-0d5e-44db-8070-5a7f6b71bc13	RecurringMeetings::InitNextOccurrenceJob-1	\N	\N	\N	\N	\N	\N	2	RecurringMeetings::InitNextOccurrenceJob	\N	\N	\N	\N
4790c91f-203f-4e77-a183-d59f820a7024	default	5	{"job_id": "4790c91f-203f-4e77-a183-d59f820a7024", "locale": "en", "priority": 5, "timezone": "Etc/UTC", "arguments": [{"value": "send_mails", "_aj_serialized": "ActiveJob::Serializers::SymbolSerializer"}], "job_class": "Notifications::WorkflowJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T07:50:44.601519489Z", "scheduled_at": "2026-05-04T07:55:44.601152381Z", "provider_job_id": null, "exception_executions": {}}	2026-05-04 07:55:44.601152+00	2026-05-04 07:55:47.6312+00	2026-05-04 07:55:47.651407+00	\N	2026-05-04 07:50:44.601529+00	2026-05-04 07:55:47.653349+00	4790c91f-203f-4e77-a183-d59f820a7024	\N	\N	\N	\N	\N	\N	\N	1	Notifications::WorkflowJob	\N	\N	\N	\N
3225b250-7eb5-4d7e-a6f3-f9980f607060	default	5	{"job_id": "3225b250-7eb5-4d7e-a6f3-f9980f607060", "locale": "en", "priority": 5, "timezone": "Etc/UTC", "arguments": [{"value": "send_mails", "_aj_serialized": "ActiveJob::Serializers::SymbolSerializer"}], "job_class": "Notifications::WorkflowJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T07:50:50.698275104Z", "scheduled_at": "2026-05-04T07:55:50.698088938Z", "provider_job_id": null, "exception_executions": {}}	2026-05-04 07:55:50.698088+00	2026-05-04 07:55:52.991112+00	2026-05-04 07:55:53.010582+00	\N	2026-05-04 07:50:50.698381+00	2026-05-04 07:55:53.015484+00	3225b250-7eb5-4d7e-a6f3-f9980f607060	\N	\N	\N	\N	\N	\N	\N	1	Notifications::WorkflowJob	\N	\N	\N	\N
dc4ec32a-0868-4de0-9a8e-82afd91d6969	default	10	{"job_id": "dc4ec32a-0868-4de0-9a8e-82afd91d6969", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleDateAlertsNotificationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:00:00.056096395Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:00:00.056169+00	2026-05-04 08:00:00.101192+00	2026-05-04 08:00:00.185782+00	\N	2026-05-04 08:00:00.056169+00	2026-05-04 08:00:00.192054+00	dc4ec32a-0868-4de0-9a8e-82afd91d6969	Notifications::ScheduleDateAlertsNotificationsJob	Notifications::ScheduleDateAlertsNotificationsJob	\N	2026-05-04 08:00:00+00	\N	\N	\N	1	Notifications::ScheduleDateAlertsNotificationsJob	\N	\N	\N	\N
32cd93e8-6dde-4faa-87e0-f850f5e17dba	default	10	{"job_id": "32cd93e8-6dde-4faa-87e0-f850f5e17dba", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "LdapGroups::SynchronizationJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:00:00.094905872Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:00:00.09497+00	2026-05-04 08:00:00.210913+00	2026-05-04 08:00:00.233437+00	\N	2026-05-04 08:00:00.09497+00	2026-05-04 08:00:00.236473+00	32cd93e8-6dde-4faa-87e0-f850f5e17dba	\N	LdapGroups::SynchronizationJob	\N	2026-05-04 08:00:00+00	\N	\N	\N	1	LdapGroups::SynchronizationJob	\N	\N	\N	\N
811763e8-2d18-4744-9461-b8b2adde86fc	default	10	{"job_id": "811763e8-2d18-4744-9461-b8b2adde86fc", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [], "job_class": "Notifications::ScheduleReminderMailsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:00:00.136737464Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:00:00.136801+00	2026-05-04 08:00:00.251184+00	2026-05-04 08:00:00.91519+00	\N	2026-05-04 08:00:00.136801+00	2026-05-04 08:00:00.947381+00	811763e8-2d18-4744-9461-b8b2adde86fc	Notifications::ScheduleReminderMailsJob	Notifications::ScheduleReminderMailsJob	\N	2026-05-04 08:00:00+00	\N	\N	\N	1	Notifications::ScheduleReminderMailsJob	\N	\N	\N	\N
3b590328-da76-466d-9578-98e7b933f25d	default	10	{"job_id": "3b590328-da76-466d-9578-98e7b933f25d", "locale": "en", "priority": 10, "timezone": "UTC", "arguments": [{"_aj_globalid": "gid://open-project/RecurringMeeting/1"}, {"value": "2026-05-11T19:16:14.917368000+02:00", "_aj_serialized": "ActiveJob::Serializers::TimeSerializer"}], "job_class": "RecurringMeetings::InitNextOccurrenceJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T07:50:50.395390544Z", "scheduled_at": "2026-05-04T17:16:14.917368000Z", "provider_job_id": null, "exception_executions": {}}	2026-05-04 17:16:14.917368+00	\N	\N	\N	2026-05-04 07:50:50.395848+00	2026-05-04 07:50:50.399778+00	3b590328-da76-466d-9578-98e7b933f25d	RecurringMeetings::InitNextOccurrenceJob-1	\N	\N	\N	\N	\N	\N	\N	RecurringMeetings::InitNextOccurrenceJob	\N	\N	\N	\N
4592f6ed-f8b2-4adc-89ad-0b56d85447ab	default	5	{"job_id": "4592f6ed-f8b2-4adc-89ad-0b56d85447ab", "locale": "en", "priority": 5, "timezone": "Etc/UTC", "arguments": [{"value": "create_notifications", "_aj_serialized": "ActiveJob::Serializers::SymbolSerializer"}, {"_aj_globalid": "gid://open-project/Journal/64"}, false], "job_class": "Notifications::WorkflowJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T07:50:50.508737980Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 07:50:50.508855+00	2026-05-04 07:50:50.677826+00	2026-05-04 07:50:50.705232+00	\N	2026-05-04 07:50:50.508855+00	2026-05-04 07:50:50.706895+00	4592f6ed-f8b2-4adc-89ad-0b56d85447ab	\N	\N	\N	\N	\N	\N	\N	1	Notifications::WorkflowJob	\N	\N	\N	\N
8be174eb-6095-441e-a0a4-5f9a87835d33	default	5	{"job_id": "8be174eb-6095-441e-a0a4-5f9a87835d33", "locale": "en", "priority": 5, "timezone": "Etc/UTC", "arguments": [{"value": "send_mails", "_aj_serialized": "ActiveJob::Serializers::SymbolSerializer"}], "job_class": "Notifications::WorkflowJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T07:50:47.635136718Z", "scheduled_at": "2026-05-04T07:55:47.634857719Z", "provider_job_id": null, "exception_executions": {}}	2026-05-04 07:55:47.634857+00	2026-05-04 07:55:47.667337+00	2026-05-04 07:55:47.676512+00	\N	2026-05-04 07:50:47.635143+00	2026-05-04 07:55:47.678227+00	8be174eb-6095-441e-a0a4-5f9a87835d33	\N	\N	\N	\N	\N	\N	\N	1	Notifications::WorkflowJob	\N	\N	\N	\N
17ee8bd2-54da-4182-b249-dfa320aa3185	default	5	{"job_id": "17ee8bd2-54da-4182-b249-dfa320aa3185", "locale": "en", "priority": 5, "timezone": "UTC", "arguments": [6], "job_class": "Mails::ReminderJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:00:00.798890575Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:00:00.798964+00	2026-05-04 08:00:00.822683+00	2026-05-04 08:00:01.420069+00	\N	2026-05-04 08:00:00.798964+00	2026-05-04 08:00:01.4222+00	17ee8bd2-54da-4182-b249-dfa320aa3185	Mails::ReminderJob-6	\N	\N	\N	\N	\N	\N	1	Mails::ReminderJob	\N	\N	\N	\N
ca92fadd-67e0-45f5-82cb-bed61b006629	default	5	{"job_id": "ca92fadd-67e0-45f5-82cb-bed61b006629", "locale": "en", "priority": 5, "timezone": "UTC", "arguments": [7], "job_class": "Mails::ReminderJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:00:00.819575474Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:00:00.81958+00	2026-05-04 08:00:00.847883+00	2026-05-04 08:00:01.425215+00	\N	2026-05-04 08:00:00.81958+00	2026-05-04 08:00:01.42674+00	ca92fadd-67e0-45f5-82cb-bed61b006629	Mails::ReminderJob-7	\N	\N	\N	\N	\N	\N	1	Mails::ReminderJob	\N	\N	\N	\N
ea5d868d-3578-435b-b7e8-fff0818b6ad4	default	5	{"job_id": "ea5d868d-3578-435b-b7e8-fff0818b6ad4", "locale": "en", "priority": 5, "timezone": "UTC", "arguments": [5], "job_class": "Mails::ReminderJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:00:00.772235520Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:00:00.772587+00	2026-05-04 08:00:00.795531+00	2026-05-04 08:00:01.452741+00	\N	2026-05-04 08:00:00.772587+00	2026-05-04 08:00:01.454489+00	ea5d868d-3578-435b-b7e8-fff0818b6ad4	Mails::ReminderJob-5	\N	\N	\N	\N	\N	\N	1	Mails::ReminderJob	\N	\N	\N	\N
027f8f97-20e8-47af-b4dd-6587b5865eb4	default	5	{"job_id": "027f8f97-20e8-47af-b4dd-6587b5865eb4", "locale": "en", "priority": 5, "timezone": "UTC", "arguments": [8], "job_class": "Mails::ReminderJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:00:00.890906476Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:00:00.890912+00	2026-05-04 08:00:00.982483+00	2026-05-04 08:00:01.459267+00	\N	2026-05-04 08:00:00.890912+00	2026-05-04 08:00:01.461642+00	027f8f97-20e8-47af-b4dd-6587b5865eb4	Mails::ReminderJob-8	\N	\N	\N	\N	\N	\N	1	Mails::ReminderJob	\N	\N	\N	\N
072d18a6-5d15-4f11-a01d-ee5efaadb260	default	7	{"job_id": "072d18a6-5d15-4f11-a01d-ee5efaadb260", "locale": "en", "priority": 7, "timezone": "UTC", "arguments": [], "job_class": "Storages::ManageStorageIntegrationsJob", "executions": 0, "queue_name": "default", "enqueued_at": "2026-05-04T08:01:00.015901586Z", "scheduled_at": null, "provider_job_id": null, "exception_executions": {}}	2026-05-04 08:01:00.015985+00	2026-05-04 08:01:00.030582+00	2026-05-04 08:01:00.058496+00	\N	2026-05-04 08:01:00.015985+00	2026-05-04 08:01:00.061115+00	072d18a6-5d15-4f11-a01d-ee5efaadb260	Storages::ManageStorageIntegrationsJob	Storages::ManageStorageIntegrationsJob	\N	2026-05-04 08:01:00+00	\N	\N	\N	1	Storages::ManageStorageIntegrationsJob	\N	\N	\N	\N
\.


--
-- Data for Name: grid_widgets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grid_widgets (id, start_row, end_row, start_column, end_column, identifier, options, grid_id) FROM stdin;
1	1	2	1	2	work_package_query	---\n:query_id: 5\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '1'\n	1
2	1	2	2	3	work_package_query	---\n:query_id: 6\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '7'\n	1
3	1	2	3	4	work_package_query	---\n:query_id: 7\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '12'\n	1
4	1	2	4	5	work_package_query	---\n:query_id: 8\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '14'\n	1
5	1	2	1	2	work_package_query	---\n:query_id: 9\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	2
6	1	2	2	3	work_package_query	---\n:query_id: 10\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	2
7	1	2	3	4	work_package_query	---\n:query_id: 11\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	2
8	1	2	4	5	work_package_query	---\n:query_id: 12\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	2
9	1	2	1	2	work_package_query	---\n:query_id: 13\n:filters:\n- :parent:\n    :operator: "="\n    :values:\n    - '2'\n	3
10	1	2	2	3	work_package_query	---\n:query_id: 14\n:filters:\n- :parent:\n    :operator: "="\n    :values:\n    - '10'\n	3
11	1	2	1	2	work_package_query	---\n:query_id: 19\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '1'\n	4
12	1	2	2	3	work_package_query	---\n:query_id: 20\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '7'\n	4
13	1	2	3	4	work_package_query	---\n:query_id: 21\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '12'\n	4
14	1	2	4	5	work_package_query	---\n:query_id: 22\n:filters:\n- :status:\n    :operator: "="\n    :values:\n    - '14'\n	4
15	1	2	1	2	work_package_query	---\n:query_id: 23\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	5
16	1	2	2	3	work_package_query	---\n:query_id: 24\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	5
17	1	2	3	4	work_package_query	---\n:query_id: 25\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	5
18	1	2	4	5	work_package_query	---\n:query_id: 26\n:filters:\n- :manualSort:\n    :operator: ow\n    :values: []\n	5
19	1	2	1	3	custom_text	---\ntext: "![Teaser](/api/v3/attachments/1/content)"\nname: Welcome\n	6
20	2	5	1	2	custom_text	---\nname: Getting started\ntext: |\n  We are glad you joined! We suggest to try a few things to get started in OpenProject.\n\n  Discover the most important features with our [Guided Tour]({{opSetting:base_url}}/projects/demo-project/work_packages/?start_onboarding_tour=true).\n\n  _Try the following steps:_\n\n  1. *Invite new members to your project*: &rightarrow; Go to [Members]({{opSetting:base_url}}/projects/demo-project/members) in the project navigation.\n  2. *View the work in your project*: &rightarrow; Go to [Work packages]({{opSetting:base_url}}/projects/demo-project/work_packages) in the project navigation.\n  3. *Create a new work package*: &rightarrow; Go to [Work packages &rightarrow; Create]({{opSetting:base_url}}/projects/demo-project/work_packages/new).\n  4. *Create and update a project plan*: &rightarrow; Go to [Project plan]({{opSetting:base_url}}/projects/demo-project/work_packages?query_id=1) in the project navigation.\n  5. *Activate further modules*: &rightarrow; Go to [Project settings &rightarrow; Modules]({{opSetting:base_url}}/projects/demo-project/settings/modules).\n  6. *Complete your tasks in the project*: &rightarrow; Go to [Work packages &rightarrow; Tasks]({{opSetting:base_url}}/projects/demo-project/work_packages/details/3/overview?query_id=3).\n\n  Here you will find our [User Guides](https://www.openproject.org/docs/user-guide/).\n  Please let us know if you have any questions or need support. Contact us: [support[at]openproject.com](mailto:support@openproject.com).\n	6
21	2	3	2	3	project_status	\N	6
22	3	4	2	3	project_description	\N	6
23	4	5	2	3	members	---\nname: Members\n	6
24	5	6	1	3	work_packages_overview	---\nname: Work packages\n	6
25	6	7	1	3	work_packages_table	---\nqueryId: '2'\nname: Milestones\n	6
26	1	2	1	3	custom_text	---\ntext: "![Teaser](/api/v3/attachments/2/content)"\nname: Welcome\n	7
27	2	5	1	2	custom_text	---\nname: Getting started\ntext: |\n  We are glad you joined! We suggest to try a few things to get started in OpenProject.\n\n  _Try the following steps:_\n\n  1. *Invite new members to your project*: &rightarrow; Go to [Members]({{opSetting:base_url}}/projects/your-scrum-project/members) in the project navigation.\n  2. *View your Product backlog and Sprint backlogs*: &rightarrow; Go to [Backlogs]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) in the project navigation.\n  3. *View your Task board*: &rightarrow; Go to [Backlogs]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) &rightarrow; Click on right arrow on Sprint &rightarrow; Select [Task Board](/projects/your-scrum-project/sprints/3/taskboard).\n  4. *Create a new work package*: &rightarrow; Go to [Work packages &rightarrow; Create]({{opSetting:base_url}}/projects/your-scrum-project/work_packages/new).\n  5. *Create and update a project plan*: &rightarrow; Go to [Project plan](/projects/your-scrum-project/work_packages?query_id=15) in the project navigation.\n  6. *Create a Sprint wiki*: &rightarrow; Go to [Backlogs]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) and open the sprint wiki from the right drop down menu in a sprint. You can edit the [wiki template]({{opSetting:base_url}}/projects/your-scrum-project/wiki/) based on your needs.\n  7. *Activate further modules*: &rightarrow; Go to [Project settings &rightarrow; Modules]({{opSetting:base_url}}/projects/your-scrum-project/settings/modules).\n\n  Here you will find our [User Guides](https://www.openproject.org/docs/user-guide/).\n  Please let us know if you have any questions or need support. Contact us: [support[at]openproject.com](mailto:support@openproject.com).\n	7
28	2	3	2	3	project_status	\N	7
29	3	4	2	3	project_description	\N	7
30	4	5	2	3	members	---\nname: Members\n	7
31	5	6	1	3	work_packages_overview	---\nname: Work packages\n	7
32	6	7	1	3	work_packages_table	---\nqueryId: '15'\nname: Project plan\n	7
\.


--
-- Data for Name: grids; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grids (id, row_count, column_count, type, user_id, created_at, updated_at, project_id, name, options) FROM stdin;
1	1	4	Boards::Grid	\N	2026-04-10 07:16:14.735835+00	2026-04-10 07:16:14.735835+00	1	Kanban board	---\ntype: action\nattribute: status\nhighlightingMode: priority\n:filters:\n- :type:\n    :operator: "="\n    :values:\n    - '1'\n
2	1	4	Boards::Grid	\N	2026-04-10 07:16:14.846025+00	2026-04-10 07:16:14.846025+00	1	Basic board	---\nhighlightingMode: priority\n
3	1	2	Boards::Grid	\N	2026-04-10 07:16:14.904215+00	2026-04-10 07:16:14.904215+00	1	Work breakdown structure	---\ntype: action\nattribute: subtasks\n
4	1	4	Boards::Grid	\N	2026-04-10 07:16:18.283715+00	2026-04-10 07:16:18.283715+00	2	Kanban board	---\ntype: action\nattribute: status\nhighlightingMode: priority\n
5	1	4	Boards::Grid	\N	2026-04-10 07:16:18.357493+00	2026-04-10 07:16:18.357493+00	2	Task board	---\nhighlightingMode: priority\n
6	6	2	Grids::Overview	\N	2026-04-10 07:16:18.387567+00	2026-04-10 07:16:18.387567+00	1	\N	\N
7	6	2	Grids::Overview	\N	2026-04-10 07:16:18.494944+00	2026-04-10 07:16:18.494944+00	2	\N	\N
\.


--
-- Data for Name: group_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_users (id, group_id, user_id) FROM stdin;
1	9	5
2	9	6
3	9	7
4	9	8
\.


--
-- Data for Name: hierarchical_item_hierarchies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hierarchical_item_hierarchies (ancestor_id, descendant_id, generations) FROM stdin;
\.


--
-- Data for Name: hierarchical_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hierarchical_items (id, parent_id, sort_order, label, short, is_deleted, created_at, updated_at, custom_field_id, position_cache, weight, children_count) FROM stdin;
\.


--
-- Data for Name: ical_token_query_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ical_token_query_assignments (id, ical_token_id, query_id, created_at, updated_at, name) FROM stdin;
\.


--
-- Data for Name: ifc_models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ifc_models (id, title, created_at, updated_at, project_id, uploader_id, is_default, conversion_status, conversion_error_message) FROM stdin;
\.


--
-- Data for Name: job_statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.job_statuses (id, reference_type, reference_id, message, created_at, updated_at, status, user_id, job_id, payload) FROM stdin;
\.


--
-- Data for Name: journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.journals (id, journable_type, journable_id, user_id, notes, created_at, version, updated_at, data_type, data_id, cause, validity_period, restricted) FROM stdin;
2	News	1	2		2026-04-10 07:16:12.121164+00	1	2026-04-10 07:16:12.121164+00	Journal::NewsJournal	1	{}	["2026-04-10 07:16:12.121164+00",)	f
3	Project	1	4		2026-04-10 07:16:12.602091+00	2	2026-04-10 07:16:12.602091+00	Journal::ProjectJournal	2	{}	["2026-04-10 07:16:12.602091+00",)	f
1	Project	1	2		2026-04-10 07:16:11.719906+00	1	2026-04-10 07:16:11.719906+00	Journal::ProjectJournal	1	{}	["2026-04-10 07:16:11.719906+00","2026-04-10 07:16:12.602091+00")	f
4	WikiPage	1	2		2026-04-10 07:16:12.733823+00	1	2026-04-10 07:16:12.733823+00	Journal::WikiPageJournal	1	{}	["2026-04-10 07:16:12.733823+00",)	f
5	WorkPackage	1	2		2026-04-10 07:16:12.814+00	1	2026-04-10 07:16:12.814+00	Journal::WorkPackageJournal	1	{}	["2026-04-10 07:16:12.814+00",)	f
6	WorkPackage	2	2		2026-04-10 07:16:12.955551+00	1	2026-04-10 07:16:12.955551+00	Journal::WorkPackageJournal	2	{}	["2026-04-10 07:16:12.955551+00",)	f
8	WorkPackage	4	2		2026-04-10 07:16:13.109164+00	1	2026-04-10 07:16:13.194382+00	Journal::WorkPackageJournal	5	{}	["2026-04-10 07:16:13.109164+00",)	f
9	WorkPackage	5	2		2026-04-10 07:16:13.279438+00	1	2026-04-10 07:16:13.362904+00	Journal::WorkPackageJournal	7	{}	["2026-04-10 07:16:13.279438+00",)	f
10	WorkPackage	6	2		2026-04-10 07:16:13.485643+00	1	2026-04-10 07:16:13.563346+00	Journal::WorkPackageJournal	9	{}	["2026-04-10 07:16:13.485643+00",)	f
7	WorkPackage	3	2		2026-04-10 07:16:13.028552+00	1	2026-04-10 07:16:13.642595+00	Journal::WorkPackageJournal	10	{}	["2026-04-10 07:16:13.028552+00",)	f
11	WorkPackage	7	2		2026-04-10 07:16:13.730402+00	1	2026-04-10 07:16:13.807056+00	Journal::WorkPackageJournal	12	{}	["2026-04-10 07:16:13.730402+00",)	f
12	WorkPackage	8	2		2026-04-10 07:16:13.877223+00	1	2026-04-10 07:16:13.9638+00	Journal::WorkPackageJournal	14	{}	["2026-04-10 07:16:13.877223+00",)	f
13	WorkPackage	9	2		2026-04-10 07:16:14.04038+00	1	2026-04-10 07:16:14.04038+00	Journal::WorkPackageJournal	15	{}	["2026-04-10 07:16:14.04038+00",)	f
14	WorkPackage	10	2		2026-04-10 07:16:14.11422+00	1	2026-04-10 07:16:14.11422+00	Journal::WorkPackageJournal	16	{}	["2026-04-10 07:16:14.11422+00",)	f
15	WorkPackage	11	2		2026-04-10 07:16:14.177112+00	1	2026-04-10 07:16:14.247884+00	Journal::WorkPackageJournal	18	{}	["2026-04-10 07:16:14.177112+00",)	f
16	WorkPackage	12	2		2026-04-10 07:16:14.335453+00	1	2026-04-10 07:16:14.408619+00	Journal::WorkPackageJournal	20	{}	["2026-04-10 07:16:14.335453+00",)	f
17	WorkPackage	13	2		2026-04-10 07:16:14.488504+00	1	2026-04-10 07:16:14.488504+00	Journal::WorkPackageJournal	21	{}	["2026-04-10 07:16:14.488504+00",)	f
18	Meeting	1	4		2026-04-10 07:16:14.990979+00	1	2026-04-10 07:16:14.990979+00	Journal::MeetingJournal	1	{}	["2026-04-10 07:16:14.990979+00",)	f
19	Project	2	2		2026-04-10 07:16:15.320386+00	1	2026-04-10 07:16:15.320386+00	Journal::ProjectJournal	3	{}	["2026-04-10 07:16:15.320386+00",)	f
20	News	2	2		2026-04-10 07:16:15.408097+00	1	2026-04-10 07:16:15.408097+00	Journal::NewsJournal	2	{}	["2026-04-10 07:16:15.408097+00",)	f
21	WikiPage	2	2		2026-04-10 07:16:15.505935+00	1	2026-04-10 07:16:15.505935+00	Journal::WikiPageJournal	2	{}	["2026-04-10 07:16:15.505935+00",)	f
22	WikiPage	3	2		2026-04-10 07:16:15.705957+00	1	2026-04-10 07:16:15.705957+00	Journal::WikiPageJournal	3	{}	["2026-04-10 07:16:15.705957+00",)	f
23	WorkPackage	14	2		2026-04-10 07:16:15.758136+00	1	2026-04-10 07:16:15.758136+00	Journal::WorkPackageJournal	22	{}	["2026-04-10 07:16:15.758136+00",)	f
24	WorkPackage	15	2		2026-04-10 07:16:15.856276+00	1	2026-04-10 07:16:15.856276+00	Journal::WorkPackageJournal	23	{}	["2026-04-10 07:16:15.856276+00",)	f
25	WorkPackage	16	2		2026-04-10 07:16:15.948314+00	1	2026-04-10 07:16:15.948314+00	Journal::WorkPackageJournal	24	{}	["2026-04-10 07:16:15.948314+00",)	f
26	WorkPackage	17	2		2026-04-10 07:16:16.024391+00	1	2026-04-10 07:16:16.118579+00	Journal::WorkPackageJournal	26	{}	["2026-04-10 07:16:16.024391+00",)	f
27	WorkPackage	18	2		2026-04-10 07:16:16.200444+00	1	2026-04-10 07:16:16.279268+00	Journal::WorkPackageJournal	28	{}	["2026-04-10 07:16:16.200444+00",)	f
29	WorkPackage	20	2		2026-04-10 07:16:16.414831+00	1	2026-04-10 07:16:16.48685+00	Journal::WorkPackageJournal	31	{}	["2026-04-10 07:16:16.414831+00",)	f
28	WorkPackage	19	2		2026-04-10 07:16:16.347218+00	1	2026-04-10 07:16:16.564239+00	Journal::WorkPackageJournal	32	{}	["2026-04-10 07:16:16.347218+00",)	f
30	WorkPackage	21	2		2026-04-10 07:16:16.647326+00	1	2026-04-10 07:16:16.647326+00	Journal::WorkPackageJournal	33	{}	["2026-04-10 07:16:16.647326+00",)	f
31	WorkPackage	22	2		2026-04-10 07:16:16.72846+00	1	2026-04-10 07:16:16.72846+00	Journal::WorkPackageJournal	34	{}	["2026-04-10 07:16:16.72846+00",)	f
32	WorkPackage	23	2		2026-04-10 07:16:16.80073+00	1	2026-04-10 07:16:16.872802+00	Journal::WorkPackageJournal	36	{}	["2026-04-10 07:16:16.80073+00",)	f
33	WorkPackage	24	2		2026-04-10 07:16:16.951956+00	1	2026-04-10 07:16:16.951956+00	Journal::WorkPackageJournal	37	{}	["2026-04-10 07:16:16.951956+00",)	f
34	WorkPackage	25	2		2026-04-10 07:16:17.047257+00	1	2026-04-10 07:16:17.047257+00	Journal::WorkPackageJournal	38	{}	["2026-04-10 07:16:17.047257+00",)	f
35	WorkPackage	26	2		2026-04-10 07:16:17.158961+00	1	2026-04-10 07:16:17.158961+00	Journal::WorkPackageJournal	39	{}	["2026-04-10 07:16:17.158961+00",)	f
36	WorkPackage	27	2		2026-04-10 07:16:17.241532+00	1	2026-04-10 07:16:17.241532+00	Journal::WorkPackageJournal	40	{}	["2026-04-10 07:16:17.241532+00",)	f
37	WorkPackage	28	2		2026-04-10 07:16:17.322536+00	1	2026-04-10 07:16:17.322536+00	Journal::WorkPackageJournal	41	{}	["2026-04-10 07:16:17.322536+00",)	f
38	WorkPackage	29	2		2026-04-10 07:16:17.455261+00	1	2026-04-10 07:16:17.539984+00	Journal::WorkPackageJournal	43	{}	["2026-04-10 07:16:17.455261+00",)	f
39	WorkPackage	30	2		2026-04-10 07:16:17.625255+00	1	2026-04-10 07:16:17.625255+00	Journal::WorkPackageJournal	44	{}	["2026-04-10 07:16:17.625255+00",)	f
40	WorkPackage	31	2		2026-04-10 07:16:17.709674+00	1	2026-04-10 07:16:17.709674+00	Journal::WorkPackageJournal	45	{}	["2026-04-10 07:16:17.709674+00",)	f
41	WorkPackage	32	2		2026-04-10 07:16:17.784827+00	1	2026-04-10 07:16:17.784827+00	Journal::WorkPackageJournal	46	{}	["2026-04-10 07:16:17.784827+00",)	f
42	WorkPackage	33	2		2026-04-10 07:16:17.862116+00	1	2026-04-10 07:16:17.862116+00	Journal::WorkPackageJournal	47	{}	["2026-04-10 07:16:17.862116+00",)	f
43	WorkPackage	34	2		2026-04-10 07:16:17.936696+00	1	2026-04-10 07:16:17.936696+00	Journal::WorkPackageJournal	48	{}	["2026-04-10 07:16:17.936696+00",)	f
44	WorkPackage	35	2		2026-04-10 07:16:18.013667+00	1	2026-04-10 07:16:18.013667+00	Journal::WorkPackageJournal	49	{}	["2026-04-10 07:16:18.013667+00",)	f
45	WorkPackage	36	2		2026-04-10 07:16:18.10817+00	1	2026-04-10 07:16:18.10817+00	Journal::WorkPackageJournal	50	{}	["2026-04-10 07:16:18.10817+00",)	f
46	Attachment	1	2		2026-04-10 07:16:18.437258+00	1	2026-04-10 07:16:18.437258+00	Journal::AttachmentJournal	1	{}	["2026-04-10 07:16:18.437258+00",)	f
47	Attachment	2	2		2026-04-10 07:16:18.510751+00	1	2026-04-10 07:16:18.510751+00	Journal::AttachmentJournal	2	{}	["2026-04-10 07:16:18.510751+00",)	f
48	Meeting	2	1		2026-04-10 07:17:15.632124+00	1	2026-04-10 07:17:15.632124+00	Journal::MeetingJournal	2	{}	["2026-04-10 07:17:15.632124+00",)	f
49	Project	3	4		2026-04-10 07:32:56.630128+00	1	2026-04-10 07:32:56.630128+00	Journal::ProjectJournal	4	{}	["2026-04-10 07:32:56.630128+00",)	f
53	WorkPackage	40	4		2026-04-10 07:33:00.022549+00	1	2026-04-10 07:33:00.022549+00	Journal::WorkPackageJournal	54	{}	["2026-04-10 07:33:00.022549+00",)	f
54	WorkPackage	41	4		2026-04-10 07:33:00.426725+00	1	2026-04-10 07:33:00.426725+00	Journal::WorkPackageJournal	57	{}	["2026-04-10 07:33:00.426725+00",)	f
50	WorkPackage	37	4	_Updated automatically by changing values within child work package #40_\n	2026-04-10 07:32:59.024492+00	1	2026-04-10 07:33:00.113556+00	Journal::WorkPackageJournal	56	{}	["2026-04-10 07:32:59.024492+00","2026-04-10 07:33:00.455963+00")	f
55	WorkPackage	37	4	_Updated automatically by changing values within child work package #41_\n	2026-04-10 07:33:00.455963+00	2	2026-04-10 07:33:00.484443+00	Journal::WorkPackageJournal	59	{}	["2026-04-10 07:33:00.455963+00",)	f
56	WorkPackage	42	4		2026-04-10 07:33:01.055121+00	1	2026-04-10 07:33:01.055121+00	Journal::WorkPackageJournal	60	{}	["2026-04-10 07:33:01.055121+00",)	f
57	WorkPackage	43	4		2026-04-10 07:33:01.683093+00	1	2026-04-10 07:33:01.683093+00	Journal::WorkPackageJournal	63	{}	["2026-04-10 07:33:01.683093+00",)	f
51	WorkPackage	38	4	_Updated automatically by changing values within child work package #42_\n	2026-04-10 07:32:59.364021+00	1	2026-04-10 07:33:01.161862+00	Journal::WorkPackageJournal	62	{}	["2026-04-10 07:32:59.364021+00","2026-04-10 07:33:01.718837+00")	f
59	WorkPackage	44	4		2026-04-10 07:33:02.033242+00	1	2026-04-10 07:33:02.033242+00	Journal::WorkPackageJournal	65	{}	["2026-04-10 07:33:02.033242+00",)	f
60	WorkPackage	38	4	_Updated automatically by changing values within child work package #44_\n	2026-04-10 07:33:02.066823+00	3	2026-04-10 07:33:02.066823+00	Journal::WorkPackageJournal	66	{}	["2026-04-10 07:33:02.066823+00",)	f
58	WorkPackage	38	4	_Updated automatically by changing values within child work package #43_\n	2026-04-10 07:33:01.718837+00	2	2026-04-10 07:33:01.718837+00	Journal::WorkPackageJournal	64	{}	["2026-04-10 07:33:01.718837+00","2026-04-10 07:33:02.066823+00")	f
61	WorkPackage	45	4		2026-04-10 07:33:02.377493+00	1	2026-04-10 07:33:02.377493+00	Journal::WorkPackageJournal	67	{}	["2026-04-10 07:33:02.377493+00",)	f
52	WorkPackage	39	4	_Updated automatically by changing values within child work package #45_\n	2026-04-10 07:32:59.721858+00	1	2026-04-10 07:33:02.449545+00	Journal::WorkPackageJournal	69	{}	["2026-04-10 07:32:59.721858+00",)	f
62	Meeting	3	1		2026-05-04 07:50:43.971731+00	1	2026-05-04 07:50:43.971731+00	Journal::MeetingJournal	3	{}	["2026-05-04 07:50:43.971731+00",)	f
63	Meeting	4	1		2026-05-04 07:50:47.29963+00	1	2026-05-04 07:50:47.29963+00	Journal::MeetingJournal	4	{}	["2026-05-04 07:50:47.29963+00",)	f
64	Meeting	5	1		2026-05-04 07:50:50.464339+00	1	2026-05-04 07:50:50.464339+00	Journal::MeetingJournal	5	{}	["2026-05-04 07:50:50.464339+00",)	f
\.


--
-- Data for Name: labor_budget_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.labor_budget_items (id, budget_id, hours, user_id, comments, amount) FROM stdin;
\.


--
-- Data for Name: last_project_folders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.last_project_folders (id, project_storage_id, origin_folder_id, mode, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ldap_auth_sources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ldap_auth_sources (id, name, host, port, account, account_password, base_dn, attr_login, attr_firstname, attr_lastname, attr_mail, onthefly_register, attr_admin, created_at, updated_at, tls_mode, filter_string, verify_peer, tls_certificate_string) FROM stdin;
\.


--
-- Data for Name: ldap_groups_memberships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ldap_groups_memberships (id, user_id, group_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ldap_groups_synchronized_filters; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ldap_groups_synchronized_filters (id, name, group_name_attribute, filter_string, ldap_auth_source_id, created_at, updated_at, base_dn, sync_users) FROM stdin;
\.


--
-- Data for Name: ldap_groups_synchronized_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ldap_groups_synchronized_groups (id, group_id, ldap_auth_source_id, created_at, updated_at, dn, users_count, filter_id, sync_users) FROM stdin;
\.


--
-- Data for Name: material_budget_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.material_budget_items (id, budget_id, units, cost_type_id, comments, amount) FROM stdin;
\.


--
-- Data for Name: mcp_configurations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mcp_configurations (id, identifier, title, description, enabled, created_at, updated_at) FROM stdin;
1	mcp_server	OpenProject	Performs project management tasks on the given installation of OpenProject.	t	2026-04-10 07:16:18.580022+00	2026-04-10 07:16:18.580022+00
2	tools/current_user	Current user	Returns the currently authenticated user. Also available as an MCP resource.	t	2026-04-10 07:16:18.665026+00	2026-04-10 07:16:18.665026+00
3	tools/list_statuses	List statuses	Lists all work package statuses available on this OpenProject instance. Also available as an MCP resource.	t	2026-04-10 07:16:18.667003+00	2026-04-10 07:16:18.667003+00
4	tools/list_types	List types	Lists all work package types available on this OpenProject instance. Also available as an MCP resource.	t	2026-04-10 07:16:18.668102+00	2026-04-10 07:16:18.668102+00
5	tools/search_projects	Search projects	Search projects matching all of the passed input parameters. Parameters not passed are ignored. Results are limited to a maximum of 100 projects. To get the rest of the results, call the tool again with apage number of 2 or higher.	t	2026-04-10 07:16:18.669057+00	2026-04-10 07:16:18.669057+00
6	tools/search_users	Search users	Search users matching all of the passed input parameters. Parameters not passed are ignored. Results are limited to a maximum of 100 users. To get the rest of the results, call the tool again with a page number of 2 or higher.	t	2026-04-10 07:16:18.669851+00	2026-04-10 07:16:18.669851+00
7	tools/search_work_packages	Search work packages	Search work packages matching all of the passed input parameters. Parameters not passed are ignored. Results are limited to a maximum of 100 work packages. To get the rest of the results, call the tool again with apage number of 2 or higher.	t	2026-04-10 07:16:18.670645+00	2026-04-10 07:16:18.670645+00
8	resources/current_user	Current user	Representation of the currently authenticated user.	t	2026-04-10 07:16:18.671388+00	2026-04-10 07:16:18.671388+00
9	resources/project	Project	Access projects of this OpenProject instance.	t	2026-04-10 07:16:18.672174+00	2026-04-10 07:16:18.672174+00
10	resources/status	Work Package Status	Access work package statuses of this OpenProject instance.	t	2026-04-10 07:16:18.672912+00	2026-04-10 07:16:18.672912+00
11	resources/status_list	Work Package Statuses List	A list of all work package statuses configured in this OpenProject instance.	t	2026-04-10 07:16:18.673846+00	2026-04-10 07:16:18.673846+00
12	resources/type	Work Package Type	Access work package types of this OpenProject instance.	t	2026-04-10 07:16:18.674573+00	2026-04-10 07:16:18.674573+00
13	resources/type_list	Work Package Types List	A list of all work package types configured in this OpenProject instance.	t	2026-04-10 07:16:18.675317+00	2026-04-10 07:16:18.675317+00
14	resources/user	User	Access users of this OpenProject instance.	t	2026-04-10 07:16:18.676256+00	2026-04-10 07:16:18.676256+00
15	resources/version	Work Package Version	Access work package versions of this OpenProject instance.	t	2026-04-10 07:16:18.677356+00	2026-04-10 07:16:18.677356+00
16	resources/work_package	Work Package	Access work packages of this OpenProject instance.	t	2026-04-10 07:16:18.678149+00	2026-04-10 07:16:18.678149+00
17	tools/search_portfolios	Search portfolios	Search portfolios matching all of the passed input parameters. Parameters not passed are ignored. Results are limited to a maximum of 100 portfolios. To get the rest of the results, call the tool again with apage number of 2 or higher.	t	2026-05-04 07:50:11.081519+00	2026-05-04 07:50:11.081519+00
18	tools/search_programs	Search programs	Search programs matching all of the passed input parameters. Parameters not passed are ignored. Results are limited to a maximum of 100 programs. To get the rest of the results, call the tool again with apage number of 2 or higher.	t	2026-05-04 07:50:11.107228+00	2026-05-04 07:50:11.107228+00
19	tools/search_versions	Search versions	Search versions matching all of the passed input parameters. Parameters not passed are ignored. Results are limited to a maximum of 100 versions. To get the rest of the results, call the tool again with apage number of 2 or higher.	t	2026-05-04 07:50:11.109686+00	2026-05-04 07:50:11.109686+00
\.


--
-- Data for Name: meeting_agenda_item_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meeting_agenda_item_journals (id, journal_id, agenda_item_id, author_id, title, notes, "position", duration_in_minutes, work_package_id, item_type, presenter_id) FROM stdin;
\.


--
-- Data for Name: meeting_agenda_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meeting_agenda_items (id, meeting_id, author_id, title, notes, "position", duration_in_minutes, created_at, updated_at, work_package_id, item_type, lock_version, presenter_id, meeting_section_id) FROM stdin;
1	1	4	Good news	What went well this week?	1	5	2026-04-10 07:16:15.256429	2026-04-10 07:16:15.256429	\N	0	0	4	2
2	1	4	Updates from development team	News and focused topics for the upcoming week.	2	5	2026-04-10 07:16:15.265459	2026-04-10 07:16:15.265459	\N	0	0	4	2
3	1	4	Updates from product team	News and focused topics for the upcoming week.	3	5	2026-04-10 07:16:15.269739	2026-04-10 07:16:15.269739	\N	0	0	4	2
4	1	4	Updates from marketing team	News and focused topics for the upcoming week.	4	5	2026-04-10 07:16:15.273771	2026-04-10 07:16:15.273771	\N	0	0	4	2
5	1	4	\N	**Today's topic**: Organizing the open-source conference.	5	5	2026-04-10 07:16:15.277868	2026-04-10 07:16:15.277868	2	1	0	4	2
6	1	4	Updates from sales team	News and focused topics for the upcoming week.	6	5	2026-04-10 07:16:15.282413	2026-04-10 07:16:15.282413	\N	0	0	4	2
7	1	4	Review of quarterly goals	Assessing the status and progress of the defined quarterly goals.	7	5	2026-04-10 07:16:15.287398	2026-04-10 07:16:15.287398	\N	0	0	4	2
8	1	4	Core values feedback	Highlight employees who have lived the core values this week.	8	5	2026-04-10 07:16:15.291394	2026-04-10 07:16:15.291394	\N	0	0	4	2
9	1	4	General topics	Solving or discussing topics together.	9	20	2026-04-10 07:16:15.296277	2026-04-10 07:16:15.296277	\N	0	0	4	2
10	2	4	Good news	What went well this week?	1	5	2026-04-10 07:17:15.830085	2026-04-10 07:17:15.830085	\N	0	0	4	4
11	2	4	Updates from development team	News and focused topics for the upcoming week.	2	5	2026-04-10 07:17:15.854624	2026-04-10 07:17:15.854624	\N	0	0	4	4
12	2	4	Updates from product team	News and focused topics for the upcoming week.	3	5	2026-04-10 07:17:15.871168	2026-04-10 07:17:15.871168	\N	0	0	4	4
13	2	4	Updates from marketing team	News and focused topics for the upcoming week.	4	5	2026-04-10 07:17:15.886338	2026-04-10 07:17:15.886338	\N	0	0	4	4
14	2	4	\N	**Today's topic**: Organizing the open-source conference.	5	5	2026-04-10 07:17:15.901724	2026-04-10 07:17:15.901724	2	1	0	4	4
15	2	4	Updates from sales team	News and focused topics for the upcoming week.	6	5	2026-04-10 07:17:15.921891	2026-04-10 07:17:15.921891	\N	0	0	4	4
16	2	4	Review of quarterly goals	Assessing the status and progress of the defined quarterly goals.	7	5	2026-04-10 07:17:15.938669	2026-04-10 07:17:15.938669	\N	0	0	4	4
17	2	4	Core values feedback	Highlight employees who have lived the core values this week.	8	5	2026-04-10 07:17:15.951154	2026-04-10 07:17:15.951154	\N	0	0	4	4
18	2	4	General topics	Solving or discussing topics together.	9	20	2026-04-10 07:17:15.962459	2026-04-10 07:17:15.962459	\N	0	0	4	4
19	3	4	Good news	What went well this week?	1	5	2026-05-04 07:50:44.279132	2026-05-04 07:50:44.279132	\N	0	0	4	6
20	3	4	Updates from development team	News and focused topics for the upcoming week.	2	5	2026-05-04 07:50:44.300403	2026-05-04 07:50:44.300403	\N	0	0	4	6
21	3	4	Updates from product team	News and focused topics for the upcoming week.	3	5	2026-05-04 07:50:44.325739	2026-05-04 07:50:44.325739	\N	0	0	4	6
22	3	4	Updates from marketing team	News and focused topics for the upcoming week.	4	5	2026-05-04 07:50:44.347421	2026-05-04 07:50:44.347421	\N	0	0	4	6
23	3	4	\N	**Today's topic**: Organizing the open-source conference.	5	5	2026-05-04 07:50:44.36807	2026-05-04 07:50:44.36807	2	1	0	4	6
24	3	4	Updates from sales team	News and focused topics for the upcoming week.	6	5	2026-05-04 07:50:44.383717	2026-05-04 07:50:44.383717	\N	0	0	4	6
25	3	4	Review of quarterly goals	Assessing the status and progress of the defined quarterly goals.	7	5	2026-05-04 07:50:44.400045	2026-05-04 07:50:44.400045	\N	0	0	4	6
26	3	4	Core values feedback	Highlight employees who have lived the core values this week.	8	5	2026-05-04 07:50:44.415367	2026-05-04 07:50:44.415367	\N	0	0	4	6
27	3	4	General topics	Solving or discussing topics together.	9	20	2026-05-04 07:50:44.428193	2026-05-04 07:50:44.428193	\N	0	0	4	6
28	4	4	Good news	What went well this week?	1	5	2026-05-04 07:50:47.414984	2026-05-04 07:50:47.414984	\N	0	0	4	8
29	4	4	Updates from development team	News and focused topics for the upcoming week.	2	5	2026-05-04 07:50:47.430279	2026-05-04 07:50:47.430279	\N	0	0	4	8
30	4	4	Updates from product team	News and focused topics for the upcoming week.	3	5	2026-05-04 07:50:47.444189	2026-05-04 07:50:47.444189	\N	0	0	4	8
31	4	4	Updates from marketing team	News and focused topics for the upcoming week.	4	5	2026-05-04 07:50:47.456245	2026-05-04 07:50:47.456245	\N	0	0	4	8
32	4	4	\N	**Today's topic**: Organizing the open-source conference.	5	5	2026-05-04 07:50:47.467946	2026-05-04 07:50:47.467946	2	1	0	4	8
33	4	4	Updates from sales team	News and focused topics for the upcoming week.	6	5	2026-05-04 07:50:47.482249	2026-05-04 07:50:47.482249	\N	0	0	4	8
34	4	4	Review of quarterly goals	Assessing the status and progress of the defined quarterly goals.	7	5	2026-05-04 07:50:47.49384	2026-05-04 07:50:47.49384	\N	0	0	4	8
35	4	4	Core values feedback	Highlight employees who have lived the core values this week.	8	5	2026-05-04 07:50:47.510948	2026-05-04 07:50:47.510948	\N	0	0	4	8
36	4	4	General topics	Solving or discussing topics together.	9	20	2026-05-04 07:50:47.523443	2026-05-04 07:50:47.523443	\N	0	0	4	8
37	5	4	Good news	What went well this week?	1	5	2026-05-04 07:50:50.563565	2026-05-04 07:50:50.563565	\N	0	0	4	10
38	5	4	Updates from development team	News and focused topics for the upcoming week.	2	5	2026-05-04 07:50:50.572404	2026-05-04 07:50:50.572404	\N	0	0	4	10
39	5	4	Updates from product team	News and focused topics for the upcoming week.	3	5	2026-05-04 07:50:50.587899	2026-05-04 07:50:50.587899	\N	0	0	4	10
40	5	4	Updates from marketing team	News and focused topics for the upcoming week.	4	5	2026-05-04 07:50:50.597684	2026-05-04 07:50:50.597684	\N	0	0	4	10
41	5	4	\N	**Today's topic**: Organizing the open-source conference.	5	5	2026-05-04 07:50:50.606207	2026-05-04 07:50:50.606207	2	1	0	4	10
42	5	4	Updates from sales team	News and focused topics for the upcoming week.	6	5	2026-05-04 07:50:50.614115	2026-05-04 07:50:50.614115	\N	0	0	4	10
43	5	4	Review of quarterly goals	Assessing the status and progress of the defined quarterly goals.	7	5	2026-05-04 07:50:50.621966	2026-05-04 07:50:50.621966	\N	0	0	4	10
44	5	4	Core values feedback	Highlight employees who have lived the core values this week.	8	5	2026-05-04 07:50:50.630899	2026-05-04 07:50:50.630899	\N	0	0	4	10
45	5	4	General topics	Solving or discussing topics together.	9	20	2026-05-04 07:50:50.63915	2026-05-04 07:50:50.63915	\N	0	0	4	10
\.


--
-- Data for Name: meeting_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meeting_journals (id, title, author_id, project_id, location, start_time, duration, state) FROM stdin;
1	Weekly	4	1	\N	2026-04-13 17:16:14.94404+00	1	1
2	Weekly	1	1	\N	2026-04-13 17:16:14.917368+00	1	0
3	Weekly	1	1	\N	2026-04-20 17:16:14.917368+00	1	0
4	Weekly	1	1	\N	2026-04-27 17:16:14.917368+00	1	0
5	Weekly	1	1	\N	2026-05-04 17:16:14.917368+00	1	0
\.


--
-- Data for Name: meeting_outcomes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meeting_outcomes (id, notes, meeting_agenda_item_id, work_package_id, kind, created_at, updated_at, author_id) FROM stdin;
\.


--
-- Data for Name: meeting_participants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meeting_participants (id, user_id, meeting_id, email, name, invited, attended, created_at, updated_at, participation_status, comment) FROM stdin;
1	4	1	\N	\N	t	\N	2026-04-10 07:16:14.994203+00	2026-04-10 07:16:14.994203+00	needs-action	\N
2	4	2	\N	\N	t	\N	2026-04-10 07:17:15.640048+00	2026-04-10 07:17:15.640048+00	needs-action	\N
3	4	3	\N	\N	t	\N	2026-05-04 07:50:43.993722+00	2026-05-04 07:50:43.993722+00	needs-action	\N
4	4	4	\N	\N	t	\N	2026-05-04 07:50:47.306688+00	2026-05-04 07:50:47.306688+00	needs-action	\N
5	4	5	\N	\N	t	\N	2026-05-04 07:50:50.465447+00	2026-05-04 07:50:50.465447+00	needs-action	\N
\.


--
-- Data for Name: meeting_sections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meeting_sections (id, "position", title, meeting_id, created_at, updated_at, backlog) FROM stdin;
1	1	Agenda backlog	1	2026-04-10 07:16:15.101167+00	2026-04-10 07:16:15.101167+00	t
2	1		1	2026-04-10 07:16:15.252114+00	2026-04-10 07:16:15.252114+00	f
3	1	Agenda backlog	2	2026-04-10 07:17:15.745559+00	2026-04-10 07:17:15.745559+00	t
4	1		2	2026-04-10 07:17:15.768872+00	2026-04-10 07:17:15.768872+00	f
5	1	Agenda backlog	3	2026-05-04 07:50:44.172784+00	2026-05-04 07:50:44.172784+00	t
6	1		3	2026-05-04 07:50:44.205092+00	2026-05-04 07:50:44.205092+00	f
7	1	Agenda backlog	4	2026-05-04 07:50:47.365758+00	2026-05-04 07:50:47.365758+00	t
8	1		4	2026-05-04 07:50:47.377785+00	2026-05-04 07:50:47.377785+00	f
9	1	Agenda backlog	5	2026-05-04 07:50:50.527381+00	2026-05-04 07:50:50.527381+00	t
10	1		5	2026-05-04 07:50:50.541296+00	2026-05-04 07:50:50.541296+00	f
\.


--
-- Data for Name: meetings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.meetings (id, title, author_id, project_id, location, start_time, duration, created_at, updated_at, state, lock_version, recurring_meeting_id, template, uid, notify) FROM stdin;
1	Weekly	4	1	\N	2026-04-13 17:16:14.94404+00	1	2026-04-10 07:16:14.990979+00	2026-04-10 07:16:14.990979+00	1	0	1	t	91e750ba-5fae-4e86-87a6-48868b90a4aa@localhost:8092	f
2	Weekly	1	1	\N	2026-04-13 17:16:14.917368+00	1	2026-04-10 07:17:15.632124+00	2026-04-10 07:17:15.632124+00	0	0	1	f	7ba7b592-4349-42a3-a6ff-f5ca0629ab30@localhost:8092	f
3	Weekly	1	1	\N	2026-04-20 17:16:14.917368+00	1	2026-05-04 07:50:43.971731+00	2026-05-04 07:50:43.971731+00	0	0	1	f	6e450bb1-9cde-4353-ad41-f4025d108285@localhost:8443	f
4	Weekly	1	1	\N	2026-04-27 17:16:14.917368+00	1	2026-05-04 07:50:47.29963+00	2026-05-04 07:50:47.29963+00	0	0	1	f	546ed074-5320-49bd-ae20-e6f8142edc99@localhost:8443	f
5	Weekly	1	1	\N	2026-05-04 17:16:14.917368+00	1	2026-05-04 07:50:50.464339+00	2026-05-04 07:50:50.464339+00	0	0	1	f	4e16d57f-0882-47a1-b7ba-3cd6b107c323@localhost:8443	f
\.


--
-- Data for Name: member_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_roles (id, member_id, role_id, inherited_from) FROM stdin;
1	1	5	\N
2	2	5	\N
3	3	5	\N
4	7	5	3
5	5	5	3
6	6	5	3
7	4	5	3
8	8	5	\N
\.


--
-- Data for Name: members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.members (id, user_id, project_id, created_at, updated_at, entity_type, entity_id) FROM stdin;
1	4	1	2026-04-10 07:16:12.108666+00	2026-04-10 07:16:12.114028+00	\N	\N
2	4	2	2026-04-10 07:16:15.406002+00	2026-04-10 07:16:15.407503+00	\N	\N
3	9	3	2026-04-10 07:32:58.494651+00	2026-04-10 07:32:58.498174+00	\N	\N
4	5	3	2026-04-10 07:32:58.514866+00	2026-04-10 07:32:58.514866+00	\N	\N
5	8	3	2026-04-10 07:32:58.514866+00	2026-04-10 07:32:58.514866+00	\N	\N
6	6	3	2026-04-10 07:32:58.514866+00	2026-04-10 07:32:58.514866+00	\N	\N
7	7	3	2026-04-10 07:32:58.514866+00	2026-04-10 07:32:58.514866+00	\N	\N
8	4	3	2026-04-10 07:32:58.666006+00	2026-04-10 07:32:58.667511+00	\N	\N
\.


--
-- Data for Name: menu_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.menu_items (id, name, title, parent_id, options, navigatable_id, type) FROM stdin;
1	wiki	Wiki	\N	---\n:new_wiki_page: true\n:index_page: true\n	1	MenuItems::WikiMenuItem
2	wiki	Wiki	\N	---\n:new_wiki_page: true\n:index_page: true\n	2	MenuItems::WikiMenuItem
3	wiki	Wiki	\N	---\n:new_wiki_page: true\n:index_page: true\n	3	MenuItems::WikiMenuItem
\.


--
-- Data for Name: message_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_journals (id, forum_id, parent_id, subject, content, author_id, locked, sticky) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.messages (id, forum_id, parent_id, subject, content, author_id, replies_count, last_reply_id, created_at, updated_at, locked, sticky, sticked_on) FROM stdin;
\.


--
-- Data for Name: news; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.news (id, project_id, title, summary, description, author_id, created_at, comments_count, updated_at) FROM stdin;
1	1	Welcome to your demo project	We are glad you joined.\nIn this module you can communicate project news to your team members.\n	The actual news	4	2026-04-10 07:16:12.121164+00	0	2026-04-10 07:16:12.121164+00
2	2	Welcome to your Scrum demo project	We are glad you joined.\nIn this module you can communicate project news to your team members.\n	This is the news content.	4	2026-04-10 07:16:15.408097+00	0	2026-04-10 07:16:15.408097+00
\.


--
-- Data for Name: news_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.news_journals (id, project_id, title, summary, description, author_id, comments_count) FROM stdin;
1	1	Welcome to your demo project	We are glad you joined.\nIn this module you can communicate project news to your team members.\n	The actual news	4	0
2	2	Welcome to your Scrum demo project	We are glad you joined.\nIn this module you can communicate project news to your team members.\n	This is the news content.	4	0
\.


--
-- Data for Name: non_working_days; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.non_working_days (id, name, date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_settings (id, project_id, user_id, watched, mentioned, created_at, updated_at, work_package_commented, work_package_created, work_package_processed, work_package_prioritized, work_package_scheduled, news_added, news_commented, document_added, forum_messages, wiki_page_added, wiki_page_updated, membership_added, membership_updated, start_date, due_date, overdue, assignee, responsible, shared) FROM stdin;
1	\N	4	t	t	2026-04-10 07:16:11.194784+00	2026-04-10 07:16:11.194784+00	f	f	f	f	f	f	f	f	f	f	f	f	f	1	1	\N	t	t	t
2	\N	5	t	t	2026-04-10 07:32:56.974298+00	2026-04-10 07:32:56.974298+00	f	f	f	f	f	f	f	f	f	f	f	f	f	1	1	\N	t	t	t
3	\N	6	t	t	2026-04-10 07:32:57.257614+00	2026-04-10 07:32:57.257614+00	f	f	f	f	f	f	f	f	f	f	f	f	f	1	1	\N	t	t	t
4	\N	7	t	t	2026-04-10 07:32:57.536787+00	2026-04-10 07:32:57.536787+00	f	f	f	f	f	f	f	f	f	f	f	f	f	1	1	\N	t	t	t
5	\N	8	t	t	2026-04-10 07:32:57.827235+00	2026-04-10 07:32:57.827235+00	f	f	f	f	f	f	f	f	f	f	f	f	f	1	1	\N	t	t	t
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, subject, read_ian, reason, recipient_id, actor_id, resource_type, resource_id, journal_id, created_at, updated_at, mail_reminder_sent, mail_alert_sent) FROM stdin;
2	\N	f	1	6	4	WorkPackage	38	51	2026-04-10 07:32:59.48173+00	2026-05-04 08:00:01.240045+00	t	\N
9	\N	f	1	6	4	WorkPackage	43	57	2026-04-10 07:33:01.857167+00	2026-05-04 08:00:01.240045+00	t	\N
10	\N	f	1	6	4	WorkPackage	38	58	2026-04-10 07:33:01.882146+00	2026-05-04 08:00:01.240045+00	t	\N
12	\N	f	1	6	4	WorkPackage	38	60	2026-04-10 07:33:02.221779+00	2026-05-04 08:00:01.240045+00	t	\N
4	\N	f	1	7	4	WorkPackage	40	53	2026-04-10 07:33:00.297907+00	2026-05-04 08:00:01.248459+00	t	\N
11	\N	f	1	7	4	WorkPackage	44	59	2026-04-10 07:33:02.199574+00	2026-05-04 08:00:01.248459+00	t	\N
1	\N	f	1	5	4	WorkPackage	37	50	2026-04-10 07:32:59.325914+00	2026-05-04 08:00:01.253552+00	t	\N
3	\N	f	1	5	4	WorkPackage	39	52	2026-04-10 07:32:59.92406+00	2026-05-04 08:00:01.253552+00	t	\N
6	\N	f	1	5	4	WorkPackage	37	55	2026-04-10 07:33:00.710033+00	2026-05-04 08:00:01.253552+00	t	\N
7	\N	f	1	5	4	WorkPackage	37	55	2026-04-10 07:33:00.7179+00	2026-05-04 08:00:01.253552+00	t	\N
8	\N	f	1	5	4	WorkPackage	42	56	2026-04-10 07:33:01.305126+00	2026-05-04 08:00:01.253552+00	t	\N
5	\N	f	1	8	4	WorkPackage	41	54	2026-04-10 07:33:00.684495+00	2026-05-04 08:00:01.314341+00	t	\N
13	\N	f	1	8	4	WorkPackage	45	61	2026-04-10 07:33:02.578489+00	2026-05-04 08:00:01.314341+00	t	\N
\.


--
-- Data for Name: oauth_access_grants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_access_grants (id, resource_owner_id, application_id, token, expires_in, redirect_uri, created_at, revoked_at, scopes, code_challenge, code_challenge_method) FROM stdin;
\.


--
-- Data for Name: oauth_access_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_access_tokens (id, resource_owner_id, application_id, token, refresh_token, expires_in, revoked_at, created_at, scopes, previous_refresh_token) FROM stdin;
\.


--
-- Data for Name: oauth_applications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_applications (id, name, uid, secret, owner_type, owner_id, client_credentials_user_id, redirect_uri, scopes, confidential, created_at, updated_at, integration_type, integration_id, enabled, builtin) FROM stdin;
1	OpenProject Mobile App	DgJZ7Rat23xHZbcq_nxPg5RUuxljonLCN7V7N7GoBAA	f2d308f5644cdd0dd68a5c1b0f37b3f7fdce59322d93b873c26c5e89120d7ee7	User	1	\N	openprojectapp://oauth-callback		f	2026-04-10 07:16:11.542634+00	2026-04-10 07:16:11.542634+00	\N	\N	f	t
\.


--
-- Data for Name: oauth_client_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_client_tokens (id, oauth_client_id, user_id, access_token, refresh_token, token_type, expires_in, scope, created_at, updated_at, lock_version) FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_clients (id, client_id, client_secret, integration_type, integration_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: oidc_group_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oidc_group_links (id, group_id, auth_provider_id, oidc_group_name, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: oidc_group_memberships; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oidc_group_memberships (id, auth_provider_id, group_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: oidc_user_session_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oidc_user_session_links (id, oidc_session, session_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: oidc_user_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oidc_user_tokens (id, user_id, access_token, refresh_token, audiences, created_at, updated_at, expires_at) FROM stdin;
\.


--
-- Data for Name: ordered_work_packages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ordered_work_packages (id, "position", query_id, work_package_id) FROM stdin;
1	0	9	8
2	1	9	11
3	0	10	7
4	0	11	3
5	0	23	16
6	1	23	25
7	2	23	27
8	0	24	14
9	0	25	26
10	0	26	24
\.


--
-- Data for Name: paper_trail_audits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.paper_trail_audits (id, item_type, item_id, event, whodunnit, stack, object, object_changes, created_at) FROM stdin;
\.


--
-- Data for Name: project_custom_field_project_mappings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_custom_field_project_mappings (id, custom_field_id, project_id, created_at, updated_at, creation_wizard) FROM stdin;
\.


--
-- Data for Name: project_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_journals (id, name, description, public, parent_id, identifier, active, templated, status_code, status_explanation, workspace_type) FROM stdin;
1	Demo project	This is a short summary of the goals of this demo project.	t	\N	demo-project	t	f	0	All tasks are on schedule. The people involved know their tasks. The system is completely set up.	project
2	Demo project	This is a short summary of the goals of this demo project.	t	\N	demo-project	t	f	0	All tasks are on schedule. The people involved know their tasks. The system is completely set up.	project
3	Scrum project	This is a short summary of the goals of this demo Scrum project.	t	\N	your-scrum-project	t	f	0	All tasks are on schedule. The people involved know their tasks. The system is completely set up.	project
4	Workshop Project	Demo project for the OpenProject workshop.	f	\N	workshop-project	t	f	\N		project
\.


--
-- Data for Name: project_phase_definitions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_phase_definitions (id, name, "position", color_id, created_at, updated_at, start_gate, start_gate_name, finish_gate, finish_gate_name) FROM stdin;
1	Initiating	1	145	2026-04-10 07:16:07.931961+00	2026-04-10 07:16:07.931961+00	f	\N	f	\N
2	Planning	2	146	2026-04-10 07:16:07.94477+00	2026-04-10 07:16:07.94477+00	t	Ready for Planning	f	\N
3	Executing	3	147	2026-04-10 07:16:07.951288+00	2026-04-10 07:16:07.951288+00	t	Ready for Executing	f	\N
4	Closing	4	148	2026-04-10 07:16:07.956114+00	2026-04-10 07:16:07.956114+00	t	Ready for Closing	f	\N
\.


--
-- Data for Name: project_phase_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_phase_journals (id, journal_id, phase_id, start_date, finish_date, active, duration) FROM stdin;
1	3	1	\N	\N	t	\N
2	3	2	\N	\N	t	\N
3	3	3	\N	\N	t	\N
4	3	4	\N	\N	t	\N
\.


--
-- Data for Name: project_phases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_phases (id, start_date, finish_date, active, project_id, definition_id, created_at, updated_at, duration) FROM stdin;
1	2026-04-10	2026-05-07	t	1	1	2026-04-10 07:16:06.698791+00	2026-04-10 07:16:12.692914+00	20
2	2026-05-08	2026-06-18	t	1	2	2026-04-10 07:16:06.698791+00	2026-04-10 07:16:12.701447+00	30
3	2026-06-19	2026-08-13	t	1	3	2026-04-10 07:16:06.698791+00	2026-04-10 07:16:12.708192+00	40
4	2026-08-14	2026-08-27	t	1	4	2026-04-10 07:16:06.698791+00	2026-04-10 07:16:12.71552+00	10
\.


--
-- Data for Name: project_queries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_queries (id, name, user_id, filters, selects, orders, created_at, updated_at, public) FROM stdin;
\.


--
-- Data for Name: project_storages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_storages (id, project_id, storage_id, creator_id, created_at, updated_at, project_folder_id, project_folder_mode) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (id, name, description, public, parent_id, created_at, updated_at, identifier, lft, rgt, active, templated, status_code, status_explanation, settings, workspace_type, template_id) FROM stdin;
1	Demo project	This is a short summary of the goals of this demo project.	t	\N	2026-04-10 07:16:11.719906+00	2026-04-10 07:16:12.602091+00	demo-project	1	2	t	f	0	All tasks are on schedule. The people involved know their tasks. The system is completely set up.	{"excluded_role_ids_on_copy": "[]"}	project	\N
2	Scrum project	This is a short summary of the goals of this demo Scrum project.	t	\N	2026-04-10 07:16:15.320386+00	2026-04-10 07:16:15.320386+00	your-scrum-project	3	4	t	f	0	All tasks are on schedule. The people involved know their tasks. The system is completely set up.	{"excluded_role_ids_on_copy": "[]"}	project	\N
3	Workshop Project	Demo project for the OpenProject workshop.	f	\N	2026-04-10 07:32:56.630128+00	2026-04-10 07:32:56.630128+00	workshop-project	5	6	t	f	\N	\N	{"excluded_role_ids_on_copy": "[]"}	project	\N
\.


--
-- Data for Name: projects_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects_types (project_id, type_id) FROM stdin;
1	1
1	2
1	3
2	1
2	2
2	3
2	5
2	6
2	7
3	1
3	2
3	3
\.


--
-- Data for Name: queries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.queries (id, project_id, name, filters, user_id, public, column_names, sort_criteria, group_by, display_sums, timeline_visible, show_hierarchies, timeline_zoom_level, timeline_labels, highlighting_mode, highlighted_attributes, created_at, updated_at, display_representation, starred, include_subprojects, timestamps) FROM stdin;
1	1	Project plan	---\nstatus_id:\n  :operator: o\n  :values: []\n	4	t	---\n- :id\n- :type\n- :subject\n- :status\n- :start_date\n- :due_date\n- :duration\n- :assigned_to\n	---\n- - id\n  - asc\n	\N	f	t	t	5	\N	\N	\N	2026-04-10 07:16:12.419717+00	2026-04-10 07:16:12.419717+00	\N	t	t	\N
2	1	Milestones	---\ntype_id:\n  :operator: "="\n  :values:\n  - '2'\n	4	t	---\n- :id\n- :type\n- :subject\n- :status\n- :start_date\n- :due_date\n	---\n- - id\n  - asc\n	\N	f	t	f	5	\N	\N	\N	2026-04-10 07:16:12.453801+00	2026-04-10 07:16:12.453801+00	\N	f	t	\N
3	1	Tasks	---\nstatus_id:\n  :operator: o\n  :values: []\ntype_id:\n  :operator: "="\n  :values:\n  - '1'\n	4	t	---\n- :id\n- :subject\n- :priority\n- :status\n- :assigned_to\n	---\n- - id\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2026-04-10 07:16:12.476104+00	2026-04-10 07:16:12.476104+00	\N	f	t	\N
4	1	Team planner	---\nassigned_to_id:\n  :operator: "="\n  :values:\n  - '4'\n	4	t	\N	\N	\N	f	f	f	5	\N	\N	\N	2026-04-10 07:16:12.511339+00	2026-04-10 07:16:12.511339+00	\N	f	t	\N
5	1	New	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '1'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2026-04-10 07:16:14.659703+00	2026-04-10 07:16:14.659703+00	\N	f	t	\N
6	1	In progress	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '7'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2026-04-10 07:16:14.674801+00	2026-04-10 07:16:14.674801+00	\N	f	t	\N
7	1	Closed	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '12'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2026-04-10 07:16:14.685518+00	2026-04-10 07:16:14.685518+00	\N	f	t	\N
8	1	Rejected	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '14'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2026-04-10 07:16:14.698306+00	2026-04-10 07:16:14.698306+00	\N	f	t	\N
9	1	Wish list	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2026-04-10 07:16:14.779324+00	2026-04-10 07:16:14.779324+00	\N	f	t	\N
10	1	Short list	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2026-04-10 07:16:14.802571+00	2026-04-10 07:16:14.802571+00	\N	f	t	\N
11	1	Priority list for today	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2026-04-10 07:16:14.818355+00	2026-04-10 07:16:14.818355+00	\N	f	t	\N
12	1	Never	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2026-04-10 07:16:14.840411+00	2026-04-10 07:16:14.840411+00	\N	f	t	\N
13	1	Organize open source conference	---\nstatus_id:\n  :operator: o\n  :values:\n  - ''\nparent:\n  :operator: "="\n  :values:\n  - '2'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2026-04-10 07:16:14.88115+00	2026-04-10 07:16:14.88115+00	\N	f	t	\N
14	1	Follow-up tasks	---\nstatus_id:\n  :operator: o\n  :values:\n  - ''\nparent:\n  :operator: "="\n  :values:\n  - '10'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2026-04-10 07:16:14.900637+00	2026-04-10 07:16:14.900637+00	\N	f	t	\N
15	2	Project plan	---\nstatus_id:\n  :operator: o\n  :values: []\ntype_id:\n  :operator: "="\n  :values:\n  - '2'\n  - '3'\n	4	t	\N	---\n- - id\n  - asc\n	\N	f	t	f	5	\N	\N	\N	2026-04-10 07:16:15.606956+00	2026-04-10 07:16:15.606956+00	\N	f	t	\N
16	2	Product backlog	---\nstatus_id:\n  :operator: o\n  :values: []\nversion_id:\n  :operator: "="\n  :values:\n  - '2'\n	4	t	---\n- :id\n- :type\n- :subject\n- :priority\n- :status\n- :assigned_to\n- :story_points\n	---\n- - status\n  - asc\n	status	f	f	f	5	\N	\N	\N	2026-04-10 07:16:15.638996+00	2026-04-10 07:16:15.638996+00	\N	f	t	\N
17	2	Sprint 1	---\nstatus_id:\n  :operator: o\n  :values: []\nversion_id:\n  :operator: "="\n  :values:\n  - '3'\n	4	t	---\n- :id\n- :type\n- :subject\n- :priority\n- :status\n- :assigned_to\n- :done_ratio\n- :story_points\n	\N	\N	f	f	t	5	\N	\N	\N	2026-04-10 07:16:15.675966+00	2026-04-10 07:16:15.675966+00	\N	f	t	\N
18	2	Tasks	---\nstatus_id:\n  :operator: o\n  :values: []\ntype_id:\n  :operator: "="\n  :values:\n  - '1'\n	4	t	\N	\N	\N	f	f	t	5	\N	\N	\N	2026-04-10 07:16:15.696338+00	2026-04-10 07:16:15.696338+00	\N	f	t	\N
19	2	New	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '1'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2026-04-10 07:16:18.245105+00	2026-04-10 07:16:18.245105+00	\N	f	t	\N
20	2	In progress	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '7'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2026-04-10 07:16:18.258668+00	2026-04-10 07:16:18.258668+00	\N	f	t	\N
21	2	Closed	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '12'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2026-04-10 07:16:18.269791+00	2026-04-10 07:16:18.269791+00	\N	f	t	\N
22	2	Rejected	---\nstatus_id:\n  :operator: "="\n  :values:\n  - '14'\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	t	5	\N	\N	\N	2026-04-10 07:16:18.279416+00	2026-04-10 07:16:18.279416+00	\N	f	t	\N
23	2	Wish list	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2026-04-10 07:16:18.308743+00	2026-04-10 07:16:18.308743+00	\N	f	t	\N
24	2	Short list	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2026-04-10 07:16:18.321809+00	2026-04-10 07:16:18.321809+00	\N	f	t	\N
25	2	Priority list for today	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2026-04-10 07:16:18.335239+00	2026-04-10 07:16:18.335239+00	\N	f	t	\N
26	2	Never	---\nmanual_sort:\n  :operator: ow\n  :values: []\n	4	t	\N	---\n- - manual_sorting\n  - asc\n	\N	f	f	f	5	\N	\N	\N	2026-04-10 07:16:18.353559+00	2026-04-10 07:16:18.353559+00	\N	f	t	\N
\.


--
-- Data for Name: rates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rates (id, valid_from, rate, type, project_id, user_id, cost_type_id) FROM stdin;
\.


--
-- Data for Name: recaptcha_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recaptcha_entries (id, user_id, created_at, updated_at, version) FROM stdin;
\.


--
-- Data for Name: recurring_meeting_interim_responses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recurring_meeting_interim_responses (id, recurring_meeting_id, user_id, start_time, participation_status, comment, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: recurring_meetings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recurring_meetings (id, start_time, end_date, title, frequency, end_after, iterations, project_id, author_id, created_at, updated_at, "interval", time_zone, uid, current_schedule_start) FROM stdin;
1	2026-04-13 17:16:14.917368+00	\N	Weekly	2	3	\N	1	4	2026-04-10 07:16:14.941762+00	2026-04-10 07:16:14.941762+00	1	Europe/Berlin	0c76dc74-33f3-4729-ae21-e9d8c76ca8ce@localhost:8092	2026-04-13 17:16:14.920282+00
\.


--
-- Data for Name: relations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.relations (id, from_id, to_id, lag, description, relation_type) FROM stdin;
1	13	10	\N	\N	follows
2	9	2	\N	\N	follows
3	8	3	\N	\N	follows
4	7	3	\N	\N	follows
5	36	35	\N	\N	follows
6	34	33	\N	\N	follows
7	32	31	\N	\N	follows
\.


--
-- Data for Name: reminder_notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reminder_notifications (id, reminder_id, notification_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: reminders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reminders (id, remindable_type, remindable_id, creator_id, remind_at, completed_at, job_id, note, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: remote_identities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.remote_identities (id, user_id, auth_source_id, origin_user_id, created_at, updated_at, auth_source_type, integration_type, integration_id) FROM stdin;
\.


--
-- Data for Name: repositories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repositories (id, project_id, url, login, password, root_url, type, path_encoding, log_encoding, scm_type, required_storage_bytes, storage_updated_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (id, permission, role_id, created_at, updated_at) FROM stdin;
1	view_work_packages	1	2026-04-10 07:16:07.005542+00	2026-04-10 07:16:07.005542+00
2	view_calendar	1	2026-04-10 07:16:07.008206+00	2026-04-10 07:16:07.008206+00
3	comment_news	1	2026-04-10 07:16:07.010101+00	2026-04-10 07:16:07.010101+00
4	view_wiki_pages	1	2026-04-10 07:16:07.011028+00	2026-04-10 07:16:07.011028+00
5	view_project_attributes	1	2026-04-10 07:16:07.013781+00	2026-04-10 07:16:07.013781+00
6	view_project_phases	1	2026-04-10 07:16:07.015233+00	2026-04-10 07:16:07.015233+00
7	show_board_views	1	2026-04-10 07:16:07.01774+00	2026-04-10 07:16:07.01774+00
8	share_calendars	1	2026-04-10 07:16:07.022979+00	2026-04-10 07:16:07.022979+00
9	show_github_content	1	2026-04-10 07:16:07.023988+00	2026-04-10 07:16:07.023988+00
10	view_file_links	1	2026-04-10 07:16:07.024552+00	2026-04-10 07:16:07.024552+00
11	view_project	1	2026-04-10 07:16:07.040794+00	2026-04-10 07:16:07.040794+00
12	search_project	1	2026-04-10 07:16:07.046501+00	2026-04-10 07:16:07.046501+00
13	view_news	1	2026-04-10 07:16:07.048064+00	2026-04-10 07:16:07.048064+00
14	view_messages	1	2026-04-10 07:16:07.050944+00	2026-04-10 07:16:07.050944+00
15	view_project_activity	1	2026-04-10 07:16:07.055691+00	2026-04-10 07:16:07.055691+00
16	view_work_packages	2	2026-04-10 07:16:07.113716+00	2026-04-10 07:16:07.113716+00
17	view_wiki_pages	2	2026-04-10 07:16:07.121998+00	2026-04-10 07:16:07.121998+00
18	view_project_attributes	2	2026-04-10 07:16:07.12885+00	2026-04-10 07:16:07.12885+00
19	view_project_phases	2	2026-04-10 07:16:07.130307+00	2026-04-10 07:16:07.130307+00
20	view_file_links	2	2026-04-10 07:16:07.130803+00	2026-04-10 07:16:07.130803+00
21	view_project	2	2026-04-10 07:16:07.131254+00	2026-04-10 07:16:07.131254+00
22	search_project	2	2026-04-10 07:16:07.133675+00	2026-04-10 07:16:07.133675+00
23	view_news	2	2026-04-10 07:16:07.135308+00	2026-04-10 07:16:07.135308+00
24	view_messages	2	2026-04-10 07:16:07.135998+00	2026-04-10 07:16:07.135998+00
25	view_project_activity	2	2026-04-10 07:16:07.13977+00	2026-04-10 07:16:07.13977+00
26	view_work_packages	3	2026-04-10 07:16:07.252903+00	2026-04-10 07:16:07.252903+00
27	export_work_packages	3	2026-04-10 07:16:07.25372+00	2026-04-10 07:16:07.25372+00
28	add_work_packages	3	2026-04-10 07:16:07.254227+00	2026-04-10 07:16:07.254227+00
29	move_work_packages	3	2026-04-10 07:16:07.254662+00	2026-04-10 07:16:07.254662+00
30	edit_work_packages	3	2026-04-10 07:16:07.255101+00	2026-04-10 07:16:07.255101+00
31	assign_versions	3	2026-04-10 07:16:07.255537+00	2026-04-10 07:16:07.255537+00
32	work_package_assigned	3	2026-04-10 07:16:07.25653+00	2026-04-10 07:16:07.25653+00
33	add_work_package_comments	3	2026-04-10 07:16:07.257168+00	2026-04-10 07:16:07.257168+00
34	edit_own_work_package_comments	3	2026-04-10 07:16:07.257746+00	2026-04-10 07:16:07.257746+00
35	manage_work_package_relations	3	2026-04-10 07:16:07.258372+00	2026-04-10 07:16:07.258372+00
36	manage_subtasks	3	2026-04-10 07:16:07.258827+00	2026-04-10 07:16:07.258827+00
37	save_queries	3	2026-04-10 07:16:07.25925+00	2026-04-10 07:16:07.25925+00
38	view_work_package_watchers	3	2026-04-10 07:16:07.259682+00	2026-04-10 07:16:07.259682+00
39	add_work_package_watchers	3	2026-04-10 07:16:07.261413+00	2026-04-10 07:16:07.261413+00
40	delete_work_package_watchers	3	2026-04-10 07:16:07.262359+00	2026-04-10 07:16:07.262359+00
41	view_calendar	3	2026-04-10 07:16:07.262861+00	2026-04-10 07:16:07.262861+00
42	comment_news	3	2026-04-10 07:16:07.263312+00	2026-04-10 07:16:07.263312+00
43	manage_news	3	2026-04-10 07:16:07.264067+00	2026-04-10 07:16:07.264067+00
44	view_time_entries	3	2026-04-10 07:16:07.264624+00	2026-04-10 07:16:07.264624+00
45	view_own_time_entries	3	2026-04-10 07:16:07.265123+00	2026-04-10 07:16:07.265123+00
46	edit_own_time_entries	3	2026-04-10 07:16:07.265618+00	2026-04-10 07:16:07.265618+00
47	view_timelines	3	2026-04-10 07:16:07.266072+00	2026-04-10 07:16:07.266072+00
48	edit_timelines	3	2026-04-10 07:16:07.267007+00	2026-04-10 07:16:07.267007+00
49	delete_timelines	3	2026-04-10 07:16:07.267442+00	2026-04-10 07:16:07.267442+00
50	view_reportings	3	2026-04-10 07:16:07.268271+00	2026-04-10 07:16:07.268271+00
51	edit_reportings	3	2026-04-10 07:16:07.268711+00	2026-04-10 07:16:07.268711+00
52	delete_reportings	3	2026-04-10 07:16:07.269123+00	2026-04-10 07:16:07.269123+00
53	manage_wiki	3	2026-04-10 07:16:07.269534+00	2026-04-10 07:16:07.269534+00
54	rename_wiki_pages	3	2026-04-10 07:16:07.26995+00	2026-04-10 07:16:07.26995+00
55	change_wiki_parent_page	3	2026-04-10 07:16:07.275397+00	2026-04-10 07:16:07.275397+00
56	delete_wiki_pages	3	2026-04-10 07:16:07.275914+00	2026-04-10 07:16:07.275914+00
57	view_wiki_pages	3	2026-04-10 07:16:07.276354+00	2026-04-10 07:16:07.276354+00
58	export_wiki_pages	3	2026-04-10 07:16:07.276984+00	2026-04-10 07:16:07.276984+00
59	view_wiki_edits	3	2026-04-10 07:16:07.277485+00	2026-04-10 07:16:07.277485+00
60	edit_wiki_pages	3	2026-04-10 07:16:07.277945+00	2026-04-10 07:16:07.277945+00
61	delete_wiki_pages_attachments	3	2026-04-10 07:16:07.278377+00	2026-04-10 07:16:07.278377+00
62	protect_wiki_pages	3	2026-04-10 07:16:07.278791+00	2026-04-10 07:16:07.278791+00
63	list_attachments	3	2026-04-10 07:16:07.279195+00	2026-04-10 07:16:07.279195+00
64	add_messages	3	2026-04-10 07:16:07.282356+00	2026-04-10 07:16:07.282356+00
65	edit_own_messages	3	2026-04-10 07:16:07.28506+00	2026-04-10 07:16:07.28506+00
66	delete_own_messages	3	2026-04-10 07:16:07.285705+00	2026-04-10 07:16:07.285705+00
67	browse_repository	3	2026-04-10 07:16:07.287051+00	2026-04-10 07:16:07.287051+00
68	view_changesets	3	2026-04-10 07:16:07.287512+00	2026-04-10 07:16:07.287512+00
69	commit_access	3	2026-04-10 07:16:07.298579+00	2026-04-10 07:16:07.298579+00
70	view_commit_author_statistics	3	2026-04-10 07:16:07.299348+00	2026-04-10 07:16:07.299348+00
71	view_members	3	2026-04-10 07:16:07.30241+00	2026-04-10 07:16:07.30241+00
72	view_team_planner	3	2026-04-10 07:16:07.302846+00	2026-04-10 07:16:07.302846+00
73	view_shared_work_packages	3	2026-04-10 07:16:07.30324+00	2026-04-10 07:16:07.30324+00
74	copy_work_packages	3	2026-04-10 07:16:07.30366+00	2026-04-10 07:16:07.30366+00
75	add_work_package_attachments	3	2026-04-10 07:16:07.304041+00	2026-04-10 07:16:07.304041+00
76	view_project_attributes	3	2026-04-10 07:16:07.304427+00	2026-04-10 07:16:07.304427+00
77	view_internal_comments	3	2026-04-10 07:16:07.305204+00	2026-04-10 07:16:07.305204+00
78	add_internal_comments	3	2026-04-10 07:16:07.305606+00	2026-04-10 07:16:07.305606+00
79	edit_own_internal_comments	3	2026-04-10 07:16:07.305983+00	2026-04-10 07:16:07.305983+00
80	view_project_phases	3	2026-04-10 07:16:07.306358+00	2026-04-10 07:16:07.306358+00
81	export_projects	3	2026-04-10 07:16:07.306748+00	2026-04-10 07:16:07.306748+00
82	view_master_backlog	3	2026-04-10 07:16:07.30713+00	2026-04-10 07:16:07.30713+00
83	view_taskboards	3	2026-04-10 07:16:07.307519+00	2026-04-10 07:16:07.307519+00
84	show_board_views	3	2026-04-10 07:16:07.307969+00	2026-04-10 07:16:07.307969+00
85	manage_public_queries	3	2026-04-10 07:16:07.312801+00	2026-04-10 07:16:07.312801+00
86	manage_board_views	3	2026-04-10 07:16:07.313325+00	2026-04-10 07:16:07.313325+00
87	share_calendars	3	2026-04-10 07:16:07.313776+00	2026-04-10 07:16:07.313776+00
88	view_cost_rates	3	2026-04-10 07:16:07.314229+00	2026-04-10 07:16:07.314229+00
89	log_own_costs	3	2026-04-10 07:16:07.31466+00	2026-04-10 07:16:07.31466+00
90	edit_own_cost_entries	3	2026-04-10 07:16:07.315253+00	2026-04-10 07:16:07.315253+00
91	view_budgets	3	2026-04-10 07:16:07.316317+00	2026-04-10 07:16:07.316317+00
92	view_own_cost_entries	3	2026-04-10 07:16:07.316829+00	2026-04-10 07:16:07.316829+00
93	log_own_time	3	2026-04-10 07:16:07.317309+00	2026-04-10 07:16:07.317309+00
94	save_cost_reports	3	2026-04-10 07:16:07.31778+00	2026-04-10 07:16:07.31778+00
95	save_private_cost_reports	3	2026-04-10 07:16:07.31831+00	2026-04-10 07:16:07.31831+00
96	view_documents	3	2026-04-10 07:16:07.318784+00	2026-04-10 07:16:07.318784+00
97	manage_documents	3	2026-04-10 07:16:07.319224+00	2026-04-10 07:16:07.319224+00
98	show_github_content	3	2026-04-10 07:16:07.319648+00	2026-04-10 07:16:07.319648+00
99	create_meetings	3	2026-04-10 07:16:07.320664+00	2026-04-10 07:16:07.320664+00
100	edit_meetings	3	2026-04-10 07:16:07.322615+00	2026-04-10 07:16:07.322615+00
101	delete_meetings	3	2026-04-10 07:16:07.323117+00	2026-04-10 07:16:07.323117+00
102	view_meetings	3	2026-04-10 07:16:07.32393+00	2026-04-10 07:16:07.32393+00
103	manage_agendas	3	2026-04-10 07:16:07.325305+00	2026-04-10 07:16:07.325305+00
104	manage_outcomes	3	2026-04-10 07:16:07.326686+00	2026-04-10 07:16:07.326686+00
105	send_meeting_invites_and_outcomes	3	2026-04-10 07:16:07.327156+00	2026-04-10 07:16:07.327156+00
106	view_file_links	3	2026-04-10 07:16:07.327607+00	2026-04-10 07:16:07.327607+00
107	manage_file_links	3	2026-04-10 07:16:07.328144+00	2026-04-10 07:16:07.328144+00
108	read_files	3	2026-04-10 07:16:07.328567+00	2026-04-10 07:16:07.328567+00
109	write_files	3	2026-04-10 07:16:07.328996+00	2026-04-10 07:16:07.328996+00
110	create_files	3	2026-04-10 07:16:07.330301+00	2026-04-10 07:16:07.330301+00
111	delete_files	3	2026-04-10 07:16:07.332373+00	2026-04-10 07:16:07.332373+00
112	share_files	3	2026-04-10 07:16:07.333304+00	2026-04-10 07:16:07.333304+00
113	view_project	3	2026-04-10 07:16:07.333979+00	2026-04-10 07:16:07.333979+00
114	search_project	3	2026-04-10 07:16:07.33732+00	2026-04-10 07:16:07.33732+00
115	view_news	3	2026-04-10 07:16:07.346196+00	2026-04-10 07:16:07.346196+00
116	view_messages	3	2026-04-10 07:16:07.346708+00	2026-04-10 07:16:07.346708+00
117	view_project_activity	3	2026-04-10 07:16:07.350682+00	2026-04-10 07:16:07.350682+00
118	view_work_packages	4	2026-04-10 07:16:07.408075+00	2026-04-10 07:16:07.408075+00
119	add_work_package_comments	4	2026-04-10 07:16:07.409485+00	2026-04-10 07:16:07.409485+00
120	edit_own_work_package_comments	4	2026-04-10 07:16:07.410476+00	2026-04-10 07:16:07.410476+00
121	save_queries	4	2026-04-10 07:16:07.410932+00	2026-04-10 07:16:07.410932+00
122	view_calendar	4	2026-04-10 07:16:07.411353+00	2026-04-10 07:16:07.411353+00
123	comment_news	4	2026-04-10 07:16:07.411806+00	2026-04-10 07:16:07.411806+00
124	view_timelines	4	2026-04-10 07:16:07.412265+00	2026-04-10 07:16:07.412265+00
125	view_reportings	4	2026-04-10 07:16:07.412667+00	2026-04-10 07:16:07.412667+00
126	view_wiki_pages	4	2026-04-10 07:16:07.413119+00	2026-04-10 07:16:07.413119+00
127	export_wiki_pages	4	2026-04-10 07:16:07.413508+00	2026-04-10 07:16:07.413508+00
128	list_attachments	4	2026-04-10 07:16:07.413908+00	2026-04-10 07:16:07.413908+00
129	add_messages	4	2026-04-10 07:16:07.414261+00	2026-04-10 07:16:07.414261+00
130	edit_own_messages	4	2026-04-10 07:16:07.414612+00	2026-04-10 07:16:07.414612+00
131	delete_own_messages	4	2026-04-10 07:16:07.4152+00	2026-04-10 07:16:07.4152+00
132	browse_repository	4	2026-04-10 07:16:07.415705+00	2026-04-10 07:16:07.415705+00
133	view_changesets	4	2026-04-10 07:16:07.41623+00	2026-04-10 07:16:07.41623+00
134	view_commit_author_statistics	4	2026-04-10 07:16:07.416699+00	2026-04-10 07:16:07.416699+00
135	view_team_planner	4	2026-04-10 07:16:07.417155+00	2026-04-10 07:16:07.417155+00
136	view_shared_work_packages	4	2026-04-10 07:16:07.418099+00	2026-04-10 07:16:07.418099+00
137	view_project_attributes	4	2026-04-10 07:16:07.418674+00	2026-04-10 07:16:07.418674+00
138	view_project_phases	4	2026-04-10 07:16:07.419228+00	2026-04-10 07:16:07.419228+00
139	view_master_backlog	4	2026-04-10 07:16:07.419728+00	2026-04-10 07:16:07.419728+00
140	view_taskboards	4	2026-04-10 07:16:07.420245+00	2026-04-10 07:16:07.420245+00
141	show_board_views	4	2026-04-10 07:16:07.420646+00	2026-04-10 07:16:07.420646+00
142	share_calendars	4	2026-04-10 07:16:07.421026+00	2026-04-10 07:16:07.421026+00
143	view_documents	4	2026-04-10 07:16:07.421387+00	2026-04-10 07:16:07.421387+00
144	show_github_content	4	2026-04-10 07:16:07.421759+00	2026-04-10 07:16:07.421759+00
145	view_meetings	4	2026-04-10 07:16:07.422122+00	2026-04-10 07:16:07.422122+00
146	view_file_links	4	2026-04-10 07:16:07.422484+00	2026-04-10 07:16:07.422484+00
147	read_files	4	2026-04-10 07:16:07.422844+00	2026-04-10 07:16:07.422844+00
148	view_project	4	2026-04-10 07:16:07.423243+00	2026-04-10 07:16:07.423243+00
149	search_project	4	2026-04-10 07:16:07.423617+00	2026-04-10 07:16:07.423617+00
150	view_news	4	2026-04-10 07:16:07.424085+00	2026-04-10 07:16:07.424085+00
151	view_messages	4	2026-04-10 07:16:07.424522+00	2026-04-10 07:16:07.424522+00
152	view_project_activity	4	2026-04-10 07:16:07.42489+00	2026-04-10 07:16:07.42489+00
153	archive_project	5	2026-04-10 07:16:07.439166+00	2026-04-10 07:16:07.439166+00
154	edit_project	5	2026-04-10 07:16:07.439669+00	2026-04-10 07:16:07.439669+00
155	select_project_modules	5	2026-04-10 07:16:07.440248+00	2026-04-10 07:16:07.440248+00
156	view_project_attributes	5	2026-04-10 07:16:07.440791+00	2026-04-10 07:16:07.440791+00
157	export_projects	5	2026-04-10 07:16:07.441244+00	2026-04-10 07:16:07.441244+00
158	edit_project_attributes	5	2026-04-10 07:16:07.442283+00	2026-04-10 07:16:07.442283+00
159	select_project_custom_fields	5	2026-04-10 07:16:07.442685+00	2026-04-10 07:16:07.442685+00
160	view_project_phases	5	2026-04-10 07:16:07.443086+00	2026-04-10 07:16:07.443086+00
161	edit_project_phases	5	2026-04-10 07:16:07.443477+00	2026-04-10 07:16:07.443477+00
162	select_project_phases	5	2026-04-10 07:16:07.443868+00	2026-04-10 07:16:07.443868+00
163	manage_members	5	2026-04-10 07:16:07.444246+00	2026-04-10 07:16:07.444246+00
164	invite_members_by_email	5	2026-04-10 07:16:07.444605+00	2026-04-10 07:16:07.444605+00
165	view_members	5	2026-04-10 07:16:07.444973+00	2026-04-10 07:16:07.444973+00
166	manage_versions	5	2026-04-10 07:16:07.445345+00	2026-04-10 07:16:07.445345+00
167	manage_types	5	2026-04-10 07:16:07.445722+00	2026-04-10 07:16:07.445722+00
168	select_custom_fields	5	2026-04-10 07:16:07.446096+00	2026-04-10 07:16:07.446096+00
169	add_subprojects	5	2026-04-10 07:16:07.446481+00	2026-04-10 07:16:07.446481+00
170	copy_projects	5	2026-04-10 07:16:07.446875+00	2026-04-10 07:16:07.446875+00
171	view_work_packages	5	2026-04-10 07:16:07.44725+00	2026-04-10 07:16:07.44725+00
172	add_work_packages	5	2026-04-10 07:16:07.447597+00	2026-04-10 07:16:07.447597+00
173	edit_work_packages	5	2026-04-10 07:16:07.448008+00	2026-04-10 07:16:07.448008+00
174	move_work_packages	5	2026-04-10 07:16:07.448502+00	2026-04-10 07:16:07.448502+00
175	copy_work_packages	5	2026-04-10 07:16:07.449055+00	2026-04-10 07:16:07.449055+00
176	add_work_package_comments	5	2026-04-10 07:16:07.449495+00	2026-04-10 07:16:07.449495+00
177	edit_own_work_package_comments	5	2026-04-10 07:16:07.450098+00	2026-04-10 07:16:07.450098+00
178	edit_work_package_comments	5	2026-04-10 07:16:07.450507+00	2026-04-10 07:16:07.450507+00
179	view_internal_comments	5	2026-04-10 07:16:07.450884+00	2026-04-10 07:16:07.450884+00
180	add_internal_comments	5	2026-04-10 07:16:07.451257+00	2026-04-10 07:16:07.451257+00
181	edit_own_internal_comments	5	2026-04-10 07:16:07.451626+00	2026-04-10 07:16:07.451626+00
182	edit_others_internal_comments	5	2026-04-10 07:16:07.452038+00	2026-04-10 07:16:07.452038+00
183	add_work_package_attachments	5	2026-04-10 07:16:07.452424+00	2026-04-10 07:16:07.452424+00
184	manage_categories	5	2026-04-10 07:16:07.453118+00	2026-04-10 07:16:07.453118+00
185	export_work_packages	5	2026-04-10 07:16:07.453507+00	2026-04-10 07:16:07.453507+00
186	delete_work_packages	5	2026-04-10 07:16:07.454201+00	2026-04-10 07:16:07.454201+00
187	manage_work_package_relations	5	2026-04-10 07:16:07.454654+00	2026-04-10 07:16:07.454654+00
188	manage_subtasks	5	2026-04-10 07:16:07.455028+00	2026-04-10 07:16:07.455028+00
189	manage_public_queries	5	2026-04-10 07:16:07.455398+00	2026-04-10 07:16:07.455398+00
190	save_queries	5	2026-04-10 07:16:07.455741+00	2026-04-10 07:16:07.455741+00
191	view_work_package_watchers	5	2026-04-10 07:16:07.456114+00	2026-04-10 07:16:07.456114+00
192	add_work_package_watchers	5	2026-04-10 07:16:07.456493+00	2026-04-10 07:16:07.456493+00
193	delete_work_package_watchers	5	2026-04-10 07:16:07.456834+00	2026-04-10 07:16:07.456834+00
194	share_work_packages	5	2026-04-10 07:16:07.457172+00	2026-04-10 07:16:07.457172+00
195	view_shared_work_packages	5	2026-04-10 07:16:07.45756+00	2026-04-10 07:16:07.45756+00
196	assign_versions	5	2026-04-10 07:16:07.458094+00	2026-04-10 07:16:07.458094+00
197	change_work_package_status	5	2026-04-10 07:16:07.458504+00	2026-04-10 07:16:07.458504+00
198	work_package_assigned	5	2026-04-10 07:16:07.458965+00	2026-04-10 07:16:07.458965+00
199	manage_news	5	2026-04-10 07:16:07.459403+00	2026-04-10 07:16:07.459403+00
200	comment_news	5	2026-04-10 07:16:07.459948+00	2026-04-10 07:16:07.459948+00
201	view_wiki_pages	5	2026-04-10 07:16:07.460556+00	2026-04-10 07:16:07.460556+00
202	list_attachments	5	2026-04-10 07:16:07.460953+00	2026-04-10 07:16:07.460953+00
203	manage_wiki	5	2026-04-10 07:16:07.461346+00	2026-04-10 07:16:07.461346+00
204	manage_wiki_menu	5	2026-04-10 07:16:07.461835+00	2026-04-10 07:16:07.461835+00
205	rename_wiki_pages	5	2026-04-10 07:16:07.462276+00	2026-04-10 07:16:07.462276+00
206	change_wiki_parent_page	5	2026-04-10 07:16:07.462701+00	2026-04-10 07:16:07.462701+00
207	delete_wiki_pages	5	2026-04-10 07:16:07.463132+00	2026-04-10 07:16:07.463132+00
208	export_wiki_pages	5	2026-04-10 07:16:07.463547+00	2026-04-10 07:16:07.463547+00
209	view_wiki_edits	5	2026-04-10 07:16:07.463961+00	2026-04-10 07:16:07.463961+00
210	edit_wiki_pages	5	2026-04-10 07:16:07.464334+00	2026-04-10 07:16:07.464334+00
211	delete_wiki_pages_attachments	5	2026-04-10 07:16:07.464734+00	2026-04-10 07:16:07.464734+00
212	protect_wiki_pages	5	2026-04-10 07:16:07.465138+00	2026-04-10 07:16:07.465138+00
213	browse_repository	5	2026-04-10 07:16:07.466135+00	2026-04-10 07:16:07.466135+00
214	commit_access	5	2026-04-10 07:16:07.466673+00	2026-04-10 07:16:07.466673+00
215	manage_repository	5	2026-04-10 07:16:07.46706+00	2026-04-10 07:16:07.46706+00
216	view_changesets	5	2026-04-10 07:16:07.467415+00	2026-04-10 07:16:07.467415+00
217	view_commit_author_statistics	5	2026-04-10 07:16:07.467849+00	2026-04-10 07:16:07.467849+00
218	manage_forums	5	2026-04-10 07:16:07.46832+00	2026-04-10 07:16:07.46832+00
219	add_messages	5	2026-04-10 07:16:07.468708+00	2026-04-10 07:16:07.468708+00
220	edit_messages	5	2026-04-10 07:16:07.469066+00	2026-04-10 07:16:07.469066+00
221	edit_own_messages	5	2026-04-10 07:16:07.469446+00	2026-04-10 07:16:07.469446+00
222	delete_messages	5	2026-04-10 07:16:07.469797+00	2026-04-10 07:16:07.469797+00
223	delete_own_messages	5	2026-04-10 07:16:07.470197+00	2026-04-10 07:16:07.470197+00
224	view_time_entries	5	2026-04-10 07:16:07.470548+00	2026-04-10 07:16:07.470548+00
225	view_own_time_entries	5	2026-04-10 07:16:07.470901+00	2026-04-10 07:16:07.470901+00
226	log_own_time	5	2026-04-10 07:16:07.471244+00	2026-04-10 07:16:07.471244+00
227	log_time	5	2026-04-10 07:16:07.471603+00	2026-04-10 07:16:07.471603+00
228	edit_own_time_entries	5	2026-04-10 07:16:07.472019+00	2026-04-10 07:16:07.472019+00
229	edit_time_entries	5	2026-04-10 07:16:07.472377+00	2026-04-10 07:16:07.472377+00
230	manage_project_activities	5	2026-04-10 07:16:07.47277+00	2026-04-10 07:16:07.47277+00
231	view_own_hourly_rate	5	2026-04-10 07:16:07.473189+00	2026-04-10 07:16:07.473189+00
232	view_hourly_rates	5	2026-04-10 07:16:07.473571+00	2026-04-10 07:16:07.473571+00
233	edit_own_hourly_rate	5	2026-04-10 07:16:07.473938+00	2026-04-10 07:16:07.473938+00
234	edit_hourly_rates	5	2026-04-10 07:16:07.474322+00	2026-04-10 07:16:07.474322+00
235	view_cost_rates	5	2026-04-10 07:16:07.474746+00	2026-04-10 07:16:07.474746+00
236	log_own_costs	5	2026-04-10 07:16:07.475135+00	2026-04-10 07:16:07.475135+00
237	log_costs	5	2026-04-10 07:16:07.475506+00	2026-04-10 07:16:07.475506+00
238	edit_own_cost_entries	5	2026-04-10 07:16:07.475881+00	2026-04-10 07:16:07.475881+00
239	edit_cost_entries	5	2026-04-10 07:16:07.476757+00	2026-04-10 07:16:07.476757+00
240	view_cost_entries	5	2026-04-10 07:16:07.477132+00	2026-04-10 07:16:07.477132+00
241	view_own_cost_entries	5	2026-04-10 07:16:07.477474+00	2026-04-10 07:16:07.477474+00
242	save_cost_reports	5	2026-04-10 07:16:07.477829+00	2026-04-10 07:16:07.477829+00
243	save_private_cost_reports	5	2026-04-10 07:16:07.478172+00	2026-04-10 07:16:07.478172+00
244	view_master_backlog	5	2026-04-10 07:16:07.478515+00	2026-04-10 07:16:07.478515+00
245	view_taskboards	5	2026-04-10 07:16:07.478898+00	2026-04-10 07:16:07.478898+00
246	select_done_statuses	5	2026-04-10 07:16:07.479245+00	2026-04-10 07:16:07.479245+00
247	update_sprints	5	2026-04-10 07:16:07.479587+00	2026-04-10 07:16:07.479587+00
248	show_github_content	5	2026-04-10 07:16:07.480005+00	2026-04-10 07:16:07.480005+00
249	show_gitlab_content	5	2026-04-10 07:16:07.480363+00	2026-04-10 07:16:07.480363+00
250	show_board_views	5	2026-04-10 07:16:07.480712+00	2026-04-10 07:16:07.480712+00
251	manage_board_views	5	2026-04-10 07:16:07.481093+00	2026-04-10 07:16:07.481093+00
252	manage_dashboards	5	2026-04-10 07:16:07.481455+00	2026-04-10 07:16:07.481455+00
253	view_budgets	5	2026-04-10 07:16:07.481948+00	2026-04-10 07:16:07.481948+00
254	edit_budgets	5	2026-04-10 07:16:07.482651+00	2026-04-10 07:16:07.482651+00
255	view_meetings	5	2026-04-10 07:16:07.48324+00	2026-04-10 07:16:07.48324+00
256	create_meetings	5	2026-04-10 07:16:07.483651+00	2026-04-10 07:16:07.483651+00
257	edit_meetings	5	2026-04-10 07:16:07.484136+00	2026-04-10 07:16:07.484136+00
258	delete_meetings	5	2026-04-10 07:16:07.484578+00	2026-04-10 07:16:07.484578+00
259	send_meeting_invites_and_outcomes	5	2026-04-10 07:16:07.485599+00	2026-04-10 07:16:07.485599+00
260	manage_agendas	5	2026-04-10 07:16:07.48608+00	2026-04-10 07:16:07.48608+00
261	manage_outcomes	5	2026-04-10 07:16:07.486514+00	2026-04-10 07:16:07.486514+00
262	view_team_planner	5	2026-04-10 07:16:07.486922+00	2026-04-10 07:16:07.486922+00
263	manage_team_planner	5	2026-04-10 07:16:07.487296+00	2026-04-10 07:16:07.487296+00
264	view_calendar	5	2026-04-10 07:16:07.487663+00	2026-04-10 07:16:07.487663+00
265	manage_calendars	5	2026-04-10 07:16:07.488134+00	2026-04-10 07:16:07.488134+00
266	share_calendars	5	2026-04-10 07:16:07.488533+00	2026-04-10 07:16:07.488533+00
267	manage_files_in_project	5	2026-04-10 07:16:07.488925+00	2026-04-10 07:16:07.488925+00
268	read_files	5	2026-04-10 07:16:07.489332+00	2026-04-10 07:16:07.489332+00
269	write_files	5	2026-04-10 07:16:07.489737+00	2026-04-10 07:16:07.489737+00
270	create_files	5	2026-04-10 07:16:07.490126+00	2026-04-10 07:16:07.490126+00
271	delete_files	5	2026-04-10 07:16:07.490485+00	2026-04-10 07:16:07.490485+00
272	share_files	5	2026-04-10 07:16:07.490836+00	2026-04-10 07:16:07.490836+00
273	view_file_links	5	2026-04-10 07:16:07.491202+00	2026-04-10 07:16:07.491202+00
274	manage_file_links	5	2026-04-10 07:16:07.491603+00	2026-04-10 07:16:07.491603+00
275	view_documents	5	2026-04-10 07:16:07.49213+00	2026-04-10 07:16:07.49213+00
276	manage_documents	5	2026-04-10 07:16:07.49252+00	2026-04-10 07:16:07.49252+00
277	view_ifc_models	5	2026-04-10 07:16:07.492883+00	2026-04-10 07:16:07.492883+00
278	manage_ifc_models	5	2026-04-10 07:16:07.493333+00	2026-04-10 07:16:07.493333+00
279	view_linked_issues	5	2026-04-10 07:16:07.493747+00	2026-04-10 07:16:07.493747+00
280	manage_bcf	5	2026-04-10 07:16:07.494143+00	2026-04-10 07:16:07.494143+00
281	delete_bcf	5	2026-04-10 07:16:07.494505+00	2026-04-10 07:16:07.494505+00
282	save_bcf_queries	5	2026-04-10 07:16:07.495279+00	2026-04-10 07:16:07.495279+00
283	manage_public_bcf_queries	5	2026-04-10 07:16:07.495655+00	2026-04-10 07:16:07.495655+00
284	view_project	5	2026-04-10 07:16:07.496038+00	2026-04-10 07:16:07.496038+00
285	search_project	5	2026-04-10 07:16:07.496426+00	2026-04-10 07:16:07.496426+00
286	view_news	5	2026-04-10 07:16:07.496825+00	2026-04-10 07:16:07.496825+00
287	view_messages	5	2026-04-10 07:16:07.497208+00	2026-04-10 07:16:07.497208+00
288	view_project_activity	5	2026-04-10 07:16:07.49758+00	2026-04-10 07:16:07.49758+00
289	view_work_packages	6	2026-04-10 07:16:07.54014+00	2026-04-10 07:16:07.54014+00
290	edit_work_packages	6	2026-04-10 07:16:07.540662+00	2026-04-10 07:16:07.540662+00
291	work_package_assigned	6	2026-04-10 07:16:07.541098+00	2026-04-10 07:16:07.541098+00
292	add_work_package_comments	6	2026-04-10 07:16:07.541456+00	2026-04-10 07:16:07.541456+00
293	edit_own_work_package_comments	6	2026-04-10 07:16:07.542267+00	2026-04-10 07:16:07.542267+00
294	manage_work_package_relations	6	2026-04-10 07:16:07.54266+00	2026-04-10 07:16:07.54266+00
295	copy_work_packages	6	2026-04-10 07:16:07.543011+00	2026-04-10 07:16:07.543011+00
296	export_work_packages	6	2026-04-10 07:16:07.543381+00	2026-04-10 07:16:07.543381+00
297	view_own_time_entries	6	2026-04-10 07:16:07.54386+00	2026-04-10 07:16:07.54386+00
298	log_own_time	6	2026-04-10 07:16:07.544248+00	2026-04-10 07:16:07.544248+00
299	edit_own_time_entries	6	2026-04-10 07:16:07.544614+00	2026-04-10 07:16:07.544614+00
300	show_github_content	6	2026-04-10 07:16:07.544992+00	2026-04-10 07:16:07.544992+00
301	view_file_links	6	2026-04-10 07:16:07.545396+00	2026-04-10 07:16:07.545396+00
302	view_work_packages	7	2026-04-10 07:16:07.552551+00	2026-04-10 07:16:07.552551+00
303	work_package_assigned	7	2026-04-10 07:16:07.553133+00	2026-04-10 07:16:07.553133+00
304	add_work_package_comments	7	2026-04-10 07:16:07.553593+00	2026-04-10 07:16:07.553593+00
305	edit_own_work_package_comments	7	2026-04-10 07:16:07.554049+00	2026-04-10 07:16:07.554049+00
306	export_work_packages	7	2026-04-10 07:16:07.55442+00	2026-04-10 07:16:07.55442+00
307	add_work_package_attachments	7	2026-04-10 07:16:07.555191+00	2026-04-10 07:16:07.555191+00
308	view_own_time_entries	7	2026-04-10 07:16:07.555546+00	2026-04-10 07:16:07.555546+00
309	log_own_time	7	2026-04-10 07:16:07.556014+00	2026-04-10 07:16:07.556014+00
310	edit_own_time_entries	7	2026-04-10 07:16:07.556498+00	2026-04-10 07:16:07.556498+00
311	show_github_content	7	2026-04-10 07:16:07.556898+00	2026-04-10 07:16:07.556898+00
312	view_file_links	7	2026-04-10 07:16:07.557262+00	2026-04-10 07:16:07.557262+00
313	view_work_packages	8	2026-04-10 07:16:07.564558+00	2026-04-10 07:16:07.564558+00
314	export_work_packages	8	2026-04-10 07:16:07.565095+00	2026-04-10 07:16:07.565095+00
315	show_github_content	8	2026-04-10 07:16:07.565531+00	2026-04-10 07:16:07.565531+00
316	view_project_query	9	2026-04-10 07:16:07.604109+00	2026-04-10 07:16:07.604109+00
317	view_project_query	10	2026-04-10 07:16:07.610353+00	2026-04-10 07:16:07.610353+00
318	edit_project_query	10	2026-04-10 07:16:07.610766+00	2026-04-10 07:16:07.610766+00
319	add_project	11	2026-04-10 07:16:07.652487+00	2026-04-10 07:16:07.652487+00
320	create_user	11	2026-04-10 07:16:07.653198+00	2026-04-10 07:16:07.653198+00
321	manage_user	11	2026-04-10 07:16:07.653608+00	2026-04-10 07:16:07.653608+00
322	manage_placeholder_user	11	2026-04-10 07:16:07.653976+00	2026-04-10 07:16:07.653976+00
323	view_all_principals	11	2026-04-10 07:16:07.654364+00	2026-04-10 07:16:07.654364+00
324	invite_users_by_email	11	2026-04-10 07:16:07.654755+00	2026-04-10 07:16:07.654755+00
325	manage_dashboards	5	2026-04-10 07:16:18.562113+00	2026-04-10 07:16:18.562113+00
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, "position", builtin, type, created_at, updated_at) FROM stdin;
1	Non member	1	1	ProjectRole	2026-04-10 07:16:06.977665+00	2026-04-10 07:16:06.977665+00
2	Anonymous	2	2	ProjectRole	2026-04-10 07:16:07.074247+00	2026-04-10 07:16:07.074247+00
3	Member	3	0	ProjectRole	2026-04-10 07:16:07.224603+00	2026-04-10 07:16:07.224603+00
4	Reader	4	0	ProjectRole	2026-04-10 07:16:07.395488+00	2026-04-10 07:16:07.395488+00
5	Project admin	5	0	ProjectRole	2026-04-10 07:16:07.434669+00	2026-04-10 07:16:07.434669+00
11	Staff and projects manager	6	0	GlobalRole	2026-04-10 07:16:07.643022+00	2026-04-10 07:16:07.643022+00
6	Work package editor	9	5	WorkPackageRole	2026-04-10 07:16:07.526503+00	2026-04-10 07:16:07.661076+00
7	Work package commenter	10	4	WorkPackageRole	2026-04-10 07:16:07.547738+00	2026-04-10 07:16:07.661076+00
8	Work package viewer	11	3	WorkPackageRole	2026-04-10 07:16:07.5594+00	2026-04-10 07:16:07.661076+00
9	Project query viewer	12	6	ProjectQueryRole	2026-04-10 07:16:07.595021+00	2026-04-10 07:16:07.661076+00
10	Project query editor	13	7	ProjectQueryRole	2026-04-10 07:16:07.606003+00	2026-04-10 07:16:07.661076+00
12	Standard global role	7	8	GlobalRole	2026-04-10 07:16:07.657695+00	2026-04-10 07:16:07.657695+00
\.


--
-- Data for Name: scheduled_meetings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scheduled_meetings (id, recurring_meeting_id, meeting_id, start_time, cancelled, created_at, updated_at) FROM stdin;
1	1	2	2026-04-13 17:16:14.917368+00	f	2026-04-10 07:17:16.002227+00	2026-04-10 07:17:16.002227+00
2	1	3	2026-04-20 17:16:14.917368+00	f	2026-05-04 07:50:44.473702+00	2026-05-04 07:50:44.473702+00
3	1	4	2026-04-27 17:16:14.917368+00	f	2026-05-04 07:50:47.560422+00	2026-05-04 07:50:47.560422+00
4	1	5	2026-05-04 17:16:14.917368+00	f	2026-05-04 07:50:50.654654+00	2026-05-04 07:50:50.654654+00
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_migrations (version) FROM stdin;
20260130105057
20260122130916
20260108111032
20260106151226
20260105101148
20260105100429
20260105095917
20260105095152
20260105093729
20260105093056
20260105092419
20260105090537
20251218133700
20251218100741
20251218100721
20251218100700
20251217105019
20251216155857
20251211160744
20251209191935
20251204100529
20251126092758
20251125000000
20251121073442
20251119095014
20251117102116
20251115211211
20251114174545
20251111155829
20251111145039
20251107114245
20251105082430
20251105082400
20251104151450
20251103123548
20251031071403
20251029134217
20251024140438
20251022114752
20251021133601
20251017111720
20250929070310
20250923142124
20250923120330
20250923064241
20250910085916
20250908172222
20250908151957
20250908072653
20250905204438
20250821092618
20250820131839
20250819152511
20250818133654
20250811102200
20250808062421
20250806132912
20250804133700
20250804083253
20250731144436
20250714142919
20250711133700
20250710133700
20250709103506
20250709090813
20250703143214
20250627121119
20250624155721
20250613141234
20250612133700
20250610111413
20250605133700
20250526155610
20250512114003
20250428135623
20250428114958
20250423123519
20250422072119
20250416141059
20250416112143
20250416095154
20250411104802
20250404061503
20250404060850
20250403150639
20250210184018
20241202112409
20241202112408
20241202112407
20241202112406
20240306154737
20240306154736
20240306154735
20240306154734
20240123151252
20240123151251
20240123151250
20240123151249
20240123151248
20240123151247
20240123151246
1022015
1021015
1020015
1019015
1018016
1017016
1016015
1015015
1014015
1013015
1012015
1011015
1010015
1009016
1008015
1007015
1006015
1005015
1004015
1003016
1002015
1001015
1000016
20260226133700
20260313120000
\.


--
-- Data for Name: scim_clients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scim_clients (id, name, auth_provider_id, authentication_method, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: service_account_associations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_account_associations (id, service_account_id, service_id, service_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, session_id, data, updated_at, user_id) FROM stdin;
5	2::600e260dc4d147fbb49e96f4f2ac93af17d7ce265792dbcda1e324b632e5aa30	BAh7AA==\n	2026-04-10 07:32:11.988662+00	\N
7	2::1e4e905768300e24f6e400a8212d4267bc509c772daca9097e65034c51cb163a	BAh7AA==\n	2026-04-10 07:32:56.168891+00	\N
12	2::bfda29572ffca9e0e581c2a4732d52af94638085cea4c592c8547cc42c277941	BAh7B0kiD3VwZGF0ZWRfYXQGOgZFRkl1OglUaW1lDYqQH4BpvULkCjoNbmFu\nb19udW1pRzoNbmFub19kZW5pBjoNc3VibWljcm8iBwZgOgtvZmZzZXRpADoJ\nem9uZUkiCFVUQwY7AEZJIhBfY3NyZl90b2tlbgY7AEZJIjBaTzZkSWlHdGJC\naDBJemY0WWI4ODFiYnQ4UVRfSkN5d3FVUmZxTlY1NXlzBjsARg==\n	2026-05-04 10:57:04.363007+00	\N
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.settings (id, name, value, updated_at) FROM stdin;
1	lookbook_enabled	f	2026-04-10 07:16:09.74904+00
2	additional_host_names	[]	2026-04-10 07:16:09.7635+00
3	fog	{}	2026-04-10 07:16:09.772484+00
4	feature_beta_widgets_active	f	2026-04-10 07:16:09.783027+00
5	feature_mcp_server_active	f	2026-04-10 07:16:09.786656+00
6	feature_minutes_styling_meeting_pdf_active	f	2026-04-10 07:16:09.790127+00
7	opentelemetry_enabled	f	2026-04-10 07:16:09.795704+00
8	session_cookie_name	_open_project_session	2026-04-10 07:16:09.803297+00
9	plugin_openproject_auth_saml	---\nproviders:\n	2026-04-10 07:16:09.817527+00
10	costs_currency	EUR	2026-04-10 07:16:09.823616+00
11	costs_currency_format	%n %u	2026-04-10 07:16:09.826437+00
12	allow_tracking_start_and_end_times	f	2026-04-10 07:16:09.829867+00
13	enforce_tracking_start_and_end_times	f	2026-04-10 07:16:09.833858+00
14	cost_reporting_cache_filter_classes	true	2026-04-10 07:16:09.836994+00
16	plugin_openproject_avatars	---\nenable_gravatars: true\nenable_local_avatars: true\n	2026-04-10 07:16:09.848162+00
17	plugin_openproject_two_factor_authentication	---\nactive_strategies:\n- :totp\n- :webauthn\nenforced: false\nallow_remember_for_days: 0\n	2026-04-10 07:16:09.853245+00
18	feature_deploy_targets_active	f	2026-04-10 07:16:09.857899+00
19	plugin_openproject_github_integration	---\ngithub_user_id:\n	2026-04-10 07:16:09.865537+00
20	plugin_openproject_ldap_groups	{}	2026-04-10 07:16:09.869572+00
21	plugin_openproject_recaptcha	---\nrecaptcha_type: disabled\nresponse_limit: 5000\n	2026-04-10 07:16:09.874207+00
22	recaptcha_via_hcaptcha	f	2026-04-10 07:16:09.877484+00
23	ical_enabled	true	2026-04-10 07:16:09.880328+00
24	feature_storage_file_picking_select_all_active	f	2026-04-10 07:16:09.884739+00
25	plugin_openproject_bim	{}	2026-04-10 07:16:09.88828+00
26	rate_limiting	{}	2026-04-10 07:16:09.89337+00
27	activity_days_default	30	2026-04-10 07:16:09.898978+00
28	allowed_link_protocols	[]	2026-04-10 07:16:09.902503+00
29	apiv3_cors_enabled	f	2026-04-10 07:16:09.906319+00
30	apiv3_cors_origins	[]	2026-04-10 07:16:09.909302+00
31	apiv3_docs_enabled	f	2026-04-10 07:16:09.917806+00
32	apiv3_enable_basic_auth	true	2026-04-10 07:16:09.921266+00
33	apiv3_max_page_size	1000	2026-04-10 07:16:09.925258+00
34	apiv3_write_readonly_attributes	f	2026-04-10 07:16:09.929053+00
35	app_title	OpenProject	2026-04-10 07:16:09.932595+00
36	attachment_max_size	5120	2026-04-10 07:16:09.935704+00
37	attachment_whitelist	[]	2026-04-10 07:16:09.94039+00
38	attachments_grace_period	180	2026-04-10 07:16:09.944012+00
39	antivirus_scan_available	true	2026-04-10 07:16:09.946807+00
40	antivirus_scan_mode	disabled	2026-04-10 07:16:09.950724+00
41	antivirus_scan_action	quarantine	2026-04-10 07:16:09.976714+00
42	autofetch_changesets	true	2026-04-10 07:16:09.984989+00
43	autologin	0	2026-04-10 07:16:09.98823+00
44	autologin_cookie_name	autologin	2026-04-10 07:16:09.991422+00
45	autologin_cookie_path	/	2026-04-10 07:16:09.994261+00
46	available_languages	---\n- ca\n- cs\n- de\n- el\n- en\n- es\n- fr\n- hu\n- id\n- it\n- ja\n- ko\n- lt\n- nl\n- 'no'\n- pl\n- pt-BR\n- pt-PT\n- ro\n- ru\n- sk\n- sl\n- sv\n- tr\n- uk\n- vi\n- zh-CN\n- zh-TW\n	2026-04-10 07:16:09.997827+00
47	avatar_link_expiration_seconds	86400	2026-04-10 07:16:10.001119+00
48	backup_enabled	true	2026-04-10 07:16:10.004062+00
49	backup_daily_limit	3	2026-04-10 07:16:10.007241+00
50	backup_initial_waiting_period	86400	2026-04-10 07:16:10.010259+00
51	backup_include_attachments	true	2026-04-10 07:16:10.015121+00
52	backup_attachment_size_max_sum_mb	1024	2026-04-10 07:16:10.020476+00
53	bcc_recipients	true	2026-04-10 07:16:10.025498+00
55	brute_force_block_minutes	30	2026-04-10 07:16:10.032482+00
56	brute_force_block_after_failed_logins	20	2026-04-10 07:16:10.036041+00
57	cache_formatted_text	true	2026-04-10 07:16:10.041074+00
58	total_percent_complete_mode	work_weighted_average	2026-04-10 07:16:10.049693+00
59	commit_fix_keywords	fixes,closes	2026-04-10 07:16:10.053257+00
60	commit_logs_encoding	UTF-8	2026-04-10 07:16:10.057034+00
61	commit_logtime_enabled	f	2026-04-10 07:16:10.064202+00
62	commit_ref_keywords	refs,references,IssueID	2026-04-10 07:16:10.067686+00
65	cross_project_work_package_relations	true	2026-04-10 07:16:10.080462+00
66	days_per_month	20	2026-04-10 07:16:10.084188+00
68	default_comment_sort_order	asc	2026-04-10 07:16:10.090497+00
69	disable_keyboard_shortcuts	f	2026-04-10 07:16:10.094626+00
70	default_language	en	2026-04-10 07:16:10.101651+00
71	real_time_text_collaboration_enabled	true	2026-04-10 07:16:10.105053+00
72	default_projects_modules	---\n- calendar\n- board_view\n- work_package_tracking\n- gantt\n- news\n- costs\n- wiki\n- documents\n- reporting_module\n- backlogs\n- meetings\n	2026-04-10 07:16:10.108901+00
73	default_projects_public	f	2026-04-10 07:16:10.119495+00
78	development_highlight_enabled	f	2026-04-10 07:16:10.137531+00
79	diff_max_lines_displayed	1500	2026-04-10 07:16:10.140848+00
80	disable_password_choice	f	2026-04-10 07:16:10.144028+00
81	disable_password_login	f	2026-04-10 07:16:10.146812+00
82	display_subprojects_work_packages	true	2026-04-10 07:16:10.150692+00
83	drop_old_sessions_on_logout	true	2026-04-10 07:16:10.154545+00
84	drop_old_sessions_on_login	f	2026-04-10 07:16:10.157702+00
85	duration_format	hours_only	2026-04-10 07:16:10.160665+00
86	ee_hide_banners	f	2026-04-10 07:16:10.163966+00
87	emails_salutation	firstname	2026-04-10 07:16:10.169078+00
88	emails_footer	---\nen: ''\n	2026-04-10 07:16:10.1726+00
89	emails_header	---\nen: ''\n	2026-04-10 07:16:10.176095+00
90	email_login	f	2026-04-10 07:16:10.179151+00
91	enabled_projects_columns	---\n- favorited\n- name\n- project_status\n- public\n- created_at\n- latest_activity_at\n- required_disk_space\n	2026-04-10 07:16:10.182508+00
92	enabled_scm	---\n- subversion\n- git\n	2026-04-10 07:16:10.186901+00
93	feeds_enabled	true	2026-04-10 07:16:10.190254+00
94	feeds_limit	15	2026-04-10 07:16:10.206956+00
95	file_max_size_displayed	512	2026-04-10 07:16:10.221261+00
96	fog_download_url_expires_in	21600	2026-04-10 07:16:10.236967+00
97	forced_single_page_size	250	2026-04-10 07:16:10.246164+00
98	hashed_token_pepper	f10daaa08f6ebd5549750588f8bdcf3dad43ea7ce5d8a271b512a2b524c430f3	2026-04-10 07:16:10.293822+00
99	hours_per_day	8	2026-04-10 07:16:10.31487+00
100	health_checks_jobs_never_ran_minutes_ago	5	2026-04-10 07:16:10.328969+00
101	health_checks_backlog_threshold	20	2026-04-10 07:16:10.335963+00
102	gravatar_fallback_image	404	2026-04-10 07:16:10.343059+00
103	internal_password_confirmation	true	2026-04-10 07:16:10.353715+00
104	invitation_expiration_days	7	2026-04-10 07:16:10.362395+00
105	journal_aggregation_time_minutes	5	2026-04-10 07:16:10.373508+00
106	ldap_groups_disable_sync_job	f	2026-04-10 07:16:10.381143+00
107	ldap_users_disable_sync_job	f	2026-04-10 07:16:10.38877+00
108	ldap_users_sync_status	f	2026-04-10 07:16:10.396479+00
109	log_requesting_user	f	2026-04-10 07:16:10.403228+00
110	login_required	true	2026-04-10 07:16:10.409502+00
111	lost_password	true	2026-04-10 07:16:10.416157+00
112	mail_from	openproject@example.net	2026-04-10 07:16:10.424612+00
113	mail_handler_body_delimiters		2026-04-10 07:16:10.431684+00
114	mail_handler_body_delimiter_regex		2026-04-10 07:16:10.440695+00
115	mail_handler_ignore_filenames	signature.asc	2026-04-10 07:16:10.446771+00
116	mail_suffix_separators	+	2026-04-10 07:16:10.454225+00
117	new_project_send_confirmation_email	f	2026-04-10 07:16:10.460299+00
118	new_project_notification_text		2026-04-10 07:16:10.469352+00
119	notifications_hidden	f	2026-04-10 07:16:10.486209+00
120	notifications_polling_interval	60000	2026-04-10 07:16:10.499347+00
121	oauth_allow_remapping_of_existing_users	true	2026-04-10 07:16:10.518129+00
122	onboarding_enabled	true	2026-04-10 07:16:10.526876+00
123	password_active_rules	---\n- lowercase\n- uppercase\n- numeric\n- special\n	2026-04-10 07:16:10.549585+00
124	password_count_former_banned	0	2026-04-10 07:16:10.55809+00
125	password_days_valid	0	2026-04-10 07:16:10.564192+00
126	password_min_length	10	2026-04-10 07:16:10.571186+00
127	password_min_adhered_rules	0	2026-04-10 07:16:10.578389+00
128	per_page_options	20, 100	2026-04-10 07:16:10.584917+00
129	percent_complete_on_status_closed	no_change	2026-04-10 07:16:10.591956+00
130	plain_text_mail	f	2026-04-10 07:16:10.598504+00
131	show_work_package_attachments	true	2026-04-10 07:16:10.604981+00
132	registration_footer	---\nen: ''\n	2026-04-10 07:16:10.615289+00
133	report_incoming_email_errors	true	2026-04-10 07:16:10.624385+00
134	repository_checkout_data	---\ngit:\n  enabled: 0\nsubversion:\n  enabled: 0\n	2026-04-10 07:16:10.632837+00
135	repository_log_display_limit	100	2026-04-10 07:16:10.638836+00
136	repository_storage_cache_minutes	720	2026-04-10 07:16:10.647078+00
137	repository_truncate_at	500	2026-04-10 07:16:10.655175+00
138	rest_api_enabled	true	2026-04-10 07:16:10.663907+00
139	security_badge_displayed	true	2026-04-10 07:16:10.675066+00
140	self_registration	2	2026-04-10 07:16:10.685874+00
141	session_ttl_enabled	f	2026-04-10 07:16:10.693428+00
142	session_ttl	120	2026-04-10 07:16:10.703423+00
143	show_community_links	true	2026-04-10 07:16:10.712859+00
144	show_product_version	true	2026-04-10 07:16:10.724856+00
145	show_setting_mismatch_warning	true	2026-04-10 07:16:10.734427+00
146	show_storage_information	true	2026-04-10 07:16:10.741821+00
147	show_warning_bars	true	2026-04-10 07:16:10.752286+00
148	smtp_authentication	plain	2026-04-10 07:16:10.762035+00
149	smtp_enable_starttls_auto	f	2026-04-10 07:16:10.769476+00
150	smtp_ssl	f	2026-04-10 07:16:10.776536+00
151	smtp_address		2026-04-10 07:16:10.784889+00
152	smtp_domain	your.domain.com	2026-04-10 07:16:10.794871+00
153	smtp_user_name		2026-04-10 07:16:10.808193+00
154	smtp_port	587	2026-04-10 07:16:10.82328+00
155	smtp_password		2026-04-10 07:16:10.845211+00
156	smtp_timeout	5	2026-04-10 07:16:10.864844+00
157	software_name	OpenProject	2026-04-10 07:16:10.893789+00
158	software_url	https://www.openproject.org/	2026-04-10 07:16:10.899353+00
159	sys_api_enabled	f	2026-04-10 07:16:10.904404+00
161	user_default_theme	light	2026-04-10 07:16:10.913992+00
163	user_format	firstname_lastname	2026-04-10 07:16:10.92605+00
165	work_package_done_ratio	field	2026-04-10 07:16:10.936306+00
166	work_packages_projects_export_limit	500	2026-04-10 07:16:10.940935+00
167	work_packages_bulk_request_limit	10	2026-04-10 07:16:10.944894+00
168	work_package_list_default_highlighted_attributes	---\n- status\n- priority\n- due_date\n	2026-04-10 07:16:10.949587+00
169	work_package_list_default_highlighting_mode	inline	2026-04-10 07:16:10.954811+00
170	work_package_list_default_columns	---\n- id\n- subject\n- type\n- status\n- assigned_to\n- priority\n	2026-04-10 07:16:10.959854+00
171	work_package_startdate_is_adddate	f	2026-04-10 07:16:10.964382+00
172	working_days	---\n- 1\n- 2\n- 3\n- 4\n- 5\n	2026-04-10 07:16:10.96976+00
173	youtube_channel	https://www.youtube.com/c/OpenProjectCommunity	2026-04-10 07:16:10.974223+00
174	new_project_user_role_id	5	2026-04-10 07:16:10.979463+00
175	commit_fix_status_id	12	2026-04-10 07:16:10.983902+00
15	plugin_openproject_backlogs	---\nstory_types:\n- 4\n- 5\n- 6\n- 7\ntask_type: 1\npoints_burn_direction: up\nwiki_template: ''\n	2026-04-10 07:16:11.049564+00
176	welcome_title	Welcome to OpenProject!	2026-04-10 07:16:11.569564+00
177	welcome_text	OpenProject is the leading open source project management software. It supports classic, agile as well as hybrid project management and gives you full control over your data.\n\nCore features and use cases:\n\n* [Project Portfolio Management](https://www.openproject.org/collaboration-software-features/project-portfolio-management/)\n* [Project Planning and Scheduling](https://www.openproject.org/collaboration-software-features/project-planning-scheduling/)\n* [Task Management and Issue Tracking](https://www.openproject.org/collaboration-software-features/task-management/)\n* [Agile Boards (Scrum and Kanban)](https://www.openproject.org/collaboration-software-features/agile-project-management/)\n* [Requirements Management and Release Planning](https://www.openproject.org/collaboration-software-features/product-development/)\n* [Time and Cost Tracking, Budgets](https://www.openproject.org/collaboration-software-features/time-tracking/)\n* [Team Collaboration and Documentation](https://www.openproject.org/collaboration-software-features/team-collaboration/)\n\nWelcome to the future of project management.\n\nFor Admins: You can change this welcome text [here]({{opSetting:base_url}}/admin/settings/general).\n	2026-04-10 07:16:11.57347+00
164	welcome_on_homescreen	1	2026-04-10 07:16:11.577756+00
77	demo_view_of_type_gantt_seeded	true	2026-04-10 07:16:12.430963+00
75	demo_view_of_type_work_packages_table_seeded	true	2026-04-10 07:16:12.457897+00
76	demo_view_of_type_team_planner_seeded	true	2026-04-10 07:16:12.51467+00
54	boards_demo_data_available	true	2026-04-10 07:16:14.750348+00
74	demo_projects_available	true	2026-04-10 07:16:15.299526+00
178	installation_uuid	eeea9d52-ac8e-41e1-bda0-7e0825aeb415	2026-04-10 07:30:13.862748+00
179	consent_decline_mail		2026-05-04 10:56:47.585977+00
160	users_deletable_by_admins	1	2026-05-04 10:56:47.658701+00
162	users_deletable_by_self	0	2026-05-04 10:56:47.665406+00
63	consent_info	---\n:en: |-\n  ## Consent\n\n  You need to agree to the [privacy and security policy](https://www.openproject.org/data-privacy-and-security/) of this OpenProject instance.\n	2026-05-04 10:56:47.619736+00
64	consent_required	0	2026-05-04 10:56:47.632844+00
67	default_auto_hide_popups	1	2026-05-04 10:56:47.63886+00
180	user_default_timezone		2026-05-04 10:56:47.651231+00
\.


--
-- Data for Name: statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.statuses (id, name, is_closed, is_default, "position", default_done_ratio, created_at, updated_at, color_id, is_readonly, excluded_from_totals) FROM stdin;
1	New	f	t	1	0	2026-04-10 07:16:07.994451+00	2026-04-10 07:16:07.994451+00	92	f	f
2	In specification	f	f	2	10	2026-04-10 07:16:08.004528+00	2026-04-10 07:16:08.004528+00	77	f	f
3	Specified	f	f	3	20	2026-04-10 07:16:08.012312+00	2026-04-10 07:16:08.012312+00	77	f	f
4	Confirmed	f	f	4	20	2026-04-10 07:16:08.020154+00	2026-04-10 07:16:08.020154+00	57	f	f
5	To be scheduled	f	f	5	20	2026-04-10 07:16:08.027274+00	2026-04-10 07:16:08.027274+00	127	f	f
6	Scheduled	f	f	6	20	2026-04-10 07:16:08.035293+00	2026-04-10 07:16:08.035293+00	117	f	f
7	In progress	f	f	7	40	2026-04-10 07:16:08.046417+00	2026-04-10 07:16:08.046417+00	50	f	f
8	Developed	f	f	8	70	2026-04-10 07:16:08.056339+00	2026-04-10 07:16:08.056339+00	108	f	f
9	In testing	f	f	9	80	2026-04-10 07:16:08.066635+00	2026-04-10 07:16:08.066635+00	90	f	f
10	Tested	f	f	10	90	2026-04-10 07:16:08.079226+00	2026-04-10 07:16:08.079226+00	101	f	f
11	Test failed	f	f	11	70	2026-04-10 07:16:08.09048+00	2026-04-10 07:16:08.09048+00	30	f	f
12	Closed	t	f	12	100	2026-04-10 07:16:08.100529+00	2026-04-10 07:16:08.100529+00	18	f	f
13	On hold	f	f	13	0	2026-04-10 07:16:08.112454+00	2026-04-10 07:16:08.112454+00	138	f	f
14	Rejected	t	f	14	0	2026-04-10 07:16:08.126832+00	2026-04-10 07:16:08.126832+00	28	f	f
\.


--
-- Data for Name: storages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.storages (id, provider_type, name, host, creator_id, created_at, updated_at, provider_fields, health_status, health_changed_at, health_reason, health_checked_at) FROM stdin;
\.


--
-- Data for Name: storages_file_links_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.storages_file_links_journals (id, journal_id, file_link_id, link_name, storage_name) FROM stdin;
\.


--
-- Data for Name: subproject_template_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subproject_template_assignments (id, project_id, template_id, workspace_type, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: time_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.time_entries (id, project_id, user_id, work_package_id, hours, comments, activity_id, spent_on, tyear, tmonth, tweek, created_at, updated_at, overridden_costs, costs, rate_id, logged_by_id, ongoing, start_time, time_zone, entity_type, entity_id) FROM stdin;
\.


--
-- Data for Name: time_entry_activities_projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.time_entry_activities_projects (id, activity_id, project_id, active) FROM stdin;
\.


--
-- Data for Name: time_entry_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.time_entry_journals (id, project_id, user_id, work_package_id, hours, comments, activity_id, spent_on, tyear, tmonth, tweek, overridden_costs, costs, rate_id, logged_by_id, start_time, time_zone, entity_type, entity_id) FROM stdin;
\.


--
-- Data for Name: tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tokens (id, user_id, type, value, created_at, expires_on, data) FROM stdin;
2	4	Token::API	f86a5b978e4c9bf6e247bbdba51ddae9714b8348b434401ad1c0b9934b652913	2026-04-10 07:30:50.677373+00	\N	{"token_name":"REST"}
\.


--
-- Data for Name: two_factor_authentication_devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.two_factor_authentication_devices (id, type, "default", active, channel, phone_number, identifier, created_at, updated_at, last_used_at, otp_secret, user_id, webauthn_external_id, webauthn_public_key, webauthn_sign_count) FROM stdin;
\.


--
-- Data for Name: types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.types (id, name, "position", is_in_roadmap, is_milestone, is_default, color_id, created_at, updated_at, is_standard, attribute_groups, description, patterns, pdf_export_templates_config) FROM stdin;
1	Task	1	t	f	t	2	2026-04-10 07:16:08.174259+00	2026-04-10 07:16:08.174259+00	f	\N		\N	{}
2	Milestone	2	f	t	t	4	2026-04-10 07:16:08.198628+00	2026-04-10 07:16:08.198628+00	f	\N		\N	{}
3	Summary task	3	f	f	t	140	2026-04-10 07:16:08.215376+00	2026-04-10 07:16:08.215376+00	f	\N		\N	{}
4	Feature	4	t	f	f	70	2026-04-10 07:16:08.237713+00	2026-04-10 07:16:08.237713+00	f	\N		\N	{}
5	Epic	5	t	f	f	60	2026-04-10 07:16:08.244591+00	2026-04-10 07:16:08.244591+00	f	\N		\N	{}
6	User story	6	t	f	f	3	2026-04-10 07:16:08.252188+00	2026-04-10 07:16:08.252188+00	f	\N		\N	{}
7	Bug	7	t	f	f	32	2026-04-10 07:16:08.259543+00	2026-04-10 07:16:08.259543+00	f	\N		\N	{}
\.


--
-- Data for Name: user_auth_provider_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_auth_provider_links (id, user_id, auth_provider_id, external_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_passwords; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_passwords (id, user_id, hashed_password, salt, created_at, updated_at, type) FROM stdin;
2	4	$2a$12$wQMOq0zMy.YmJhSo/Qdf0O2No/6PPmPt5oq5HBTs/1PocSOSw0ODG	\N	2026-04-10 07:30:13.092948+00	2026-04-10 07:30:13.092948+00	UserPassword::Bcrypt
3	5	$2a$12$SvuNqYmJk1lXsRl5He90relW28nPP27765rT6Ec4S1ou/VM2ao2b6	\N	2026-04-10 07:32:56.98384+00	2026-04-10 07:32:56.98384+00	UserPassword::Bcrypt
4	6	$2a$12$z8c.ASHFJPHKeU5InD6AOuRTALA6oIX1CQX3CLOxKpihVZdaHIRV2	\N	2026-04-10 07:32:57.259567+00	2026-04-10 07:32:57.259567+00	UserPassword::Bcrypt
5	7	$2a$12$gYUWPCWy2Q2GRMOFxxmbFe6HGOPYJGppTaI9neLnCFAQBWvCmrtPu	\N	2026-04-10 07:32:57.541056+00	2026-04-10 07:32:57.541056+00	UserPassword::Bcrypt
6	8	$2a$12$7.FAS6ogc7MeJz.EgQEy4OrHeVImF/bKYSfv9My9dnXj6z4E.64ci	\N	2026-04-10 07:32:57.832595+00	2026-04-10 07:32:57.832595+00	UserPassword::Bcrypt
\.


--
-- Data for Name: user_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_preferences (id, user_id, settings, created_at, updated_at, dismissed_enterprise_banners) FROM stdin;
1	4	\N	2026-04-10 07:30:13.06982+00	2026-04-10 07:30:13.06982+00	{}
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, login, firstname, lastname, mail, admin, status, last_login_on, language, ldap_auth_source_id, created_at, updated_at, type, identity_url, first_login, force_password_change, failed_login_count, last_failed_login_on, consented_at, webauthn_id) FROM stdin;
1			System		t	1	\N		\N	2026-04-10 07:16:06.814866+00	2026-04-10 07:16:06.814866+00	SystemUser	\N	f	f	0	\N	\N	\N
2			Anonymous		f	1	\N		\N	2026-04-10 07:16:06.8355+00	2026-04-10 07:16:06.8355+00	AnonymousUser	\N	t	f	0	\N	\N	\N
3					f	3	\N		\N	2026-04-10 07:16:06.874713+00	2026-04-10 07:16:06.874713+00	DeletedUser	\N	t	f	0	\N	\N	\N
5	alice	Alice	Novak	alice@example.com	f	1	\N	en	\N	2026-04-10 07:32:56.971328+00	2026-04-10 07:32:56.971328+00	User	\N	t	f	0	\N	\N	\N
6	bob	Bob	Hrasko	bob@example.com	f	1	\N	en	\N	2026-04-10 07:32:57.255904+00	2026-04-10 07:32:57.255904+00	User	\N	t	f	0	\N	\N	\N
7	carol	Carol	Kovac	carol@example.com	f	1	\N	en	\N	2026-04-10 07:32:57.531058+00	2026-04-10 07:32:57.531058+00	User	\N	t	f	0	\N	\N	\N
8	dave	Dave	Mrva	dave@example.com	f	1	\N	en	\N	2026-04-10 07:32:57.82553+00	2026-04-10 07:32:57.82553+00	User	\N	t	f	0	\N	\N	\N
9			Workshop Team		f	1	\N		\N	2026-04-10 07:32:58.304199+00	2026-04-10 07:32:58.315993+00	Group	\N	t	f	0	\N	\N	\N
4	admin	OpenProject	Admin	admin@example.net	t	1	2026-05-04 10:56:28.370029+00	en	\N	2026-04-10 07:16:11.188542+00	2026-05-04 10:56:28.402131+00	User	\N	f	f	0	2026-04-10 07:28:55.68227+00	\N	\N
\.


--
-- Data for Name: version_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.version_settings (id, project_id, version_id, display, created_at, updated_at) FROM stdin;
1	2	1	3	2026-04-10 07:16:15.56558+00	2026-04-10 07:16:15.56558+00
2	2	2	3	2026-04-10 07:16:15.569052+00	2026-04-10 07:16:15.569052+00
3	2	3	2	2026-04-10 07:16:15.571131+00	2026-04-10 07:16:15.571131+00
4	2	4	2	2026-04-10 07:16:15.572476+00	2026-04-10 07:16:15.572476+00
\.


--
-- Data for Name: versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.versions (id, project_id, name, description, effective_date, created_at, updated_at, wiki_page_title, status, sharing, start_date) FROM stdin;
1	2	Bug Backlog		\N	2026-04-10 07:16:15.472579+00	2026-04-10 07:16:15.472579+00	\N	open	none	\N
2	2	Product Backlog		\N	2026-04-10 07:16:15.489316+00	2026-04-10 07:16:15.489316+00	\N	open	none	\N
3	2	Sprint 1		\N	2026-04-10 07:16:15.491876+00	2026-04-10 07:16:15.542935+00	Sprint 1	open	none	\N
4	2	Sprint 2		\N	2026-04-10 07:16:15.547378+00	2026-04-10 07:16:15.547378+00	\N	open	none	\N
\.


--
-- Data for Name: views; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.views (id, query_id, options, type, created_at, updated_at) FROM stdin;
1	1	{}	gantt	2026-04-10 07:16:12.426381+00	2026-04-10 07:16:12.426381+00
2	2	{}	work_packages_table	2026-04-10 07:16:12.456045+00	2026-04-10 07:16:12.456045+00
3	3	{}	work_packages_table	2026-04-10 07:16:12.479441+00	2026-04-10 07:16:12.479441+00
4	4	{}	team_planner	2026-04-10 07:16:12.512939+00	2026-04-10 07:16:12.512939+00
5	15	{}	gantt	2026-04-10 07:16:15.609652+00	2026-04-10 07:16:15.609652+00
6	16	{}	work_packages_table	2026-04-10 07:16:15.64076+00	2026-04-10 07:16:15.64076+00
7	17	{}	work_packages_table	2026-04-10 07:16:15.678133+00	2026-04-10 07:16:15.678133+00
8	18	{}	work_packages_table	2026-04-10 07:16:15.698277+00	2026-04-10 07:16:15.698277+00
\.


--
-- Data for Name: watchers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.watchers (id, watchable_type, watchable_id, user_id) FROM stdin;
1	News	1	4
2	Meeting	1	4
3	News	2	4
4	Meeting	2	4
5	WorkPackage	37	4
6	WorkPackage	38	4
7	WorkPackage	39	4
8	WorkPackage	40	4
9	WorkPackage	41	4
10	WorkPackage	42	4
11	WorkPackage	43	4
12	WorkPackage	44	4
13	WorkPackage	45	4
14	Meeting	3	4
15	Meeting	4	4
16	Meeting	5	4
\.


--
-- Data for Name: webhooks_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhooks_events (id, name, webhooks_webhook_id) FROM stdin;
\.


--
-- Data for Name: webhooks_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhooks_logs (id, webhooks_webhook_id, event_name, url, request_headers, request_body, response_code, response_headers, response_body, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: webhooks_projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhooks_projects (id, project_id, webhooks_webhook_id) FROM stdin;
\.


--
-- Data for Name: webhooks_webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhooks_webhooks (id, name, url, description, secret, enabled, all_projects, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: wiki_page_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wiki_page_journals (id, author_id, text) FROM stdin;
1	4	_In this wiki you can collaboratively create and edit pages and sub-pages to create a project wiki._\n\n**You can:**\n\n* Insert text and images, also with copy and paste from other documents\n* Create a page hierarchy with parent pages\n* Include wiki pages to the project menu\n* Use macros to include, e.g. table of contents, work package lists, or Gantt charts\n* Include wiki pages in other text fields, e.g. project overview page\n* Include links to other documents\n* View the change history\n* View as Markdown\n\nMore information: [https://www.openproject.org/docs/user-guide/wiki/](https://www.openproject.org/docs/user-guide/wiki/)\n
2	1	### Sprint planning meeting\n\n_Please document here topics to the Sprint planning meeting_\n\n* Time boxed (8 h)\n* Input: Product Backlog\n* Output: Sprint Backlog\n\n* Divided into two additional time boxes of 4 h:\n\n    * The Product Owner presents the [Product Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) and the priorities to the team and explains the Sprint Goal, to which the team must agree. Together, they prioritize the topics from the Product Backlog which the team will take care of in the next sprint. The team commits to the discussed delivery.\n    * The team plans autonomously (without the Product Owner) in detail and breaks down the tasks from the discussed requirements to consolidate a [Sprint Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs).\n\n\n### Daily Scrum meeting\n\n_Please document here topics to the Daily Scrum meeting_\n\n* Short, daily status meeting of the team.\n* Time boxed (max. 15 min).\n* Stand-up meeting to discuss the following topics from the [Task board](/projects/your-scrum-project/sprints/3/taskboard).\n    * What do I plan to do until the next Daily Scrum?\n    * What has blocked my work (Impediments)?\n* Scrum Master moderates and notes down [Sprint Impediments](/projects/your-scrum-project/sprints/3/taskboard).\n* Product Owner may participate may participate in order to stay informed.\n\n### Sprint Review meeting\n\n_Please document here topics to the Sprint Review meeting_\n\n* Time boxed (4 h).\n* A maximum of one hour of preparation time per person.\n* The team shows the product owner and other interested persons what has been achieved in this sprint.\n* Important: no dummies and no PowerPoint! Just finished product functionality (Increments) should be demonstrated.\n* Feedback from Product Owner, stakeholders and others is desired and will be included in further work.\n* Based on the demonstrated functionalities, the Product Owner decides to go live with this increment or to develop it further. This possibility allows an early ROI.\n\n\n### Sprint Retrospective\n\n_Please document here topics to the Sprint Retrospective meeting_\n\n* Time boxed (3 h).\n* After Sprint Review, will be moderated by Scrum Master.\n* The team discusses the sprint: what went well, what needs to be improved to be more productive for the next sprint or even have more fun.\n
3	4	### Sprint planning meeting\n\n_Please document here topics to the Sprint planning meeting_\n\n* Time boxed (8 h)\n* Input: Product Backlog\n* Output: Sprint Backlog\n\n* Divided into two additional time boxes of 4 h:\n\n    * The Product Owner presents the [Product Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) and the priorities to the team and explains the Sprint Goal, to which the team must agree. Together, they prioritize the topics from the Product Backlog which the team will take care of in the next sprint. The team commits to the discussed delivery.\n    * The team plans autonomously (without the Product Owner) in detail and breaks down the tasks from the discussed requirements to consolidate a [Sprint Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs).\n\n\n### Daily Scrum meeting\n\n_Please document here topics to the Daily Scrum meeting_\n\n* Short, daily status meeting of the team.\n* Time boxed (max. 15 min).\n* Stand-up meeting to discuss the following topics from the Task board.\n    * What do I plan to do until the next Daily Scrum?\n    * What has blocked my work (Impediments)?\n* Scrum Master moderates and notes down Sprint Impediments.\n* Product Owner may participate may participate in order to stay informed.\n\n### Sprint Review meeting\n\n_Please document here topics to the Sprint Review meeting_\n\n* Time boxed (4 h).\n* A maximum of one hour of preparation time per person.\n* The team shows the product owner and other interested persons what has been achieved in this sprint.\n* Important: no dummies and no PowerPoint! Just finished product functionality (Increments) should be demonstrated.\n* Feedback from Product Owner, stakeholders and others is desired and will be included in further work.\n* Based on the demonstrated functionalities, the Product Owner decides to go live with this increment or to develop it further. This possibility allows an early ROI.\n\n\n### Sprint Retrospective\n\n_Please document here topics to the Sprint Retrospective meeting_\n\n* Time boxed (3 h).\n* After Sprint Review, will be moderated by Scrum Master.\n* The team discusses the sprint: what went well, what needs to be improved to be more productive for the next sprint or even have more fun.\n
\.


--
-- Data for Name: wiki_pages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wiki_pages (id, wiki_id, title, created_at, protected, parent_id, slug, updated_at, author_id, text, lock_version) FROM stdin;
1	1	Wiki	2026-04-10 07:16:12.733823+00	f	\N	wiki	2026-04-10 07:16:12.733823+00	4	_In this wiki you can collaboratively create and edit pages and sub-pages to create a project wiki._\n\n**You can:**\n\n* Insert text and images, also with copy and paste from other documents\n* Create a page hierarchy with parent pages\n* Include wiki pages to the project menu\n* Use macros to include, e.g. table of contents, work package lists, or Gantt charts\n* Include wiki pages in other text fields, e.g. project overview page\n* Include links to other documents\n* View the change history\n* View as Markdown\n\nMore information: [https://www.openproject.org/docs/user-guide/wiki/](https://www.openproject.org/docs/user-guide/wiki/)\n	0
2	2	Sprint 1	2026-04-10 07:16:15.505935+00	f	\N	sprint-1	2026-04-10 07:16:15.505935+00	1	### Sprint planning meeting\n\n_Please document here topics to the Sprint planning meeting_\n\n* Time boxed (8 h)\n* Input: Product Backlog\n* Output: Sprint Backlog\n\n* Divided into two additional time boxes of 4 h:\n\n    * The Product Owner presents the [Product Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) and the priorities to the team and explains the Sprint Goal, to which the team must agree. Together, they prioritize the topics from the Product Backlog which the team will take care of in the next sprint. The team commits to the discussed delivery.\n    * The team plans autonomously (without the Product Owner) in detail and breaks down the tasks from the discussed requirements to consolidate a [Sprint Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs).\n\n\n### Daily Scrum meeting\n\n_Please document here topics to the Daily Scrum meeting_\n\n* Short, daily status meeting of the team.\n* Time boxed (max. 15 min).\n* Stand-up meeting to discuss the following topics from the [Task board](/projects/your-scrum-project/sprints/3/taskboard).\n    * What do I plan to do until the next Daily Scrum?\n    * What has blocked my work (Impediments)?\n* Scrum Master moderates and notes down [Sprint Impediments](/projects/your-scrum-project/sprints/3/taskboard).\n* Product Owner may participate may participate in order to stay informed.\n\n### Sprint Review meeting\n\n_Please document here topics to the Sprint Review meeting_\n\n* Time boxed (4 h).\n* A maximum of one hour of preparation time per person.\n* The team shows the product owner and other interested persons what has been achieved in this sprint.\n* Important: no dummies and no PowerPoint! Just finished product functionality (Increments) should be demonstrated.\n* Feedback from Product Owner, stakeholders and others is desired and will be included in further work.\n* Based on the demonstrated functionalities, the Product Owner decides to go live with this increment or to develop it further. This possibility allows an early ROI.\n\n\n### Sprint Retrospective\n\n_Please document here topics to the Sprint Retrospective meeting_\n\n* Time boxed (3 h).\n* After Sprint Review, will be moderated by Scrum Master.\n* The team discusses the sprint: what went well, what needs to be improved to be more productive for the next sprint or even have more fun.\n	0
3	2	Wiki	2026-04-10 07:16:15.705957+00	f	\N	wiki	2026-04-10 07:16:15.705957+00	4	### Sprint planning meeting\n\n_Please document here topics to the Sprint planning meeting_\n\n* Time boxed (8 h)\n* Input: Product Backlog\n* Output: Sprint Backlog\n\n* Divided into two additional time boxes of 4 h:\n\n    * The Product Owner presents the [Product Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs) and the priorities to the team and explains the Sprint Goal, to which the team must agree. Together, they prioritize the topics from the Product Backlog which the team will take care of in the next sprint. The team commits to the discussed delivery.\n    * The team plans autonomously (without the Product Owner) in detail and breaks down the tasks from the discussed requirements to consolidate a [Sprint Backlog]({{opSetting:base_url}}/projects/your-scrum-project/backlogs).\n\n\n### Daily Scrum meeting\n\n_Please document here topics to the Daily Scrum meeting_\n\n* Short, daily status meeting of the team.\n* Time boxed (max. 15 min).\n* Stand-up meeting to discuss the following topics from the Task board.\n    * What do I plan to do until the next Daily Scrum?\n    * What has blocked my work (Impediments)?\n* Scrum Master moderates and notes down Sprint Impediments.\n* Product Owner may participate may participate in order to stay informed.\n\n### Sprint Review meeting\n\n_Please document here topics to the Sprint Review meeting_\n\n* Time boxed (4 h).\n* A maximum of one hour of preparation time per person.\n* The team shows the product owner and other interested persons what has been achieved in this sprint.\n* Important: no dummies and no PowerPoint! Just finished product functionality (Increments) should be demonstrated.\n* Feedback from Product Owner, stakeholders and others is desired and will be included in further work.\n* Based on the demonstrated functionalities, the Product Owner decides to go live with this increment or to develop it further. This possibility allows an early ROI.\n\n\n### Sprint Retrospective\n\n_Please document here topics to the Sprint Retrospective meeting_\n\n* Time boxed (3 h).\n* After Sprint Review, will be moderated by Scrum Master.\n* The team discusses the sprint: what went well, what needs to be improved to be more productive for the next sprint or even have more fun.\n	0
\.


--
-- Data for Name: wiki_redirects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wiki_redirects (id, wiki_id, title, redirects_to, created_at) FROM stdin;
\.


--
-- Data for Name: wikis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.wikis (id, project_id, start_page, status, created_at, updated_at) FROM stdin;
1	1	Wiki	1	2026-04-10 07:16:11.738206+00	2026-04-10 07:16:12.73724+00
2	2	Wiki	1	2026-04-10 07:16:15.330326+00	2026-04-10 07:16:15.707007+00
3	3	Wiki	1	2026-04-10 07:32:56.658253+00	2026-04-10 07:32:56.658253+00
\.


--
-- Data for Name: work_package_hierarchies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_package_hierarchies (ancestor_id, descendant_id, generations) FROM stdin;
1	1	0
2	2	0
3	3	0
2	3	1
4	4	0
3	4	1
2	4	2
5	5	0
3	5	1
2	5	2
6	6	0
3	6	1
2	6	2
7	7	0
2	7	1
8	8	0
2	8	1
9	9	0
10	10	0
11	11	0
10	11	1
12	12	0
10	12	1
13	13	0
14	14	0
15	15	0
16	16	0
17	17	0
16	17	1
18	18	0
16	18	1
19	19	0
16	19	1
20	20	0
19	20	1
16	20	2
21	21	0
22	22	0
23	23	0
22	23	1
24	24	0
25	25	0
26	26	0
27	27	0
28	28	0
29	29	0
28	29	1
30	30	0
31	31	0
32	32	0
33	33	0
34	34	0
35	35	0
36	36	0
37	37	0
38	38	0
39	39	0
40	40	0
37	40	1
41	41	0
37	41	1
42	42	0
38	42	1
43	43	0
38	43	1
44	44	0
38	44	1
45	45	0
39	45	1
\.


--
-- Data for Name: work_package_journals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_package_journals (id, type_id, project_id, subject, description, due_date, category_id, status_id, assigned_to_id, priority_id, version_id, author_id, done_ratio, estimated_hours, start_date, parent_id, responsible_id, derived_estimated_hours, schedule_manually, duration, ignore_non_working_days, derived_remaining_hours, derived_done_ratio, story_points, remaining_hours, budget_id, project_phase_definition_id) FROM stdin;
1	2	1	Start of project		2026-04-05	\N	12	4	8	\N	4	\N	\N	2026-04-05	\N	\N	\N	t	1	t	\N	\N	\N	\N	\N	\N
2	3	1	Organize open source conference		2026-04-20	\N	7	4	8	\N	4	\N	\N	2026-04-06	\N	\N	\N	f	11	f	\N	\N	\N	\N	\N	\N
5	1	1	Send invitation to speakers		2026-04-06	\N	7	4	8	\N	4	\N	\N	2026-04-06	3	\N	\N	t	1	f	\N	\N	\N	\N	\N	\N
7	1	1	Contact sponsoring partners		2026-04-07	\N	1	4	8	\N	4	\N	\N	2026-04-06	3	\N	\N	t	2	f	\N	\N	\N	\N	\N	\N
9	1	1	Create sponsorship brochure and hand-outs		2026-04-09	\N	1	4	8	\N	4	\N	\N	2026-04-06	3	\N	\N	t	4	f	\N	\N	\N	\N	\N	\N
10	1	1	Set date and location of conference		2026-04-09	\N	7	4	8	\N	4	\N	\N	2026-04-06	2	\N	\N	f	4	f	\N	\N	\N	\N	\N	\N
12	1	1	Invite attendees to conference		2026-04-10	\N	1	4	8	\N	4	\N	\N	2026-04-10	2	\N	\N	f	1	f	\N	\N	\N	\N	\N	\N
14	1	1	Setup conference website		2026-04-20	\N	1	4	8	\N	4	\N	\N	2026-04-10	2	\N	\N	f	7	f	\N	\N	\N	\N	\N	\N
15	2	1	Conference		2026-04-21	\N	6	4	8	\N	4	\N	\N	2026-04-21	\N	\N	\N	f	1	f	\N	\N	\N	\N	\N	\N
16	3	1	Follow-up tasks		2026-05-07	\N	5	4	8	\N	4	\N	\N	2026-04-27	\N	\N	\N	f	9	f	\N	\N	\N	\N	\N	\N
18	1	1	Upload presentations to website		2026-05-06	\N	1	4	8	\N	4	\N	\N	2026-04-27	10	\N	\N	t	8	f	\N	\N	\N	\N	\N	\N
20	1	1	Party for conference supporters :-)	*   [ ] Beer\n*   [ ] Snacks\n*   [ ] Music\n*   [ ] Even more beer	2026-05-07	\N	1	4	8	\N	4	\N	\N	2026-05-07	10	\N	\N	t	1	f	\N	\N	\N	\N	\N	\N
21	2	1	End of project		2026-05-08	\N	1	4	8	\N	4	\N	\N	2026-05-08	\N	\N	\N	f	1	f	\N	\N	\N	\N	\N	\N
22	6	2	New login screen		\N	\N	2	4	8	2	4	\N	\N	2026-04-06	\N	\N	\N	t	\N	f	\N	\N	\N	\N	\N	\N
23	7	2	Password reset does not send email		\N	\N	4	4	8	1	4	\N	\N	2026-04-06	\N	\N	\N	t	\N	f	\N	\N	\N	\N	\N	\N
24	5	2	New website		2026-05-04	\N	3	4	8	\N	4	\N	\N	2026-04-06	\N	\N	\N	f	21	f	\N	\N	\N	\N	\N	\N
26	6	2	Newsletter registration form		\N	\N	7	4	8	2	4	\N	\N	2026-04-06	16	\N	\N	t	\N	f	\N	\N	\N	\N	\N	\N
28	6	2	Implement product tour		\N	\N	2	4	8	2	4	\N	\N	2026-04-06	16	\N	\N	t	\N	f	\N	\N	\N	\N	\N	\N
31	1	2	Create wireframes for new landing page		2026-05-04	\N	7	4	8	3	4	\N	\N	2026-05-04	19	\N	\N	t	1	f	\N	\N	\N	\N	\N	\N
32	6	2	New landing page		2026-05-04	\N	3	4	8	3	4	\N	\N	2026-05-04	16	\N	\N	f	1	f	\N	\N	3	\N	\N	\N
33	6	2	Contact form		2026-04-27	\N	3	4	8	3	4	\N	\N	2026-04-27	\N	\N	\N	t	1	f	\N	\N	1	\N	\N	\N
34	6	2	Feature carousel		\N	\N	3	4	8	3	4	\N	\N	2026-04-06	\N	\N	\N	f	\N	f	\N	\N	5	\N	\N	\N
36	1	2	Make screenshots for feature tour		\N	\N	12	4	8	3	4	\N	\N	2026-04-06	22	\N	\N	t	\N	f	\N	\N	\N	\N	\N	\N
37	7	2	Wrong hover color		2026-04-27	\N	14	4	8	3	4	\N	\N	2026-04-27	\N	\N	\N	t	1	f	\N	\N	1	\N	\N	\N
38	6	2	SSL certificate		2026-04-28	\N	3	4	8	2	4	\N	\N	2026-04-28	\N	\N	\N	t	1	f	\N	\N	\N	\N	\N	\N
39	6	2	Set-up Staging environment		2026-04-29	\N	2	4	8	2	4	\N	\N	2026-04-29	\N	\N	\N	t	1	f	\N	\N	\N	\N	\N	\N
40	6	2	Choose a content management system		2026-04-30	\N	3	4	8	2	4	\N	\N	2026-04-30	\N	\N	\N	t	1	f	\N	\N	\N	\N	\N	\N
41	6	2	Website navigation structure		2026-05-01	\N	3	4	8	3	4	\N	\N	2026-05-01	\N	\N	\N	f	1	f	\N	\N	3	\N	\N	\N
43	1	2	Set up navigation concept for website.		2026-05-01	\N	2	4	8	3	4	\N	\N	2026-05-01	28	\N	\N	t	1	f	\N	\N	\N	\N	\N	\N
44	6	2	Internal link structure		2026-05-01	\N	12	4	8	2	4	\N	\N	2026-05-01	\N	\N	\N	t	1	f	\N	\N	\N	\N	\N	\N
45	3	2	Develop v1.0		2026-04-23	\N	7	4	8	\N	4	\N	\N	2026-04-20	\N	\N	\N	t	4	f	\N	\N	\N	\N	\N	\N
46	2	2	Release v1.0		2026-04-24	\N	1	4	8	\N	4	\N	\N	2026-04-24	\N	\N	\N	f	1	f	\N	\N	\N	\N	\N	\N
47	3	2	Develop v1.1		2026-04-30	\N	1	4	8	\N	4	\N	\N	2026-04-27	\N	\N	\N	t	4	f	\N	\N	\N	\N	\N	\N
48	2	2	Release v1.1		2026-05-01	\N	1	4	8	\N	4	\N	\N	2026-05-01	\N	\N	\N	f	1	f	\N	\N	\N	\N	\N	\N
49	3	2	Develop v2.0		2026-05-07	\N	1	4	8	\N	4	\N	\N	2026-05-04	\N	\N	\N	t	4	f	\N	\N	\N	\N	\N	\N
50	2	2	Release v2.0		2026-05-08	\N	1	4	8	\N	4	\N	\N	2026-05-08	\N	\N	\N	f	1	f	\N	\N	\N	\N	\N	\N
54	1	3	Create participant accounts	Prepare accounts for students.	2026-05-05	\N	1	7	7	\N	4	0	2	2026-05-05	37	\N	\N	t	1	f	\N	\N	\N	2	\N	\N
56	1	3	Prepare workshop kickoff	Initial planning, goals, and setup.	2026-05-05	\N	1	5	7	\N	4	0	6	2026-05-05	\N	\N	8	f	1	f	8	0	\N	6	\N	\N
57	1	3	Prepare agenda	Draft workshop agenda and timings.	2026-05-06	\N	1	8	7	\N	4	0	3	2026-05-05	37	\N	\N	t	2	f	\N	\N	\N	3	\N	\N
59	1	3	Prepare workshop kickoff	Initial planning, goals, and setup.	2026-05-06	\N	1	5	7	\N	4	0	6	2026-05-05	\N	\N	11	f	2	f	11	0	\N	6	\N	\N
60	1	3	Write exercise 1	Basic work package exercise.	2026-05-11	\N	1	5	7	\N	4	0	4	2026-05-08	38	\N	\N	t	2	f	\N	\N	\N	4	\N	\N
62	1	3	Build demo backlog	Create user stories and supporting tasks.	2026-05-11	\N	1	6	7	\N	4	0	10	2026-05-08	\N	\N	14	f	2	f	14	0	\N	10	\N	\N
63	1	3	Write exercise 2	Boards and timelines exercise.	2026-05-11	\N	1	6	7	\N	4	0	4	2026-05-11	38	\N	\N	t	1	f	\N	\N	\N	4	\N	\N
64	1	3	Build demo backlog	Create user stories and supporting tasks.	2026-05-11	\N	1	6	7	\N	4	0	10	2026-05-08	\N	\N	18	f	2	f	18	0	\N	10	\N	\N
65	1	3	Create trainer notes	Facilitator guide and answers.	2026-05-11	\N	1	7	7	\N	4	0	3	2026-05-11	38	\N	\N	t	1	f	\N	\N	\N	3	\N	\N
66	1	3	Build demo backlog	Create user stories and supporting tasks.	2026-05-11	\N	1	6	7	\N	4	0	10	2026-05-08	\N	\N	21	f	2	f	21	0	\N	10	\N	\N
67	1	3	Collect feedback	Capture pilot retrospective notes.	2026-05-18	\N	1	8	7	\N	4	0	2	2026-05-18	39	\N	\N	t	1	f	\N	\N	\N	2	\N	\N
69	1	3	Run pilot session	Trial run with internal audience.	2026-05-18	\N	1	5	7	\N	4	0	8	2026-05-18	\N	\N	10	f	1	f	10	0	\N	8	\N	\N
\.


--
-- Data for Name: work_packages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_packages (id, type_id, project_id, subject, description, due_date, category_id, status_id, assigned_to_id, priority_id, version_id, author_id, lock_version, done_ratio, estimated_hours, created_at, updated_at, start_date, responsible_id, derived_estimated_hours, schedule_manually, parent_id, duration, ignore_non_working_days, derived_remaining_hours, derived_done_ratio, "position", story_points, remaining_hours, budget_id, project_phase_definition_id) FROM stdin;
1	2	1	Start of project	\N	2026-04-05	\N	12	4	8	\N	4	0	\N	\N	2026-04-10 07:16:12.814+00	2026-04-10 07:16:12.814+00	2026-04-05	\N	\N	t	\N	1	t	\N	\N	1	\N	\N	\N	\N
2	3	1	Organize open source conference		2026-04-20	\N	7	4	8	\N	4	0	\N	\N	2026-04-10 07:16:12.955551+00	2026-04-10 07:16:12.955551+00	2026-04-06	\N	\N	f	\N	11	f	\N	\N	1	\N	\N	\N	\N
4	1	1	Send invitation to speakers		2026-04-06	\N	7	4	8	\N	4	1	\N	\N	2026-04-10 07:16:13.109164+00	2026-04-10 07:16:13.194382+00	2026-04-06	\N	\N	t	3	1	f	\N	\N	1	\N	\N	\N	\N
5	1	1	Contact sponsoring partners		2026-04-07	\N	1	4	8	\N	4	1	\N	\N	2026-04-10 07:16:13.279438+00	2026-04-10 07:16:13.362904+00	2026-04-06	\N	\N	t	3	2	f	\N	\N	1	\N	\N	\N	\N
6	1	1	Create sponsorship brochure and hand-outs		2026-04-09	\N	1	4	8	\N	4	1	\N	\N	2026-04-10 07:16:13.485643+00	2026-04-10 07:16:13.563346+00	2026-04-06	\N	\N	t	3	4	f	\N	\N	1	\N	\N	\N	\N
3	1	1	Set date and location of conference		2026-04-09	\N	7	4	8	\N	4	1	\N	\N	2026-04-10 07:16:13.028552+00	2026-04-10 07:16:13.642595+00	2026-04-06	\N	\N	f	2	4	f	\N	\N	1	\N	\N	\N	\N
7	1	1	Invite attendees to conference		2026-04-10	\N	1	4	8	\N	4	1	\N	\N	2026-04-10 07:16:13.730402+00	2026-04-10 07:16:13.807056+00	2026-04-10	\N	\N	f	2	1	f	\N	\N	1	\N	\N	\N	\N
8	1	1	Setup conference website		2026-04-20	\N	1	4	8	\N	4	1	\N	\N	2026-04-10 07:16:13.877223+00	2026-04-10 07:16:13.9638+00	2026-04-10	\N	\N	f	2	7	f	\N	\N	1	\N	\N	\N	\N
9	2	1	Conference		2026-04-21	\N	6	4	8	\N	4	0	\N	\N	2026-04-10 07:16:14.04038+00	2026-04-10 07:16:14.04038+00	2026-04-21	\N	\N	f	\N	1	f	\N	\N	1	\N	\N	\N	\N
10	3	1	Follow-up tasks		2026-05-07	\N	5	4	8	\N	4	0	\N	\N	2026-04-10 07:16:14.11422+00	2026-04-10 07:16:14.11422+00	2026-04-27	\N	\N	f	\N	9	f	\N	\N	1	\N	\N	\N	\N
11	1	1	Upload presentations to website		2026-05-06	\N	1	4	8	\N	4	1	\N	\N	2026-04-10 07:16:14.177112+00	2026-04-10 07:16:14.247884+00	2026-04-27	\N	\N	t	10	8	f	\N	\N	1	\N	\N	\N	\N
12	1	1	Party for conference supporters :-)	*   [ ] Beer\n*   [ ] Snacks\n*   [ ] Music\n*   [ ] Even more beer	2026-05-07	\N	1	4	8	\N	4	1	\N	\N	2026-04-10 07:16:14.335453+00	2026-04-10 07:16:14.408619+00	2026-05-07	\N	\N	t	10	1	f	\N	\N	1	\N	\N	\N	\N
13	2	1	End of project	\N	2026-05-08	\N	1	4	8	\N	4	0	\N	\N	2026-04-10 07:16:14.488504+00	2026-04-10 07:16:14.488504+00	2026-05-08	\N	\N	f	\N	1	f	\N	\N	1	\N	\N	\N	\N
15	7	2	Password reset does not send email	\N	\N	\N	4	4	8	1	4	0	\N	\N	2026-04-10 07:16:15.856276+00	2026-04-10 07:16:15.856276+00	2026-04-06	\N	\N	t	\N	\N	f	\N	\N	1	\N	\N	\N	\N
16	5	2	New website	\N	2026-05-04	\N	3	4	8	\N	4	0	\N	\N	2026-04-10 07:16:15.948314+00	2026-04-10 07:16:15.948314+00	2026-04-06	\N	\N	f	\N	21	f	\N	\N	1	\N	\N	\N	\N
20	1	2	Create wireframes for new landing page	\N	2026-05-04	\N	7	4	8	3	4	1	\N	\N	2026-04-10 07:16:16.414831+00	2026-04-10 07:16:16.48685+00	2026-05-04	\N	\N	t	19	1	f	\N	\N	1	\N	\N	\N	\N
19	6	2	New landing page	\N	2026-05-04	\N	3	4	8	3	4	1	\N	\N	2026-04-10 07:16:16.347218+00	2026-04-10 07:16:16.564239+00	2026-05-04	\N	\N	f	16	1	f	\N	\N	2	3	\N	\N	\N
22	6	2	Feature carousel	\N	\N	\N	3	4	8	3	4	0	\N	\N	2026-04-10 07:16:16.72846+00	2026-04-10 07:16:16.72846+00	2026-04-06	\N	\N	f	\N	\N	f	\N	\N	3	5	\N	\N	\N
23	1	2	Make screenshots for feature tour	\N	\N	\N	12	4	8	3	4	1	\N	\N	2026-04-10 07:16:16.80073+00	2026-04-10 07:16:16.872802+00	2026-04-06	\N	\N	t	22	\N	f	\N	\N	1	\N	\N	\N	\N
24	7	2	Wrong hover color	\N	2026-04-27	\N	14	4	8	3	4	0	\N	\N	2026-04-10 07:16:16.951956+00	2026-04-10 07:16:16.951956+00	2026-04-27	\N	\N	t	\N	1	f	\N	\N	4	1	\N	\N	\N
25	6	2	SSL certificate	\N	2026-04-28	\N	3	4	8	2	4	0	\N	\N	2026-04-10 07:16:17.047257+00	2026-04-10 07:16:17.047257+00	2026-04-28	\N	\N	t	\N	1	f	\N	\N	1	\N	\N	\N	\N
26	6	2	Set-up Staging environment	\N	2026-04-29	\N	2	4	8	2	4	0	\N	\N	2026-04-10 07:16:17.158961+00	2026-04-10 07:16:17.158961+00	2026-04-29	\N	\N	t	\N	1	f	\N	\N	2	\N	\N	\N	\N
21	6	2	Contact form	\N	2026-04-27	\N	3	4	8	3	4	0	\N	\N	2026-04-10 07:16:16.647326+00	2026-04-10 07:16:16.647326+00	2026-04-27	\N	\N	t	\N	1	f	\N	\N	8	1	\N	\N	\N
28	6	2	Website navigation structure	\N	2026-05-01	\N	3	4	8	3	4	0	\N	\N	2026-04-10 07:16:17.322536+00	2026-04-10 07:16:17.322536+00	2026-05-01	\N	\N	f	\N	1	f	\N	\N	7	3	\N	\N	\N
29	1	2	Set up navigation concept for website.	\N	2026-05-01	\N	2	4	8	3	4	1	\N	\N	2026-04-10 07:16:17.455261+00	2026-04-10 07:16:17.539984+00	2026-05-01	\N	\N	t	28	1	f	\N	\N	1	\N	\N	\N	\N
14	6	2	New login screen	\N	\N	\N	2	4	8	2	4	0	\N	\N	2026-04-10 07:16:15.758136+00	2026-04-10 07:16:15.758136+00	2026-04-06	\N	\N	t	\N	\N	f	\N	\N	6	\N	\N	\N	\N
17	6	2	Newsletter registration form	\N	\N	\N	7	4	8	2	4	1	\N	\N	2026-04-10 07:16:16.024391+00	2026-04-10 07:16:16.118579+00	2026-04-06	\N	\N	t	16	\N	f	\N	\N	11	\N	\N	\N	\N
18	6	2	Implement product tour	\N	\N	\N	2	4	8	2	4	1	\N	\N	2026-04-10 07:16:16.200444+00	2026-04-10 07:16:16.279268+00	2026-04-06	\N	\N	t	16	\N	f	\N	\N	7	\N	\N	\N	\N
27	6	2	Choose a content management system	\N	2026-04-30	\N	3	4	8	2	4	0	\N	\N	2026-04-10 07:16:17.241532+00	2026-04-10 07:16:17.241532+00	2026-04-30	\N	\N	t	\N	1	f	\N	\N	8	\N	\N	\N	\N
30	6	2	Internal link structure	\N	2026-05-01	\N	12	4	8	2	4	0	\N	\N	2026-04-10 07:16:17.625255+00	2026-04-10 07:16:17.625255+00	2026-05-01	\N	\N	t	\N	1	f	\N	\N	5	\N	\N	\N	\N
31	3	2	Develop v1.0	\N	2026-04-23	\N	7	4	8	\N	4	0	\N	\N	2026-04-10 07:16:17.709674+00	2026-04-10 07:16:17.709674+00	2026-04-20	\N	\N	t	\N	4	f	\N	\N	1	\N	\N	\N	\N
32	2	2	Release v1.0	\N	2026-04-24	\N	1	4	8	\N	4	0	\N	\N	2026-04-10 07:16:17.784827+00	2026-04-10 07:16:17.784827+00	2026-04-24	\N	\N	f	\N	1	f	\N	\N	1	\N	\N	\N	\N
33	3	2	Develop v1.1	\N	2026-04-30	\N	1	4	8	\N	4	0	\N	\N	2026-04-10 07:16:17.862116+00	2026-04-10 07:16:17.862116+00	2026-04-27	\N	\N	t	\N	4	f	\N	\N	1	\N	\N	\N	\N
34	2	2	Release v1.1	\N	2026-05-01	\N	1	4	8	\N	4	0	\N	\N	2026-04-10 07:16:17.936696+00	2026-04-10 07:16:17.936696+00	2026-05-01	\N	\N	f	\N	1	f	\N	\N	1	\N	\N	\N	\N
35	3	2	Develop v2.0	\N	2026-05-07	\N	1	4	8	\N	4	0	\N	\N	2026-04-10 07:16:18.013667+00	2026-04-10 07:16:18.013667+00	2026-05-04	\N	\N	t	\N	4	f	\N	\N	1	\N	\N	\N	\N
36	2	2	Release v2.0	\N	2026-05-08	\N	1	4	8	\N	4	0	\N	\N	2026-04-10 07:16:18.10817+00	2026-04-10 07:16:18.10817+00	2026-05-08	\N	\N	f	\N	1	f	\N	\N	1	\N	\N	\N	\N
40	1	3	Create participant accounts	Prepare accounts for students.	2026-05-05	\N	1	7	7	\N	4	0	0	2	2026-04-10 07:33:00.022549+00	2026-04-10 07:33:00.022549+00	2026-05-05	\N	\N	t	37	1	f	\N	\N	1	\N	2	\N	\N
41	1	3	Prepare agenda	Draft workshop agenda and timings.	2026-05-06	\N	1	8	7	\N	4	0	0	3	2026-04-10 07:33:00.426725+00	2026-04-10 07:33:00.426725+00	2026-05-05	\N	\N	t	37	2	f	\N	\N	1	\N	3	\N	\N
37	1	3	Prepare workshop kickoff	Initial planning, goals, and setup.	2026-05-06	\N	1	5	7	\N	4	4	0	6	2026-04-10 07:32:59.024492+00	2026-04-10 07:33:00.484443+00	2026-05-05	\N	11	f	\N	2	f	11	0	1	\N	6	\N	\N
42	1	3	Write exercise 1	Basic work package exercise.	2026-05-11	\N	1	5	7	\N	4	0	0	4	2026-04-10 07:33:01.055121+00	2026-04-10 07:33:01.055121+00	2026-05-08	\N	\N	t	38	2	f	\N	\N	1	\N	4	\N	\N
43	1	3	Write exercise 2	Boards and timelines exercise.	2026-05-11	\N	1	6	7	\N	4	0	0	4	2026-04-10 07:33:01.683093+00	2026-04-10 07:33:01.683093+00	2026-05-11	\N	\N	t	38	1	f	\N	\N	1	\N	4	\N	\N
44	1	3	Create trainer notes	Facilitator guide and answers.	2026-05-11	\N	1	7	7	\N	4	0	0	3	2026-04-10 07:33:02.033242+00	2026-04-10 07:33:02.033242+00	2026-05-11	\N	\N	t	38	1	f	\N	\N	1	\N	3	\N	\N
38	1	3	Build demo backlog	Create user stories and supporting tasks.	2026-05-11	\N	1	6	7	\N	4	4	0	10	2026-04-10 07:32:59.364021+00	2026-04-10 07:33:02.066823+00	2026-05-08	\N	21	f	\N	2	f	21	0	1	\N	10	\N	\N
45	1	3	Collect feedback	Capture pilot retrospective notes.	2026-05-18	\N	1	8	7	\N	4	0	0	2	2026-04-10 07:33:02.377493+00	2026-04-10 07:33:02.377493+00	2026-05-18	\N	\N	t	39	1	f	\N	\N	1	\N	2	\N	\N
39	1	3	Run pilot session	Trial run with internal audience.	2026-05-18	\N	1	5	7	\N	4	2	0	8	2026-04-10 07:32:59.721858+00	2026-04-10 07:33:02.449545+00	2026-05-18	\N	10	f	\N	1	f	10	0	1	\N	8	\N	\N
\.


--
-- Data for Name: workflows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workflows (id, type_id, old_status_id, new_status_id, role_id, assignee, author) FROM stdin;
1	1	1	1	3	f	f
2	1	1	1	5	f	f
3	1	1	1	6	f	f
4	1	1	7	3	f	f
5	1	1	7	5	f	f
6	1	1	7	6	f	f
7	1	1	13	3	f	f
8	1	1	13	5	f	f
9	1	1	13	6	f	f
10	1	1	14	3	f	f
11	1	1	14	5	f	f
12	1	1	14	6	f	f
13	1	1	12	3	f	f
14	1	1	12	5	f	f
15	1	1	12	6	f	f
16	1	7	1	3	f	f
17	1	7	1	5	f	f
18	1	7	1	6	f	f
19	1	7	7	3	f	f
20	1	7	7	5	f	f
21	1	7	7	6	f	f
22	1	7	13	3	f	f
23	1	7	13	5	f	f
24	1	7	13	6	f	f
25	1	7	14	3	f	f
26	1	7	14	5	f	f
27	1	7	14	6	f	f
28	1	7	12	3	f	f
29	1	7	12	5	f	f
30	1	7	12	6	f	f
31	1	13	1	3	f	f
32	1	13	1	5	f	f
33	1	13	1	6	f	f
34	1	13	7	3	f	f
35	1	13	7	5	f	f
36	1	13	7	6	f	f
37	1	13	13	3	f	f
38	1	13	13	5	f	f
39	1	13	13	6	f	f
40	1	13	14	3	f	f
41	1	13	14	5	f	f
42	1	13	14	6	f	f
43	1	13	12	3	f	f
44	1	13	12	5	f	f
45	1	13	12	6	f	f
46	1	14	1	3	f	f
47	1	14	1	5	f	f
48	1	14	1	6	f	f
49	1	14	7	3	f	f
50	1	14	7	5	f	f
51	1	14	7	6	f	f
52	1	14	13	3	f	f
53	1	14	13	5	f	f
54	1	14	13	6	f	f
55	1	14	14	3	f	f
56	1	14	14	5	f	f
57	1	14	14	6	f	f
58	1	14	12	3	f	f
59	1	14	12	5	f	f
60	1	14	12	6	f	f
61	1	12	1	3	f	f
62	1	12	1	5	f	f
63	1	12	1	6	f	f
64	1	12	7	3	f	f
65	1	12	7	5	f	f
66	1	12	7	6	f	f
67	1	12	13	3	f	f
68	1	12	13	5	f	f
69	1	12	13	6	f	f
70	1	12	14	3	f	f
71	1	12	14	5	f	f
72	1	12	14	6	f	f
73	1	12	12	3	f	f
74	1	12	12	5	f	f
75	1	12	12	6	f	f
76	2	1	1	3	f	f
77	2	1	1	5	f	f
78	2	1	1	6	f	f
79	2	1	5	3	f	f
80	2	1	5	5	f	f
81	2	1	5	6	f	f
82	2	1	6	3	f	f
83	2	1	6	5	f	f
84	2	1	6	6	f	f
85	2	1	7	3	f	f
86	2	1	7	5	f	f
87	2	1	7	6	f	f
88	2	1	13	3	f	f
89	2	1	13	5	f	f
90	2	1	13	6	f	f
91	2	1	14	3	f	f
92	2	1	14	5	f	f
93	2	1	14	6	f	f
94	2	1	12	3	f	f
95	2	1	12	5	f	f
96	2	1	12	6	f	f
97	2	5	1	3	f	f
98	2	5	1	5	f	f
99	2	5	1	6	f	f
100	2	5	5	3	f	f
101	2	5	5	5	f	f
102	2	5	5	6	f	f
103	2	5	6	3	f	f
104	2	5	6	5	f	f
105	2	5	6	6	f	f
106	2	5	7	3	f	f
107	2	5	7	5	f	f
108	2	5	7	6	f	f
109	2	5	13	3	f	f
110	2	5	13	5	f	f
111	2	5	13	6	f	f
112	2	5	14	3	f	f
113	2	5	14	5	f	f
114	2	5	14	6	f	f
115	2	5	12	3	f	f
116	2	5	12	5	f	f
117	2	5	12	6	f	f
118	2	6	1	3	f	f
119	2	6	1	5	f	f
120	2	6	1	6	f	f
121	2	6	5	3	f	f
122	2	6	5	5	f	f
123	2	6	5	6	f	f
124	2	6	6	3	f	f
125	2	6	6	5	f	f
126	2	6	6	6	f	f
127	2	6	7	3	f	f
128	2	6	7	5	f	f
129	2	6	7	6	f	f
130	2	6	13	3	f	f
131	2	6	13	5	f	f
132	2	6	13	6	f	f
133	2	6	14	3	f	f
134	2	6	14	5	f	f
135	2	6	14	6	f	f
136	2	6	12	3	f	f
137	2	6	12	5	f	f
138	2	6	12	6	f	f
139	2	7	1	3	f	f
140	2	7	1	5	f	f
141	2	7	1	6	f	f
142	2	7	5	3	f	f
143	2	7	5	5	f	f
144	2	7	5	6	f	f
145	2	7	6	3	f	f
146	2	7	6	5	f	f
147	2	7	6	6	f	f
148	2	7	7	3	f	f
149	2	7	7	5	f	f
150	2	7	7	6	f	f
151	2	7	13	3	f	f
152	2	7	13	5	f	f
153	2	7	13	6	f	f
154	2	7	14	3	f	f
155	2	7	14	5	f	f
156	2	7	14	6	f	f
157	2	7	12	3	f	f
158	2	7	12	5	f	f
159	2	7	12	6	f	f
160	2	13	1	3	f	f
161	2	13	1	5	f	f
162	2	13	1	6	f	f
163	2	13	5	3	f	f
164	2	13	5	5	f	f
165	2	13	5	6	f	f
166	2	13	6	3	f	f
167	2	13	6	5	f	f
168	2	13	6	6	f	f
169	2	13	7	3	f	f
170	2	13	7	5	f	f
171	2	13	7	6	f	f
172	2	13	13	3	f	f
173	2	13	13	5	f	f
174	2	13	13	6	f	f
175	2	13	14	3	f	f
176	2	13	14	5	f	f
177	2	13	14	6	f	f
178	2	13	12	3	f	f
179	2	13	12	5	f	f
180	2	13	12	6	f	f
181	2	14	1	3	f	f
182	2	14	1	5	f	f
183	2	14	1	6	f	f
184	2	14	5	3	f	f
185	2	14	5	5	f	f
186	2	14	5	6	f	f
187	2	14	6	3	f	f
188	2	14	6	5	f	f
189	2	14	6	6	f	f
190	2	14	7	3	f	f
191	2	14	7	5	f	f
192	2	14	7	6	f	f
193	2	14	13	3	f	f
194	2	14	13	5	f	f
195	2	14	13	6	f	f
196	2	14	14	3	f	f
197	2	14	14	5	f	f
198	2	14	14	6	f	f
199	2	14	12	3	f	f
200	2	14	12	5	f	f
201	2	14	12	6	f	f
202	2	12	1	3	f	f
203	2	12	1	5	f	f
204	2	12	1	6	f	f
205	2	12	5	3	f	f
206	2	12	5	5	f	f
207	2	12	5	6	f	f
208	2	12	6	3	f	f
209	2	12	6	5	f	f
210	2	12	6	6	f	f
211	2	12	7	3	f	f
212	2	12	7	5	f	f
213	2	12	7	6	f	f
214	2	12	13	3	f	f
215	2	12	13	5	f	f
216	2	12	13	6	f	f
217	2	12	14	3	f	f
218	2	12	14	5	f	f
219	2	12	14	6	f	f
220	2	12	12	3	f	f
221	2	12	12	5	f	f
222	2	12	12	6	f	f
223	3	1	1	3	f	f
224	3	1	1	5	f	f
225	3	1	1	6	f	f
226	3	1	5	3	f	f
227	3	1	5	5	f	f
228	3	1	5	6	f	f
229	3	1	6	3	f	f
230	3	1	6	5	f	f
231	3	1	6	6	f	f
232	3	1	7	3	f	f
233	3	1	7	5	f	f
234	3	1	7	6	f	f
235	3	1	13	3	f	f
236	3	1	13	5	f	f
237	3	1	13	6	f	f
238	3	1	14	3	f	f
239	3	1	14	5	f	f
240	3	1	14	6	f	f
241	3	1	12	3	f	f
242	3	1	12	5	f	f
243	3	1	12	6	f	f
244	3	5	1	3	f	f
245	3	5	1	5	f	f
246	3	5	1	6	f	f
247	3	5	5	3	f	f
248	3	5	5	5	f	f
249	3	5	5	6	f	f
250	3	5	6	3	f	f
251	3	5	6	5	f	f
252	3	5	6	6	f	f
253	3	5	7	3	f	f
254	3	5	7	5	f	f
255	3	5	7	6	f	f
256	3	5	13	3	f	f
257	3	5	13	5	f	f
258	3	5	13	6	f	f
259	3	5	14	3	f	f
260	3	5	14	5	f	f
261	3	5	14	6	f	f
262	3	5	12	3	f	f
263	3	5	12	5	f	f
264	3	5	12	6	f	f
265	3	6	1	3	f	f
266	3	6	1	5	f	f
267	3	6	1	6	f	f
268	3	6	5	3	f	f
269	3	6	5	5	f	f
270	3	6	5	6	f	f
271	3	6	6	3	f	f
272	3	6	6	5	f	f
273	3	6	6	6	f	f
274	3	6	7	3	f	f
275	3	6	7	5	f	f
276	3	6	7	6	f	f
277	3	6	13	3	f	f
278	3	6	13	5	f	f
279	3	6	13	6	f	f
280	3	6	14	3	f	f
281	3	6	14	5	f	f
282	3	6	14	6	f	f
283	3	6	12	3	f	f
284	3	6	12	5	f	f
285	3	6	12	6	f	f
286	3	7	1	3	f	f
287	3	7	1	5	f	f
288	3	7	1	6	f	f
289	3	7	5	3	f	f
290	3	7	5	5	f	f
291	3	7	5	6	f	f
292	3	7	6	3	f	f
293	3	7	6	5	f	f
294	3	7	6	6	f	f
295	3	7	7	3	f	f
296	3	7	7	5	f	f
297	3	7	7	6	f	f
298	3	7	13	3	f	f
299	3	7	13	5	f	f
300	3	7	13	6	f	f
301	3	7	14	3	f	f
302	3	7	14	5	f	f
303	3	7	14	6	f	f
304	3	7	12	3	f	f
305	3	7	12	5	f	f
306	3	7	12	6	f	f
307	3	13	1	3	f	f
308	3	13	1	5	f	f
309	3	13	1	6	f	f
310	3	13	5	3	f	f
311	3	13	5	5	f	f
312	3	13	5	6	f	f
313	3	13	6	3	f	f
314	3	13	6	5	f	f
315	3	13	6	6	f	f
316	3	13	7	3	f	f
317	3	13	7	5	f	f
318	3	13	7	6	f	f
319	3	13	13	3	f	f
320	3	13	13	5	f	f
321	3	13	13	6	f	f
322	3	13	14	3	f	f
323	3	13	14	5	f	f
324	3	13	14	6	f	f
325	3	13	12	3	f	f
326	3	13	12	5	f	f
327	3	13	12	6	f	f
328	3	14	1	3	f	f
329	3	14	1	5	f	f
330	3	14	1	6	f	f
331	3	14	5	3	f	f
332	3	14	5	5	f	f
333	3	14	5	6	f	f
334	3	14	6	3	f	f
335	3	14	6	5	f	f
336	3	14	6	6	f	f
337	3	14	7	3	f	f
338	3	14	7	5	f	f
339	3	14	7	6	f	f
340	3	14	13	3	f	f
341	3	14	13	5	f	f
342	3	14	13	6	f	f
343	3	14	14	3	f	f
344	3	14	14	5	f	f
345	3	14	14	6	f	f
346	3	14	12	3	f	f
347	3	14	12	5	f	f
348	3	14	12	6	f	f
349	3	12	1	3	f	f
350	3	12	1	5	f	f
351	3	12	1	6	f	f
352	3	12	5	3	f	f
353	3	12	5	5	f	f
354	3	12	5	6	f	f
355	3	12	6	3	f	f
356	3	12	6	5	f	f
357	3	12	6	6	f	f
358	3	12	7	3	f	f
359	3	12	7	5	f	f
360	3	12	7	6	f	f
361	3	12	13	3	f	f
362	3	12	13	5	f	f
363	3	12	13	6	f	f
364	3	12	14	3	f	f
365	3	12	14	5	f	f
366	3	12	14	6	f	f
367	3	12	12	3	f	f
368	3	12	12	5	f	f
369	3	12	12	6	f	f
370	4	1	1	3	f	f
371	4	1	1	5	f	f
372	4	1	1	6	f	f
373	4	1	2	3	f	f
374	4	1	2	5	f	f
375	4	1	2	6	f	f
376	4	1	3	3	f	f
377	4	1	3	5	f	f
378	4	1	3	6	f	f
379	4	1	7	3	f	f
380	4	1	7	5	f	f
381	4	1	7	6	f	f
382	4	1	8	3	f	f
383	4	1	8	5	f	f
384	4	1	8	6	f	f
385	4	1	9	3	f	f
386	4	1	9	5	f	f
387	4	1	9	6	f	f
388	4	1	10	3	f	f
389	4	1	10	5	f	f
390	4	1	10	6	f	f
391	4	1	11	3	f	f
392	4	1	11	5	f	f
393	4	1	11	6	f	f
394	4	1	13	3	f	f
395	4	1	13	5	f	f
396	4	1	13	6	f	f
397	4	1	14	3	f	f
398	4	1	14	5	f	f
399	4	1	14	6	f	f
400	4	1	12	3	f	f
401	4	1	12	5	f	f
402	4	1	12	6	f	f
403	4	2	1	3	f	f
404	4	2	1	5	f	f
405	4	2	1	6	f	f
406	4	2	2	3	f	f
407	4	2	2	5	f	f
408	4	2	2	6	f	f
409	4	2	3	3	f	f
410	4	2	3	5	f	f
411	4	2	3	6	f	f
412	4	2	7	3	f	f
413	4	2	7	5	f	f
414	4	2	7	6	f	f
415	4	2	8	3	f	f
416	4	2	8	5	f	f
417	4	2	8	6	f	f
418	4	2	9	3	f	f
419	4	2	9	5	f	f
420	4	2	9	6	f	f
421	4	2	10	3	f	f
422	4	2	10	5	f	f
423	4	2	10	6	f	f
424	4	2	11	3	f	f
425	4	2	11	5	f	f
426	4	2	11	6	f	f
427	4	2	13	3	f	f
428	4	2	13	5	f	f
429	4	2	13	6	f	f
430	4	2	14	3	f	f
431	4	2	14	5	f	f
432	4	2	14	6	f	f
433	4	2	12	3	f	f
434	4	2	12	5	f	f
435	4	2	12	6	f	f
436	4	3	1	3	f	f
437	4	3	1	5	f	f
438	4	3	1	6	f	f
439	4	3	2	3	f	f
440	4	3	2	5	f	f
441	4	3	2	6	f	f
442	4	3	3	3	f	f
443	4	3	3	5	f	f
444	4	3	3	6	f	f
445	4	3	7	3	f	f
446	4	3	7	5	f	f
447	4	3	7	6	f	f
448	4	3	8	3	f	f
449	4	3	8	5	f	f
450	4	3	8	6	f	f
451	4	3	9	3	f	f
452	4	3	9	5	f	f
453	4	3	9	6	f	f
454	4	3	10	3	f	f
455	4	3	10	5	f	f
456	4	3	10	6	f	f
457	4	3	11	3	f	f
458	4	3	11	5	f	f
459	4	3	11	6	f	f
460	4	3	13	3	f	f
461	4	3	13	5	f	f
462	4	3	13	6	f	f
463	4	3	14	3	f	f
464	4	3	14	5	f	f
465	4	3	14	6	f	f
466	4	3	12	3	f	f
467	4	3	12	5	f	f
468	4	3	12	6	f	f
469	4	7	1	3	f	f
470	4	7	1	5	f	f
471	4	7	1	6	f	f
472	4	7	2	3	f	f
473	4	7	2	5	f	f
474	4	7	2	6	f	f
475	4	7	3	3	f	f
476	4	7	3	5	f	f
477	4	7	3	6	f	f
478	4	7	7	3	f	f
479	4	7	7	5	f	f
480	4	7	7	6	f	f
481	4	7	8	3	f	f
482	4	7	8	5	f	f
483	4	7	8	6	f	f
484	4	7	9	3	f	f
485	4	7	9	5	f	f
486	4	7	9	6	f	f
487	4	7	10	3	f	f
488	4	7	10	5	f	f
489	4	7	10	6	f	f
490	4	7	11	3	f	f
491	4	7	11	5	f	f
492	4	7	11	6	f	f
493	4	7	13	3	f	f
494	4	7	13	5	f	f
495	4	7	13	6	f	f
496	4	7	14	3	f	f
497	4	7	14	5	f	f
498	4	7	14	6	f	f
499	4	7	12	3	f	f
500	4	7	12	5	f	f
501	4	7	12	6	f	f
502	4	8	1	3	f	f
503	4	8	1	5	f	f
504	4	8	1	6	f	f
505	4	8	2	3	f	f
506	4	8	2	5	f	f
507	4	8	2	6	f	f
508	4	8	3	3	f	f
509	4	8	3	5	f	f
510	4	8	3	6	f	f
511	4	8	7	3	f	f
512	4	8	7	5	f	f
513	4	8	7	6	f	f
514	4	8	8	3	f	f
515	4	8	8	5	f	f
516	4	8	8	6	f	f
517	4	8	9	3	f	f
518	4	8	9	5	f	f
519	4	8	9	6	f	f
520	4	8	10	3	f	f
521	4	8	10	5	f	f
522	4	8	10	6	f	f
523	4	8	11	3	f	f
524	4	8	11	5	f	f
525	4	8	11	6	f	f
526	4	8	13	3	f	f
527	4	8	13	5	f	f
528	4	8	13	6	f	f
529	4	8	14	3	f	f
530	4	8	14	5	f	f
531	4	8	14	6	f	f
532	4	8	12	3	f	f
533	4	8	12	5	f	f
534	4	8	12	6	f	f
535	4	9	1	3	f	f
536	4	9	1	5	f	f
537	4	9	1	6	f	f
538	4	9	2	3	f	f
539	4	9	2	5	f	f
540	4	9	2	6	f	f
541	4	9	3	3	f	f
542	4	9	3	5	f	f
543	4	9	3	6	f	f
544	4	9	7	3	f	f
545	4	9	7	5	f	f
546	4	9	7	6	f	f
547	4	9	8	3	f	f
548	4	9	8	5	f	f
549	4	9	8	6	f	f
550	4	9	9	3	f	f
551	4	9	9	5	f	f
552	4	9	9	6	f	f
553	4	9	10	3	f	f
554	4	9	10	5	f	f
555	4	9	10	6	f	f
556	4	9	11	3	f	f
557	4	9	11	5	f	f
558	4	9	11	6	f	f
559	4	9	13	3	f	f
560	4	9	13	5	f	f
561	4	9	13	6	f	f
562	4	9	14	3	f	f
563	4	9	14	5	f	f
564	4	9	14	6	f	f
565	4	9	12	3	f	f
566	4	9	12	5	f	f
567	4	9	12	6	f	f
568	4	10	1	3	f	f
569	4	10	1	5	f	f
570	4	10	1	6	f	f
571	4	10	2	3	f	f
572	4	10	2	5	f	f
573	4	10	2	6	f	f
574	4	10	3	3	f	f
575	4	10	3	5	f	f
576	4	10	3	6	f	f
577	4	10	7	3	f	f
578	4	10	7	5	f	f
579	4	10	7	6	f	f
580	4	10	8	3	f	f
581	4	10	8	5	f	f
582	4	10	8	6	f	f
583	4	10	9	3	f	f
584	4	10	9	5	f	f
585	4	10	9	6	f	f
586	4	10	10	3	f	f
587	4	10	10	5	f	f
588	4	10	10	6	f	f
589	4	10	11	3	f	f
590	4	10	11	5	f	f
591	4	10	11	6	f	f
592	4	10	13	3	f	f
593	4	10	13	5	f	f
594	4	10	13	6	f	f
595	4	10	14	3	f	f
596	4	10	14	5	f	f
597	4	10	14	6	f	f
598	4	10	12	3	f	f
599	4	10	12	5	f	f
600	4	10	12	6	f	f
601	4	11	1	3	f	f
602	4	11	1	5	f	f
603	4	11	1	6	f	f
604	4	11	2	3	f	f
605	4	11	2	5	f	f
606	4	11	2	6	f	f
607	4	11	3	3	f	f
608	4	11	3	5	f	f
609	4	11	3	6	f	f
610	4	11	7	3	f	f
611	4	11	7	5	f	f
612	4	11	7	6	f	f
613	4	11	8	3	f	f
614	4	11	8	5	f	f
615	4	11	8	6	f	f
616	4	11	9	3	f	f
617	4	11	9	5	f	f
618	4	11	9	6	f	f
619	4	11	10	3	f	f
620	4	11	10	5	f	f
621	4	11	10	6	f	f
622	4	11	11	3	f	f
623	4	11	11	5	f	f
624	4	11	11	6	f	f
625	4	11	13	3	f	f
626	4	11	13	5	f	f
627	4	11	13	6	f	f
628	4	11	14	3	f	f
629	4	11	14	5	f	f
630	4	11	14	6	f	f
631	4	11	12	3	f	f
632	4	11	12	5	f	f
633	4	11	12	6	f	f
634	4	13	1	3	f	f
635	4	13	1	5	f	f
636	4	13	1	6	f	f
637	4	13	2	3	f	f
638	4	13	2	5	f	f
639	4	13	2	6	f	f
640	4	13	3	3	f	f
641	4	13	3	5	f	f
642	4	13	3	6	f	f
643	4	13	7	3	f	f
644	4	13	7	5	f	f
645	4	13	7	6	f	f
646	4	13	8	3	f	f
647	4	13	8	5	f	f
648	4	13	8	6	f	f
649	4	13	9	3	f	f
650	4	13	9	5	f	f
651	4	13	9	6	f	f
652	4	13	10	3	f	f
653	4	13	10	5	f	f
654	4	13	10	6	f	f
655	4	13	11	3	f	f
656	4	13	11	5	f	f
657	4	13	11	6	f	f
658	4	13	13	3	f	f
659	4	13	13	5	f	f
660	4	13	13	6	f	f
661	4	13	14	3	f	f
662	4	13	14	5	f	f
663	4	13	14	6	f	f
664	4	13	12	3	f	f
665	4	13	12	5	f	f
666	4	13	12	6	f	f
667	4	14	1	3	f	f
668	4	14	1	5	f	f
669	4	14	1	6	f	f
670	4	14	2	3	f	f
671	4	14	2	5	f	f
672	4	14	2	6	f	f
673	4	14	3	3	f	f
674	4	14	3	5	f	f
675	4	14	3	6	f	f
676	4	14	7	3	f	f
677	4	14	7	5	f	f
678	4	14	7	6	f	f
679	4	14	8	3	f	f
680	4	14	8	5	f	f
681	4	14	8	6	f	f
682	4	14	9	3	f	f
683	4	14	9	5	f	f
684	4	14	9	6	f	f
685	4	14	10	3	f	f
686	4	14	10	5	f	f
687	4	14	10	6	f	f
688	4	14	11	3	f	f
689	4	14	11	5	f	f
690	4	14	11	6	f	f
691	4	14	13	3	f	f
692	4	14	13	5	f	f
693	4	14	13	6	f	f
694	4	14	14	3	f	f
695	4	14	14	5	f	f
696	4	14	14	6	f	f
697	4	14	12	3	f	f
698	4	14	12	5	f	f
699	4	14	12	6	f	f
700	4	12	1	3	f	f
701	4	12	1	5	f	f
702	4	12	1	6	f	f
703	4	12	2	3	f	f
704	4	12	2	5	f	f
705	4	12	2	6	f	f
706	4	12	3	3	f	f
707	4	12	3	5	f	f
708	4	12	3	6	f	f
709	4	12	7	3	f	f
710	4	12	7	5	f	f
711	4	12	7	6	f	f
712	4	12	8	3	f	f
713	4	12	8	5	f	f
714	4	12	8	6	f	f
715	4	12	9	3	f	f
716	4	12	9	5	f	f
717	4	12	9	6	f	f
718	4	12	10	3	f	f
719	4	12	10	5	f	f
720	4	12	10	6	f	f
721	4	12	11	3	f	f
722	4	12	11	5	f	f
723	4	12	11	6	f	f
724	4	12	13	3	f	f
725	4	12	13	5	f	f
726	4	12	13	6	f	f
727	4	12	14	3	f	f
728	4	12	14	5	f	f
729	4	12	14	6	f	f
730	4	12	12	3	f	f
731	4	12	12	5	f	f
732	4	12	12	6	f	f
733	5	1	1	3	f	f
734	5	1	1	5	f	f
735	5	1	1	6	f	f
736	5	1	2	3	f	f
737	5	1	2	5	f	f
738	5	1	2	6	f	f
739	5	1	3	3	f	f
740	5	1	3	5	f	f
741	5	1	3	6	f	f
742	5	1	7	3	f	f
743	5	1	7	5	f	f
744	5	1	7	6	f	f
745	5	1	8	3	f	f
746	5	1	8	5	f	f
747	5	1	8	6	f	f
748	5	1	9	3	f	f
749	5	1	9	5	f	f
750	5	1	9	6	f	f
751	5	1	10	3	f	f
752	5	1	10	5	f	f
753	5	1	10	6	f	f
754	5	1	11	3	f	f
755	5	1	11	5	f	f
756	5	1	11	6	f	f
757	5	1	13	3	f	f
758	5	1	13	5	f	f
759	5	1	13	6	f	f
760	5	1	14	3	f	f
761	5	1	14	5	f	f
762	5	1	14	6	f	f
763	5	1	12	3	f	f
764	5	1	12	5	f	f
765	5	1	12	6	f	f
766	5	2	1	3	f	f
767	5	2	1	5	f	f
768	5	2	1	6	f	f
769	5	2	2	3	f	f
770	5	2	2	5	f	f
771	5	2	2	6	f	f
772	5	2	3	3	f	f
773	5	2	3	5	f	f
774	5	2	3	6	f	f
775	5	2	7	3	f	f
776	5	2	7	5	f	f
777	5	2	7	6	f	f
778	5	2	8	3	f	f
779	5	2	8	5	f	f
780	5	2	8	6	f	f
781	5	2	9	3	f	f
782	5	2	9	5	f	f
783	5	2	9	6	f	f
784	5	2	10	3	f	f
785	5	2	10	5	f	f
786	5	2	10	6	f	f
787	5	2	11	3	f	f
788	5	2	11	5	f	f
789	5	2	11	6	f	f
790	5	2	13	3	f	f
791	5	2	13	5	f	f
792	5	2	13	6	f	f
793	5	2	14	3	f	f
794	5	2	14	5	f	f
795	5	2	14	6	f	f
796	5	2	12	3	f	f
797	5	2	12	5	f	f
798	5	2	12	6	f	f
799	5	3	1	3	f	f
800	5	3	1	5	f	f
801	5	3	1	6	f	f
802	5	3	2	3	f	f
803	5	3	2	5	f	f
804	5	3	2	6	f	f
805	5	3	3	3	f	f
806	5	3	3	5	f	f
807	5	3	3	6	f	f
808	5	3	7	3	f	f
809	5	3	7	5	f	f
810	5	3	7	6	f	f
811	5	3	8	3	f	f
812	5	3	8	5	f	f
813	5	3	8	6	f	f
814	5	3	9	3	f	f
815	5	3	9	5	f	f
816	5	3	9	6	f	f
817	5	3	10	3	f	f
818	5	3	10	5	f	f
819	5	3	10	6	f	f
820	5	3	11	3	f	f
821	5	3	11	5	f	f
822	5	3	11	6	f	f
823	5	3	13	3	f	f
824	5	3	13	5	f	f
825	5	3	13	6	f	f
826	5	3	14	3	f	f
827	5	3	14	5	f	f
828	5	3	14	6	f	f
829	5	3	12	3	f	f
830	5	3	12	5	f	f
831	5	3	12	6	f	f
832	5	7	1	3	f	f
833	5	7	1	5	f	f
834	5	7	1	6	f	f
835	5	7	2	3	f	f
836	5	7	2	5	f	f
837	5	7	2	6	f	f
838	5	7	3	3	f	f
839	5	7	3	5	f	f
840	5	7	3	6	f	f
841	5	7	7	3	f	f
842	5	7	7	5	f	f
843	5	7	7	6	f	f
844	5	7	8	3	f	f
845	5	7	8	5	f	f
846	5	7	8	6	f	f
847	5	7	9	3	f	f
848	5	7	9	5	f	f
849	5	7	9	6	f	f
850	5	7	10	3	f	f
851	5	7	10	5	f	f
852	5	7	10	6	f	f
853	5	7	11	3	f	f
854	5	7	11	5	f	f
855	5	7	11	6	f	f
856	5	7	13	3	f	f
857	5	7	13	5	f	f
858	5	7	13	6	f	f
859	5	7	14	3	f	f
860	5	7	14	5	f	f
861	5	7	14	6	f	f
862	5	7	12	3	f	f
863	5	7	12	5	f	f
864	5	7	12	6	f	f
865	5	8	1	3	f	f
866	5	8	1	5	f	f
867	5	8	1	6	f	f
868	5	8	2	3	f	f
869	5	8	2	5	f	f
870	5	8	2	6	f	f
871	5	8	3	3	f	f
872	5	8	3	5	f	f
873	5	8	3	6	f	f
874	5	8	7	3	f	f
875	5	8	7	5	f	f
876	5	8	7	6	f	f
877	5	8	8	3	f	f
878	5	8	8	5	f	f
879	5	8	8	6	f	f
880	5	8	9	3	f	f
881	5	8	9	5	f	f
882	5	8	9	6	f	f
883	5	8	10	3	f	f
884	5	8	10	5	f	f
885	5	8	10	6	f	f
886	5	8	11	3	f	f
887	5	8	11	5	f	f
888	5	8	11	6	f	f
889	5	8	13	3	f	f
890	5	8	13	5	f	f
891	5	8	13	6	f	f
892	5	8	14	3	f	f
893	5	8	14	5	f	f
894	5	8	14	6	f	f
895	5	8	12	3	f	f
896	5	8	12	5	f	f
897	5	8	12	6	f	f
898	5	9	1	3	f	f
899	5	9	1	5	f	f
900	5	9	1	6	f	f
901	5	9	2	3	f	f
902	5	9	2	5	f	f
903	5	9	2	6	f	f
904	5	9	3	3	f	f
905	5	9	3	5	f	f
906	5	9	3	6	f	f
907	5	9	7	3	f	f
908	5	9	7	5	f	f
909	5	9	7	6	f	f
910	5	9	8	3	f	f
911	5	9	8	5	f	f
912	5	9	8	6	f	f
913	5	9	9	3	f	f
914	5	9	9	5	f	f
915	5	9	9	6	f	f
916	5	9	10	3	f	f
917	5	9	10	5	f	f
918	5	9	10	6	f	f
919	5	9	11	3	f	f
920	5	9	11	5	f	f
921	5	9	11	6	f	f
922	5	9	13	3	f	f
923	5	9	13	5	f	f
924	5	9	13	6	f	f
925	5	9	14	3	f	f
926	5	9	14	5	f	f
927	5	9	14	6	f	f
928	5	9	12	3	f	f
929	5	9	12	5	f	f
930	5	9	12	6	f	f
931	5	10	1	3	f	f
932	5	10	1	5	f	f
933	5	10	1	6	f	f
934	5	10	2	3	f	f
935	5	10	2	5	f	f
936	5	10	2	6	f	f
937	5	10	3	3	f	f
938	5	10	3	5	f	f
939	5	10	3	6	f	f
940	5	10	7	3	f	f
941	5	10	7	5	f	f
942	5	10	7	6	f	f
943	5	10	8	3	f	f
944	5	10	8	5	f	f
945	5	10	8	6	f	f
946	5	10	9	3	f	f
947	5	10	9	5	f	f
948	5	10	9	6	f	f
949	5	10	10	3	f	f
950	5	10	10	5	f	f
951	5	10	10	6	f	f
952	5	10	11	3	f	f
953	5	10	11	5	f	f
954	5	10	11	6	f	f
955	5	10	13	3	f	f
956	5	10	13	5	f	f
957	5	10	13	6	f	f
958	5	10	14	3	f	f
959	5	10	14	5	f	f
960	5	10	14	6	f	f
961	5	10	12	3	f	f
962	5	10	12	5	f	f
963	5	10	12	6	f	f
964	5	11	1	3	f	f
965	5	11	1	5	f	f
966	5	11	1	6	f	f
967	5	11	2	3	f	f
968	5	11	2	5	f	f
969	5	11	2	6	f	f
970	5	11	3	3	f	f
971	5	11	3	5	f	f
972	5	11	3	6	f	f
973	5	11	7	3	f	f
974	5	11	7	5	f	f
975	5	11	7	6	f	f
976	5	11	8	3	f	f
977	5	11	8	5	f	f
978	5	11	8	6	f	f
979	5	11	9	3	f	f
980	5	11	9	5	f	f
981	5	11	9	6	f	f
982	5	11	10	3	f	f
983	5	11	10	5	f	f
984	5	11	10	6	f	f
985	5	11	11	3	f	f
986	5	11	11	5	f	f
987	5	11	11	6	f	f
988	5	11	13	3	f	f
989	5	11	13	5	f	f
990	5	11	13	6	f	f
991	5	11	14	3	f	f
992	5	11	14	5	f	f
993	5	11	14	6	f	f
994	5	11	12	3	f	f
995	5	11	12	5	f	f
996	5	11	12	6	f	f
997	5	13	1	3	f	f
998	5	13	1	5	f	f
999	5	13	1	6	f	f
1000	5	13	2	3	f	f
1001	5	13	2	5	f	f
1002	5	13	2	6	f	f
1003	5	13	3	3	f	f
1004	5	13	3	5	f	f
1005	5	13	3	6	f	f
1006	5	13	7	3	f	f
1007	5	13	7	5	f	f
1008	5	13	7	6	f	f
1009	5	13	8	3	f	f
1010	5	13	8	5	f	f
1011	5	13	8	6	f	f
1012	5	13	9	3	f	f
1013	5	13	9	5	f	f
1014	5	13	9	6	f	f
1015	5	13	10	3	f	f
1016	5	13	10	5	f	f
1017	5	13	10	6	f	f
1018	5	13	11	3	f	f
1019	5	13	11	5	f	f
1020	5	13	11	6	f	f
1021	5	13	13	3	f	f
1022	5	13	13	5	f	f
1023	5	13	13	6	f	f
1024	5	13	14	3	f	f
1025	5	13	14	5	f	f
1026	5	13	14	6	f	f
1027	5	13	12	3	f	f
1028	5	13	12	5	f	f
1029	5	13	12	6	f	f
1030	5	14	1	3	f	f
1031	5	14	1	5	f	f
1032	5	14	1	6	f	f
1033	5	14	2	3	f	f
1034	5	14	2	5	f	f
1035	5	14	2	6	f	f
1036	5	14	3	3	f	f
1037	5	14	3	5	f	f
1038	5	14	3	6	f	f
1039	5	14	7	3	f	f
1040	5	14	7	5	f	f
1041	5	14	7	6	f	f
1042	5	14	8	3	f	f
1043	5	14	8	5	f	f
1044	5	14	8	6	f	f
1045	5	14	9	3	f	f
1046	5	14	9	5	f	f
1047	5	14	9	6	f	f
1048	5	14	10	3	f	f
1049	5	14	10	5	f	f
1050	5	14	10	6	f	f
1051	5	14	11	3	f	f
1052	5	14	11	5	f	f
1053	5	14	11	6	f	f
1054	5	14	13	3	f	f
1055	5	14	13	5	f	f
1056	5	14	13	6	f	f
1057	5	14	14	3	f	f
1058	5	14	14	5	f	f
1059	5	14	14	6	f	f
1060	5	14	12	3	f	f
1061	5	14	12	5	f	f
1062	5	14	12	6	f	f
1063	5	12	1	3	f	f
1064	5	12	1	5	f	f
1065	5	12	1	6	f	f
1066	5	12	2	3	f	f
1067	5	12	2	5	f	f
1068	5	12	2	6	f	f
1069	5	12	3	3	f	f
1070	5	12	3	5	f	f
1071	5	12	3	6	f	f
1072	5	12	7	3	f	f
1073	5	12	7	5	f	f
1074	5	12	7	6	f	f
1075	5	12	8	3	f	f
1076	5	12	8	5	f	f
1077	5	12	8	6	f	f
1078	5	12	9	3	f	f
1079	5	12	9	5	f	f
1080	5	12	9	6	f	f
1081	5	12	10	3	f	f
1082	5	12	10	5	f	f
1083	5	12	10	6	f	f
1084	5	12	11	3	f	f
1085	5	12	11	5	f	f
1086	5	12	11	6	f	f
1087	5	12	13	3	f	f
1088	5	12	13	5	f	f
1089	5	12	13	6	f	f
1090	5	12	14	3	f	f
1091	5	12	14	5	f	f
1092	5	12	14	6	f	f
1093	5	12	12	3	f	f
1094	5	12	12	5	f	f
1095	5	12	12	6	f	f
1096	6	1	1	3	f	f
1097	6	1	1	5	f	f
1098	6	1	1	6	f	f
1099	6	1	2	3	f	f
1100	6	1	2	5	f	f
1101	6	1	2	6	f	f
1102	6	1	3	3	f	f
1103	6	1	3	5	f	f
1104	6	1	3	6	f	f
1105	6	1	7	3	f	f
1106	6	1	7	5	f	f
1107	6	1	7	6	f	f
1108	6	1	8	3	f	f
1109	6	1	8	5	f	f
1110	6	1	8	6	f	f
1111	6	1	9	3	f	f
1112	6	1	9	5	f	f
1113	6	1	9	6	f	f
1114	6	1	10	3	f	f
1115	6	1	10	5	f	f
1116	6	1	10	6	f	f
1117	6	1	11	3	f	f
1118	6	1	11	5	f	f
1119	6	1	11	6	f	f
1120	6	1	13	3	f	f
1121	6	1	13	5	f	f
1122	6	1	13	6	f	f
1123	6	1	14	3	f	f
1124	6	1	14	5	f	f
1125	6	1	14	6	f	f
1126	6	1	12	3	f	f
1127	6	1	12	5	f	f
1128	6	1	12	6	f	f
1129	6	2	1	3	f	f
1130	6	2	1	5	f	f
1131	6	2	1	6	f	f
1132	6	2	2	3	f	f
1133	6	2	2	5	f	f
1134	6	2	2	6	f	f
1135	6	2	3	3	f	f
1136	6	2	3	5	f	f
1137	6	2	3	6	f	f
1138	6	2	7	3	f	f
1139	6	2	7	5	f	f
1140	6	2	7	6	f	f
1141	6	2	8	3	f	f
1142	6	2	8	5	f	f
1143	6	2	8	6	f	f
1144	6	2	9	3	f	f
1145	6	2	9	5	f	f
1146	6	2	9	6	f	f
1147	6	2	10	3	f	f
1148	6	2	10	5	f	f
1149	6	2	10	6	f	f
1150	6	2	11	3	f	f
1151	6	2	11	5	f	f
1152	6	2	11	6	f	f
1153	6	2	13	3	f	f
1154	6	2	13	5	f	f
1155	6	2	13	6	f	f
1156	6	2	14	3	f	f
1157	6	2	14	5	f	f
1158	6	2	14	6	f	f
1159	6	2	12	3	f	f
1160	6	2	12	5	f	f
1161	6	2	12	6	f	f
1162	6	3	1	3	f	f
1163	6	3	1	5	f	f
1164	6	3	1	6	f	f
1165	6	3	2	3	f	f
1166	6	3	2	5	f	f
1167	6	3	2	6	f	f
1168	6	3	3	3	f	f
1169	6	3	3	5	f	f
1170	6	3	3	6	f	f
1171	6	3	7	3	f	f
1172	6	3	7	5	f	f
1173	6	3	7	6	f	f
1174	6	3	8	3	f	f
1175	6	3	8	5	f	f
1176	6	3	8	6	f	f
1177	6	3	9	3	f	f
1178	6	3	9	5	f	f
1179	6	3	9	6	f	f
1180	6	3	10	3	f	f
1181	6	3	10	5	f	f
1182	6	3	10	6	f	f
1183	6	3	11	3	f	f
1184	6	3	11	5	f	f
1185	6	3	11	6	f	f
1186	6	3	13	3	f	f
1187	6	3	13	5	f	f
1188	6	3	13	6	f	f
1189	6	3	14	3	f	f
1190	6	3	14	5	f	f
1191	6	3	14	6	f	f
1192	6	3	12	3	f	f
1193	6	3	12	5	f	f
1194	6	3	12	6	f	f
1195	6	7	1	3	f	f
1196	6	7	1	5	f	f
1197	6	7	1	6	f	f
1198	6	7	2	3	f	f
1199	6	7	2	5	f	f
1200	6	7	2	6	f	f
1201	6	7	3	3	f	f
1202	6	7	3	5	f	f
1203	6	7	3	6	f	f
1204	6	7	7	3	f	f
1205	6	7	7	5	f	f
1206	6	7	7	6	f	f
1207	6	7	8	3	f	f
1208	6	7	8	5	f	f
1209	6	7	8	6	f	f
1210	6	7	9	3	f	f
1211	6	7	9	5	f	f
1212	6	7	9	6	f	f
1213	6	7	10	3	f	f
1214	6	7	10	5	f	f
1215	6	7	10	6	f	f
1216	6	7	11	3	f	f
1217	6	7	11	5	f	f
1218	6	7	11	6	f	f
1219	6	7	13	3	f	f
1220	6	7	13	5	f	f
1221	6	7	13	6	f	f
1222	6	7	14	3	f	f
1223	6	7	14	5	f	f
1224	6	7	14	6	f	f
1225	6	7	12	3	f	f
1226	6	7	12	5	f	f
1227	6	7	12	6	f	f
1228	6	8	1	3	f	f
1229	6	8	1	5	f	f
1230	6	8	1	6	f	f
1231	6	8	2	3	f	f
1232	6	8	2	5	f	f
1233	6	8	2	6	f	f
1234	6	8	3	3	f	f
1235	6	8	3	5	f	f
1236	6	8	3	6	f	f
1237	6	8	7	3	f	f
1238	6	8	7	5	f	f
1239	6	8	7	6	f	f
1240	6	8	8	3	f	f
1241	6	8	8	5	f	f
1242	6	8	8	6	f	f
1243	6	8	9	3	f	f
1244	6	8	9	5	f	f
1245	6	8	9	6	f	f
1246	6	8	10	3	f	f
1247	6	8	10	5	f	f
1248	6	8	10	6	f	f
1249	6	8	11	3	f	f
1250	6	8	11	5	f	f
1251	6	8	11	6	f	f
1252	6	8	13	3	f	f
1253	6	8	13	5	f	f
1254	6	8	13	6	f	f
1255	6	8	14	3	f	f
1256	6	8	14	5	f	f
1257	6	8	14	6	f	f
1258	6	8	12	3	f	f
1259	6	8	12	5	f	f
1260	6	8	12	6	f	f
1261	6	9	1	3	f	f
1262	6	9	1	5	f	f
1263	6	9	1	6	f	f
1264	6	9	2	3	f	f
1265	6	9	2	5	f	f
1266	6	9	2	6	f	f
1267	6	9	3	3	f	f
1268	6	9	3	5	f	f
1269	6	9	3	6	f	f
1270	6	9	7	3	f	f
1271	6	9	7	5	f	f
1272	6	9	7	6	f	f
1273	6	9	8	3	f	f
1274	6	9	8	5	f	f
1275	6	9	8	6	f	f
1276	6	9	9	3	f	f
1277	6	9	9	5	f	f
1278	6	9	9	6	f	f
1279	6	9	10	3	f	f
1280	6	9	10	5	f	f
1281	6	9	10	6	f	f
1282	6	9	11	3	f	f
1283	6	9	11	5	f	f
1284	6	9	11	6	f	f
1285	6	9	13	3	f	f
1286	6	9	13	5	f	f
1287	6	9	13	6	f	f
1288	6	9	14	3	f	f
1289	6	9	14	5	f	f
1290	6	9	14	6	f	f
1291	6	9	12	3	f	f
1292	6	9	12	5	f	f
1293	6	9	12	6	f	f
1294	6	10	1	3	f	f
1295	6	10	1	5	f	f
1296	6	10	1	6	f	f
1297	6	10	2	3	f	f
1298	6	10	2	5	f	f
1299	6	10	2	6	f	f
1300	6	10	3	3	f	f
1301	6	10	3	5	f	f
1302	6	10	3	6	f	f
1303	6	10	7	3	f	f
1304	6	10	7	5	f	f
1305	6	10	7	6	f	f
1306	6	10	8	3	f	f
1307	6	10	8	5	f	f
1308	6	10	8	6	f	f
1309	6	10	9	3	f	f
1310	6	10	9	5	f	f
1311	6	10	9	6	f	f
1312	6	10	10	3	f	f
1313	6	10	10	5	f	f
1314	6	10	10	6	f	f
1315	6	10	11	3	f	f
1316	6	10	11	5	f	f
1317	6	10	11	6	f	f
1318	6	10	13	3	f	f
1319	6	10	13	5	f	f
1320	6	10	13	6	f	f
1321	6	10	14	3	f	f
1322	6	10	14	5	f	f
1323	6	10	14	6	f	f
1324	6	10	12	3	f	f
1325	6	10	12	5	f	f
1326	6	10	12	6	f	f
1327	6	11	1	3	f	f
1328	6	11	1	5	f	f
1329	6	11	1	6	f	f
1330	6	11	2	3	f	f
1331	6	11	2	5	f	f
1332	6	11	2	6	f	f
1333	6	11	3	3	f	f
1334	6	11	3	5	f	f
1335	6	11	3	6	f	f
1336	6	11	7	3	f	f
1337	6	11	7	5	f	f
1338	6	11	7	6	f	f
1339	6	11	8	3	f	f
1340	6	11	8	5	f	f
1341	6	11	8	6	f	f
1342	6	11	9	3	f	f
1343	6	11	9	5	f	f
1344	6	11	9	6	f	f
1345	6	11	10	3	f	f
1346	6	11	10	5	f	f
1347	6	11	10	6	f	f
1348	6	11	11	3	f	f
1349	6	11	11	5	f	f
1350	6	11	11	6	f	f
1351	6	11	13	3	f	f
1352	6	11	13	5	f	f
1353	6	11	13	6	f	f
1354	6	11	14	3	f	f
1355	6	11	14	5	f	f
1356	6	11	14	6	f	f
1357	6	11	12	3	f	f
1358	6	11	12	5	f	f
1359	6	11	12	6	f	f
1360	6	13	1	3	f	f
1361	6	13	1	5	f	f
1362	6	13	1	6	f	f
1363	6	13	2	3	f	f
1364	6	13	2	5	f	f
1365	6	13	2	6	f	f
1366	6	13	3	3	f	f
1367	6	13	3	5	f	f
1368	6	13	3	6	f	f
1369	6	13	7	3	f	f
1370	6	13	7	5	f	f
1371	6	13	7	6	f	f
1372	6	13	8	3	f	f
1373	6	13	8	5	f	f
1374	6	13	8	6	f	f
1375	6	13	9	3	f	f
1376	6	13	9	5	f	f
1377	6	13	9	6	f	f
1378	6	13	10	3	f	f
1379	6	13	10	5	f	f
1380	6	13	10	6	f	f
1381	6	13	11	3	f	f
1382	6	13	11	5	f	f
1383	6	13	11	6	f	f
1384	6	13	13	3	f	f
1385	6	13	13	5	f	f
1386	6	13	13	6	f	f
1387	6	13	14	3	f	f
1388	6	13	14	5	f	f
1389	6	13	14	6	f	f
1390	6	13	12	3	f	f
1391	6	13	12	5	f	f
1392	6	13	12	6	f	f
1393	6	14	1	3	f	f
1394	6	14	1	5	f	f
1395	6	14	1	6	f	f
1396	6	14	2	3	f	f
1397	6	14	2	5	f	f
1398	6	14	2	6	f	f
1399	6	14	3	3	f	f
1400	6	14	3	5	f	f
1401	6	14	3	6	f	f
1402	6	14	7	3	f	f
1403	6	14	7	5	f	f
1404	6	14	7	6	f	f
1405	6	14	8	3	f	f
1406	6	14	8	5	f	f
1407	6	14	8	6	f	f
1408	6	14	9	3	f	f
1409	6	14	9	5	f	f
1410	6	14	9	6	f	f
1411	6	14	10	3	f	f
1412	6	14	10	5	f	f
1413	6	14	10	6	f	f
1414	6	14	11	3	f	f
1415	6	14	11	5	f	f
1416	6	14	11	6	f	f
1417	6	14	13	3	f	f
1418	6	14	13	5	f	f
1419	6	14	13	6	f	f
1420	6	14	14	3	f	f
1421	6	14	14	5	f	f
1422	6	14	14	6	f	f
1423	6	14	12	3	f	f
1424	6	14	12	5	f	f
1425	6	14	12	6	f	f
1426	6	12	1	3	f	f
1427	6	12	1	5	f	f
1428	6	12	1	6	f	f
1429	6	12	2	3	f	f
1430	6	12	2	5	f	f
1431	6	12	2	6	f	f
1432	6	12	3	3	f	f
1433	6	12	3	5	f	f
1434	6	12	3	6	f	f
1435	6	12	7	3	f	f
1436	6	12	7	5	f	f
1437	6	12	7	6	f	f
1438	6	12	8	3	f	f
1439	6	12	8	5	f	f
1440	6	12	8	6	f	f
1441	6	12	9	3	f	f
1442	6	12	9	5	f	f
1443	6	12	9	6	f	f
1444	6	12	10	3	f	f
1445	6	12	10	5	f	f
1446	6	12	10	6	f	f
1447	6	12	11	3	f	f
1448	6	12	11	5	f	f
1449	6	12	11	6	f	f
1450	6	12	13	3	f	f
1451	6	12	13	5	f	f
1452	6	12	13	6	f	f
1453	6	12	14	3	f	f
1454	6	12	14	5	f	f
1455	6	12	14	6	f	f
1456	6	12	12	3	f	f
1457	6	12	12	5	f	f
1458	6	12	12	6	f	f
1459	7	1	1	3	f	f
1460	7	1	1	5	f	f
1461	7	1	1	6	f	f
1462	7	1	4	3	f	f
1463	7	1	4	5	f	f
1464	7	1	4	6	f	f
1465	7	1	7	3	f	f
1466	7	1	7	5	f	f
1467	7	1	7	6	f	f
1468	7	1	8	3	f	f
1469	7	1	8	5	f	f
1470	7	1	8	6	f	f
1471	7	1	9	3	f	f
1472	7	1	9	5	f	f
1473	7	1	9	6	f	f
1474	7	1	10	3	f	f
1475	7	1	10	5	f	f
1476	7	1	10	6	f	f
1477	7	1	11	3	f	f
1478	7	1	11	5	f	f
1479	7	1	11	6	f	f
1480	7	1	13	3	f	f
1481	7	1	13	5	f	f
1482	7	1	13	6	f	f
1483	7	1	14	3	f	f
1484	7	1	14	5	f	f
1485	7	1	14	6	f	f
1486	7	1	12	3	f	f
1487	7	1	12	5	f	f
1488	7	1	12	6	f	f
1489	7	4	1	3	f	f
1490	7	4	1	5	f	f
1491	7	4	1	6	f	f
1492	7	4	4	3	f	f
1493	7	4	4	5	f	f
1494	7	4	4	6	f	f
1495	7	4	7	3	f	f
1496	7	4	7	5	f	f
1497	7	4	7	6	f	f
1498	7	4	8	3	f	f
1499	7	4	8	5	f	f
1500	7	4	8	6	f	f
1501	7	4	9	3	f	f
1502	7	4	9	5	f	f
1503	7	4	9	6	f	f
1504	7	4	10	3	f	f
1505	7	4	10	5	f	f
1506	7	4	10	6	f	f
1507	7	4	11	3	f	f
1508	7	4	11	5	f	f
1509	7	4	11	6	f	f
1510	7	4	13	3	f	f
1511	7	4	13	5	f	f
1512	7	4	13	6	f	f
1513	7	4	14	3	f	f
1514	7	4	14	5	f	f
1515	7	4	14	6	f	f
1516	7	4	12	3	f	f
1517	7	4	12	5	f	f
1518	7	4	12	6	f	f
1519	7	7	1	3	f	f
1520	7	7	1	5	f	f
1521	7	7	1	6	f	f
1522	7	7	4	3	f	f
1523	7	7	4	5	f	f
1524	7	7	4	6	f	f
1525	7	7	7	3	f	f
1526	7	7	7	5	f	f
1527	7	7	7	6	f	f
1528	7	7	8	3	f	f
1529	7	7	8	5	f	f
1530	7	7	8	6	f	f
1531	7	7	9	3	f	f
1532	7	7	9	5	f	f
1533	7	7	9	6	f	f
1534	7	7	10	3	f	f
1535	7	7	10	5	f	f
1536	7	7	10	6	f	f
1537	7	7	11	3	f	f
1538	7	7	11	5	f	f
1539	7	7	11	6	f	f
1540	7	7	13	3	f	f
1541	7	7	13	5	f	f
1542	7	7	13	6	f	f
1543	7	7	14	3	f	f
1544	7	7	14	5	f	f
1545	7	7	14	6	f	f
1546	7	7	12	3	f	f
1547	7	7	12	5	f	f
1548	7	7	12	6	f	f
1549	7	8	1	3	f	f
1550	7	8	1	5	f	f
1551	7	8	1	6	f	f
1552	7	8	4	3	f	f
1553	7	8	4	5	f	f
1554	7	8	4	6	f	f
1555	7	8	7	3	f	f
1556	7	8	7	5	f	f
1557	7	8	7	6	f	f
1558	7	8	8	3	f	f
1559	7	8	8	5	f	f
1560	7	8	8	6	f	f
1561	7	8	9	3	f	f
1562	7	8	9	5	f	f
1563	7	8	9	6	f	f
1564	7	8	10	3	f	f
1565	7	8	10	5	f	f
1566	7	8	10	6	f	f
1567	7	8	11	3	f	f
1568	7	8	11	5	f	f
1569	7	8	11	6	f	f
1570	7	8	13	3	f	f
1571	7	8	13	5	f	f
1572	7	8	13	6	f	f
1573	7	8	14	3	f	f
1574	7	8	14	5	f	f
1575	7	8	14	6	f	f
1576	7	8	12	3	f	f
1577	7	8	12	5	f	f
1578	7	8	12	6	f	f
1579	7	9	1	3	f	f
1580	7	9	1	5	f	f
1581	7	9	1	6	f	f
1582	7	9	4	3	f	f
1583	7	9	4	5	f	f
1584	7	9	4	6	f	f
1585	7	9	7	3	f	f
1586	7	9	7	5	f	f
1587	7	9	7	6	f	f
1588	7	9	8	3	f	f
1589	7	9	8	5	f	f
1590	7	9	8	6	f	f
1591	7	9	9	3	f	f
1592	7	9	9	5	f	f
1593	7	9	9	6	f	f
1594	7	9	10	3	f	f
1595	7	9	10	5	f	f
1596	7	9	10	6	f	f
1597	7	9	11	3	f	f
1598	7	9	11	5	f	f
1599	7	9	11	6	f	f
1600	7	9	13	3	f	f
1601	7	9	13	5	f	f
1602	7	9	13	6	f	f
1603	7	9	14	3	f	f
1604	7	9	14	5	f	f
1605	7	9	14	6	f	f
1606	7	9	12	3	f	f
1607	7	9	12	5	f	f
1608	7	9	12	6	f	f
1609	7	10	1	3	f	f
1610	7	10	1	5	f	f
1611	7	10	1	6	f	f
1612	7	10	4	3	f	f
1613	7	10	4	5	f	f
1614	7	10	4	6	f	f
1615	7	10	7	3	f	f
1616	7	10	7	5	f	f
1617	7	10	7	6	f	f
1618	7	10	8	3	f	f
1619	7	10	8	5	f	f
1620	7	10	8	6	f	f
1621	7	10	9	3	f	f
1622	7	10	9	5	f	f
1623	7	10	9	6	f	f
1624	7	10	10	3	f	f
1625	7	10	10	5	f	f
1626	7	10	10	6	f	f
1627	7	10	11	3	f	f
1628	7	10	11	5	f	f
1629	7	10	11	6	f	f
1630	7	10	13	3	f	f
1631	7	10	13	5	f	f
1632	7	10	13	6	f	f
1633	7	10	14	3	f	f
1634	7	10	14	5	f	f
1635	7	10	14	6	f	f
1636	7	10	12	3	f	f
1637	7	10	12	5	f	f
1638	7	10	12	6	f	f
1639	7	11	1	3	f	f
1640	7	11	1	5	f	f
1641	7	11	1	6	f	f
1642	7	11	4	3	f	f
1643	7	11	4	5	f	f
1644	7	11	4	6	f	f
1645	7	11	7	3	f	f
1646	7	11	7	5	f	f
1647	7	11	7	6	f	f
1648	7	11	8	3	f	f
1649	7	11	8	5	f	f
1650	7	11	8	6	f	f
1651	7	11	9	3	f	f
1652	7	11	9	5	f	f
1653	7	11	9	6	f	f
1654	7	11	10	3	f	f
1655	7	11	10	5	f	f
1656	7	11	10	6	f	f
1657	7	11	11	3	f	f
1658	7	11	11	5	f	f
1659	7	11	11	6	f	f
1660	7	11	13	3	f	f
1661	7	11	13	5	f	f
1662	7	11	13	6	f	f
1663	7	11	14	3	f	f
1664	7	11	14	5	f	f
1665	7	11	14	6	f	f
1666	7	11	12	3	f	f
1667	7	11	12	5	f	f
1668	7	11	12	6	f	f
1669	7	13	1	3	f	f
1670	7	13	1	5	f	f
1671	7	13	1	6	f	f
1672	7	13	4	3	f	f
1673	7	13	4	5	f	f
1674	7	13	4	6	f	f
1675	7	13	7	3	f	f
1676	7	13	7	5	f	f
1677	7	13	7	6	f	f
1678	7	13	8	3	f	f
1679	7	13	8	5	f	f
1680	7	13	8	6	f	f
1681	7	13	9	3	f	f
1682	7	13	9	5	f	f
1683	7	13	9	6	f	f
1684	7	13	10	3	f	f
1685	7	13	10	5	f	f
1686	7	13	10	6	f	f
1687	7	13	11	3	f	f
1688	7	13	11	5	f	f
1689	7	13	11	6	f	f
1690	7	13	13	3	f	f
1691	7	13	13	5	f	f
1692	7	13	13	6	f	f
1693	7	13	14	3	f	f
1694	7	13	14	5	f	f
1695	7	13	14	6	f	f
1696	7	13	12	3	f	f
1697	7	13	12	5	f	f
1698	7	13	12	6	f	f
1699	7	14	1	3	f	f
1700	7	14	1	5	f	f
1701	7	14	1	6	f	f
1702	7	14	4	3	f	f
1703	7	14	4	5	f	f
1704	7	14	4	6	f	f
1705	7	14	7	3	f	f
1706	7	14	7	5	f	f
1707	7	14	7	6	f	f
1708	7	14	8	3	f	f
1709	7	14	8	5	f	f
1710	7	14	8	6	f	f
1711	7	14	9	3	f	f
1712	7	14	9	5	f	f
1713	7	14	9	6	f	f
1714	7	14	10	3	f	f
1715	7	14	10	5	f	f
1716	7	14	10	6	f	f
1717	7	14	11	3	f	f
1718	7	14	11	5	f	f
1719	7	14	11	6	f	f
1720	7	14	13	3	f	f
1721	7	14	13	5	f	f
1722	7	14	13	6	f	f
1723	7	14	14	3	f	f
1724	7	14	14	5	f	f
1725	7	14	14	6	f	f
1726	7	14	12	3	f	f
1727	7	14	12	5	f	f
1728	7	14	12	6	f	f
1729	7	12	1	3	f	f
1730	7	12	1	5	f	f
1731	7	12	1	6	f	f
1732	7	12	4	3	f	f
1733	7	12	4	5	f	f
1734	7	12	4	6	f	f
1735	7	12	7	3	f	f
1736	7	12	7	5	f	f
1737	7	12	7	6	f	f
1738	7	12	8	3	f	f
1739	7	12	8	5	f	f
1740	7	12	8	6	f	f
1741	7	12	9	3	f	f
1742	7	12	9	5	f	f
1743	7	12	9	6	f	f
1744	7	12	10	3	f	f
1745	7	12	10	5	f	f
1746	7	12	10	6	f	f
1747	7	12	11	3	f	f
1748	7	12	11	5	f	f
1749	7	12	11	6	f	f
1750	7	12	13	3	f	f
1751	7	12	13	5	f	f
1752	7	12	13	6	f	f
1753	7	12	14	3	f	f
1754	7	12	14	5	f	f
1755	7	12	14	6	f	f
1756	7	12	12	3	f	f
1757	7	12	12	5	f	f
1758	7	12	12	6	f	f
\.


--
-- Name: announcements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.announcements_id_seq', 1, false);


--
-- Name: attachable_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attachable_journals_id_seq', 1, false);


--
-- Name: attachment_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attachment_journals_id_seq', 2, true);


--
-- Name: attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attachments_id_seq', 2, true);


--
-- Name: attribute_help_texts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.attribute_help_texts_id_seq', 1, false);


--
-- Name: auth_providers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_providers_id_seq', 1, false);


--
-- Name: autologin_session_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.autologin_session_links_id_seq', 1, false);


--
-- Name: bcf_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bcf_comments_id_seq', 1, false);


--
-- Name: bcf_issues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bcf_issues_id_seq', 1, false);


--
-- Name: bcf_viewpoints_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.bcf_viewpoints_id_seq', 1, false);


--
-- Name: budget_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.budget_journals_id_seq', 1, false);


--
-- Name: budgets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.budgets_id_seq', 1, false);


--
-- Name: calculated_value_errors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.calculated_value_errors_id_seq', 1, false);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.categories_id_seq', 2, true);


--
-- Name: changes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.changes_id_seq', 1, false);


--
-- Name: changeset_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.changeset_journals_id_seq', 1, false);


--
-- Name: changesets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.changesets_id_seq', 1, false);


--
-- Name: colors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.colors_id_seq', 148, true);


--
-- Name: comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.comments_id_seq', 1, false);


--
-- Name: cost_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cost_entries_id_seq', 1, false);


--
-- Name: cost_queries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cost_queries_id_seq', 1, false);


--
-- Name: cost_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cost_types_id_seq', 1, false);


--
-- Name: custom_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_actions_id_seq', 1, false);


--
-- Name: custom_actions_projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_actions_projects_id_seq', 1, false);


--
-- Name: custom_actions_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_actions_roles_id_seq', 1, false);


--
-- Name: custom_actions_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_actions_statuses_id_seq', 1, false);


--
-- Name: custom_actions_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_actions_types_id_seq', 1, false);


--
-- Name: custom_field_sections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_field_sections_id_seq', 1, true);


--
-- Name: custom_fields_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_fields_id_seq', 1, false);


--
-- Name: custom_fields_projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_fields_projects_id_seq', 1, false);


--
-- Name: custom_fields_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_fields_roles_id_seq', 1, false);


--
-- Name: custom_options_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_options_id_seq', 1, false);


--
-- Name: custom_styles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_styles_id_seq', 1, false);


--
-- Name: custom_values_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.custom_values_id_seq', 1, false);


--
-- Name: customizable_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.customizable_journals_id_seq', 1, false);


--
-- Name: deploy_status_checks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.deploy_status_checks_id_seq', 1, false);


--
-- Name: deploy_targets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.deploy_targets_id_seq', 1, false);


--
-- Name: design_colors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.design_colors_id_seq', 1, false);


--
-- Name: document_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_journals_id_seq', 1, false);


--
-- Name: document_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_types_id_seq', 6, true);


--
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.documents_id_seq', 1, false);


--
-- Name: emoji_reactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.emoji_reactions_id_seq', 1, false);


--
-- Name: enabled_modules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.enabled_modules_id_seq', 26, true);


--
-- Name: enterprise_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.enterprise_tokens_id_seq', 1, false);


--
-- Name: enumerations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.enumerations_id_seq', 10, true);


--
-- Name: export_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.export_settings_id_seq', 1, false);


--
-- Name: exports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.exports_id_seq', 1, false);


--
-- Name: favorites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.favorites_id_seq', 1, false);


--
-- Name: file_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.file_links_id_seq', 1, false);


--
-- Name: forums_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.forums_id_seq', 1, false);


--
-- Name: github_check_runs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.github_check_runs_id_seq', 1, false);


--
-- Name: github_pull_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.github_pull_requests_id_seq', 1, false);


--
-- Name: github_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.github_users_id_seq', 1, false);


--
-- Name: gitlab_issues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gitlab_issues_id_seq', 1, false);


--
-- Name: gitlab_merge_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gitlab_merge_requests_id_seq', 1, false);


--
-- Name: gitlab_pipelines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gitlab_pipelines_id_seq', 1, false);


--
-- Name: gitlab_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gitlab_users_id_seq', 1, false);


--
-- Name: grid_widgets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.grid_widgets_id_seq', 32, true);


--
-- Name: grids_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.grids_id_seq', 7, true);


--
-- Name: group_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.group_users_id_seq', 4, true);


--
-- Name: hierarchical_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hierarchical_items_id_seq', 1, false);


--
-- Name: ical_token_query_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ical_token_query_assignments_id_seq', 1, false);


--
-- Name: ifc_models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ifc_models_id_seq', 1, false);


--
-- Name: job_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.job_statuses_id_seq', 1, false);


--
-- Name: journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.journals_id_seq', 64, true);


--
-- Name: labor_budget_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.labor_budget_items_id_seq', 1, false);


--
-- Name: last_project_folders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.last_project_folders_id_seq', 1, false);


--
-- Name: ldap_auth_sources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ldap_auth_sources_id_seq', 1, false);


--
-- Name: ldap_groups_memberships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ldap_groups_memberships_id_seq', 1, false);


--
-- Name: ldap_groups_synchronized_filters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ldap_groups_synchronized_filters_id_seq', 1, false);


--
-- Name: ldap_groups_synchronized_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ldap_groups_synchronized_groups_id_seq', 1, false);


--
-- Name: material_budget_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.material_budget_items_id_seq', 1, false);


--
-- Name: mcp_configurations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.mcp_configurations_id_seq', 19, true);


--
-- Name: meeting_agenda_item_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.meeting_agenda_item_journals_id_seq', 1, false);


--
-- Name: meeting_agenda_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.meeting_agenda_items_id_seq', 45, true);


--
-- Name: meeting_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.meeting_journals_id_seq', 5, true);


--
-- Name: meeting_outcomes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.meeting_outcomes_id_seq', 1, false);


--
-- Name: meeting_participants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.meeting_participants_id_seq', 5, true);


--
-- Name: meeting_sections_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.meeting_sections_id_seq', 10, true);


--
-- Name: meetings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.meetings_id_seq', 5, true);


--
-- Name: member_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_roles_id_seq', 8, true);


--
-- Name: members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.members_id_seq', 8, true);


--
-- Name: menu_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.menu_items_id_seq', 3, true);


--
-- Name: message_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.message_journals_id_seq', 1, false);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.messages_id_seq', 1, false);


--
-- Name: news_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.news_id_seq', 2, true);


--
-- Name: news_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.news_journals_id_seq', 2, true);


--
-- Name: non_working_days_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.non_working_days_id_seq', 1, false);


--
-- Name: notification_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notification_settings_id_seq', 5, true);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.notifications_id_seq', 13, true);


--
-- Name: oauth_access_grants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oauth_access_grants_id_seq', 1, false);


--
-- Name: oauth_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oauth_access_tokens_id_seq', 1, false);


--
-- Name: oauth_applications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oauth_applications_id_seq', 1, true);


--
-- Name: oauth_client_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oauth_client_tokens_id_seq', 1, false);


--
-- Name: oauth_clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oauth_clients_id_seq', 1, false);


--
-- Name: oidc_group_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oidc_group_links_id_seq', 1, false);


--
-- Name: oidc_group_memberships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oidc_group_memberships_id_seq', 1, false);


--
-- Name: oidc_user_session_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oidc_user_session_links_id_seq', 1, false);


--
-- Name: oidc_user_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.oidc_user_tokens_id_seq', 1, false);


--
-- Name: ordered_work_packages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.ordered_work_packages_id_seq', 10, true);


--
-- Name: paper_trail_audits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.paper_trail_audits_id_seq', 1, false);


--
-- Name: project_custom_field_project_mappings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_custom_field_project_mappings_id_seq', 1, false);


--
-- Name: project_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_journals_id_seq', 4, true);


--
-- Name: project_phase_definitions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_phase_definitions_id_seq', 4, true);


--
-- Name: project_phase_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_phase_journals_id_seq', 4, true);


--
-- Name: project_phases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_phases_id_seq', 4, true);


--
-- Name: project_queries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_queries_id_seq', 1, false);


--
-- Name: project_storages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_storages_id_seq', 1, false);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.projects_id_seq', 3, true);


--
-- Name: queries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.queries_id_seq', 26, true);


--
-- Name: rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rates_id_seq', 1, false);


--
-- Name: recaptcha_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.recaptcha_entries_id_seq', 1, false);


--
-- Name: recurring_meeting_interim_responses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.recurring_meeting_interim_responses_id_seq', 1, false);


--
-- Name: recurring_meetings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.recurring_meetings_id_seq', 1, true);


--
-- Name: relations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.relations_id_seq', 7, true);


--
-- Name: reminder_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reminder_notifications_id_seq', 1, false);


--
-- Name: reminders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reminders_id_seq', 1, false);


--
-- Name: remote_identities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.remote_identities_id_seq', 1, false);


--
-- Name: repositories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.repositories_id_seq', 1, false);


--
-- Name: role_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.role_permissions_id_seq', 325, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_id_seq', 12, true);


--
-- Name: scheduled_meetings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.scheduled_meetings_id_seq', 4, true);


--
-- Name: scim_clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.scim_clients_id_seq', 1, false);


--
-- Name: service_account_associations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.service_account_associations_id_seq', 1, false);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sessions_id_seq', 12, true);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.settings_id_seq', 180, true);


--
-- Name: statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.statuses_id_seq', 14, true);


--
-- Name: storages_file_links_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.storages_file_links_journals_id_seq', 1, false);


--
-- Name: storages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.storages_id_seq', 1, false);


--
-- Name: subproject_template_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.subproject_template_assignments_id_seq', 1, false);


--
-- Name: time_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.time_entries_id_seq', 1, false);


--
-- Name: time_entry_activities_projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.time_entry_activities_projects_id_seq', 1, false);


--
-- Name: time_entry_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.time_entry_journals_id_seq', 1, false);


--
-- Name: tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tokens_id_seq', 2, true);


--
-- Name: two_factor_authentication_devices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.two_factor_authentication_devices_id_seq', 1, false);


--
-- Name: types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.types_id_seq', 7, true);


--
-- Name: user_auth_provider_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_auth_provider_links_id_seq', 1, false);


--
-- Name: user_passwords_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_passwords_id_seq', 6, true);


--
-- Name: user_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.user_preferences_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 9, true);


--
-- Name: version_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.version_settings_id_seq', 4, true);


--
-- Name: versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.versions_id_seq', 4, true);


--
-- Name: views_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.views_id_seq', 8, true);


--
-- Name: watchers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.watchers_id_seq', 16, true);


--
-- Name: webhooks_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.webhooks_events_id_seq', 1, false);


--
-- Name: webhooks_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.webhooks_logs_id_seq', 1, false);


--
-- Name: webhooks_projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.webhooks_projects_id_seq', 1, false);


--
-- Name: webhooks_webhooks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.webhooks_webhooks_id_seq', 1, false);


--
-- Name: wiki_page_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wiki_page_journals_id_seq', 3, true);


--
-- Name: wiki_pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wiki_pages_id_seq', 3, true);


--
-- Name: wiki_redirects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wiki_redirects_id_seq', 1, false);


--
-- Name: wikis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.wikis_id_seq', 3, true);


--
-- Name: work_package_journals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.work_package_journals_id_seq', 69, true);


--
-- Name: work_packages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.work_packages_id_seq', 45, true);


--
-- Name: workflows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.workflows_id_seq', 1758, true);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: attachable_journals attachable_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachable_journals
    ADD CONSTRAINT attachable_journals_pkey PRIMARY KEY (id);


--
-- Name: attachment_journals attachment_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachment_journals
    ADD CONSTRAINT attachment_journals_pkey PRIMARY KEY (id);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: attribute_help_texts attribute_help_texts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attribute_help_texts
    ADD CONSTRAINT attribute_help_texts_pkey PRIMARY KEY (id);


--
-- Name: auth_providers auth_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_providers
    ADD CONSTRAINT auth_providers_pkey PRIMARY KEY (id);


--
-- Name: autologin_session_links autologin_session_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.autologin_session_links
    ADD CONSTRAINT autologin_session_links_pkey PRIMARY KEY (id);


--
-- Name: bcf_comments bcf_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_comments
    ADD CONSTRAINT bcf_comments_pkey PRIMARY KEY (id);


--
-- Name: bcf_issues bcf_issues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_issues
    ADD CONSTRAINT bcf_issues_pkey PRIMARY KEY (id);


--
-- Name: bcf_viewpoints bcf_viewpoints_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_viewpoints
    ADD CONSTRAINT bcf_viewpoints_pkey PRIMARY KEY (id);


--
-- Name: budget_journals budget_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budget_journals
    ADD CONSTRAINT budget_journals_pkey PRIMARY KEY (id);


--
-- Name: budgets budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.budgets
    ADD CONSTRAINT budgets_pkey PRIMARY KEY (id);


--
-- Name: calculated_value_errors calculated_value_errors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calculated_value_errors
    ADD CONSTRAINT calculated_value_errors_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: changes changes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changes
    ADD CONSTRAINT changes_pkey PRIMARY KEY (id);


--
-- Name: changeset_journals changeset_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changeset_journals
    ADD CONSTRAINT changeset_journals_pkey PRIMARY KEY (id);


--
-- Name: changesets changesets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.changesets
    ADD CONSTRAINT changesets_pkey PRIMARY KEY (id);


--
-- Name: colors colors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.colors
    ADD CONSTRAINT colors_pkey PRIMARY KEY (id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: cost_entries cost_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_entries
    ADD CONSTRAINT cost_entries_pkey PRIMARY KEY (id);


--
-- Name: cost_queries cost_queries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_queries
    ADD CONSTRAINT cost_queries_pkey PRIMARY KEY (id);


--
-- Name: cost_types cost_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_types
    ADD CONSTRAINT cost_types_pkey PRIMARY KEY (id);


--
-- Name: custom_actions custom_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions
    ADD CONSTRAINT custom_actions_pkey PRIMARY KEY (id);


--
-- Name: custom_actions_projects custom_actions_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_projects
    ADD CONSTRAINT custom_actions_projects_pkey PRIMARY KEY (id);


--
-- Name: custom_actions_roles custom_actions_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_roles
    ADD CONSTRAINT custom_actions_roles_pkey PRIMARY KEY (id);


--
-- Name: custom_actions_statuses custom_actions_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_statuses
    ADD CONSTRAINT custom_actions_statuses_pkey PRIMARY KEY (id);


--
-- Name: custom_actions_types custom_actions_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_actions_types
    ADD CONSTRAINT custom_actions_types_pkey PRIMARY KEY (id);


--
-- Name: custom_field_sections custom_field_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_field_sections
    ADD CONSTRAINT custom_field_sections_pkey PRIMARY KEY (id);


--
-- Name: custom_fields custom_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_fields
    ADD CONSTRAINT custom_fields_pkey PRIMARY KEY (id);


--
-- Name: custom_fields_projects custom_fields_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_fields_projects
    ADD CONSTRAINT custom_fields_projects_pkey PRIMARY KEY (id);


--
-- Name: custom_fields_roles custom_fields_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_fields_roles
    ADD CONSTRAINT custom_fields_roles_pkey PRIMARY KEY (id);


--
-- Name: custom_options custom_options_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_options
    ADD CONSTRAINT custom_options_pkey PRIMARY KEY (id);


--
-- Name: custom_styles custom_styles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_styles
    ADD CONSTRAINT custom_styles_pkey PRIMARY KEY (id);


--
-- Name: custom_values custom_values_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_values
    ADD CONSTRAINT custom_values_pkey PRIMARY KEY (id);


--
-- Name: customizable_journals customizable_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customizable_journals
    ADD CONSTRAINT customizable_journals_pkey PRIMARY KEY (id);


--
-- Name: deploy_status_checks deploy_status_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deploy_status_checks
    ADD CONSTRAINT deploy_status_checks_pkey PRIMARY KEY (id);


--
-- Name: deploy_targets deploy_targets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deploy_targets
    ADD CONSTRAINT deploy_targets_pkey PRIMARY KEY (id);


--
-- Name: design_colors design_colors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.design_colors
    ADD CONSTRAINT design_colors_pkey PRIMARY KEY (id);


--
-- Name: document_journals document_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_journals
    ADD CONSTRAINT document_journals_pkey PRIMARY KEY (id);


--
-- Name: document_types document_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_types
    ADD CONSTRAINT document_types_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: emoji_reactions emoji_reactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.emoji_reactions
    ADD CONSTRAINT emoji_reactions_pkey PRIMARY KEY (id);


--
-- Name: enabled_modules enabled_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enabled_modules
    ADD CONSTRAINT enabled_modules_pkey PRIMARY KEY (id);


--
-- Name: enterprise_tokens enterprise_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enterprise_tokens
    ADD CONSTRAINT enterprise_tokens_pkey PRIMARY KEY (id);


--
-- Name: enumerations enumerations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.enumerations
    ADD CONSTRAINT enumerations_pkey PRIMARY KEY (id);


--
-- Name: export_settings export_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.export_settings
    ADD CONSTRAINT export_settings_pkey PRIMARY KEY (id);


--
-- Name: exports exports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exports
    ADD CONSTRAINT exports_pkey PRIMARY KEY (id);


--
-- Name: favorites favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT favorites_pkey PRIMARY KEY (id);


--
-- Name: file_links file_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_links
    ADD CONSTRAINT file_links_pkey PRIMARY KEY (id);


--
-- Name: forums forums_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.forums
    ADD CONSTRAINT forums_pkey PRIMARY KEY (id);


--
-- Name: github_check_runs github_check_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_check_runs
    ADD CONSTRAINT github_check_runs_pkey PRIMARY KEY (id);


--
-- Name: github_pull_requests github_pull_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_pull_requests
    ADD CONSTRAINT github_pull_requests_pkey PRIMARY KEY (id);


--
-- Name: github_users github_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.github_users
    ADD CONSTRAINT github_users_pkey PRIMARY KEY (id);


--
-- Name: gitlab_issues gitlab_issues_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gitlab_issues
    ADD CONSTRAINT gitlab_issues_pkey PRIMARY KEY (id);


--
-- Name: gitlab_merge_requests gitlab_merge_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gitlab_merge_requests
    ADD CONSTRAINT gitlab_merge_requests_pkey PRIMARY KEY (id);


--
-- Name: gitlab_pipelines gitlab_pipelines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gitlab_pipelines
    ADD CONSTRAINT gitlab_pipelines_pkey PRIMARY KEY (id);


--
-- Name: gitlab_users gitlab_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gitlab_users
    ADD CONSTRAINT gitlab_users_pkey PRIMARY KEY (id);


--
-- Name: good_job_batches good_job_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.good_job_batches
    ADD CONSTRAINT good_job_batches_pkey PRIMARY KEY (id);


--
-- Name: good_job_executions good_job_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.good_job_executions
    ADD CONSTRAINT good_job_executions_pkey PRIMARY KEY (id);


--
-- Name: good_job_processes good_job_processes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.good_job_processes
    ADD CONSTRAINT good_job_processes_pkey PRIMARY KEY (id);


--
-- Name: good_job_settings good_job_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.good_job_settings
    ADD CONSTRAINT good_job_settings_pkey PRIMARY KEY (id);


--
-- Name: good_jobs good_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.good_jobs
    ADD CONSTRAINT good_jobs_pkey PRIMARY KEY (id);


--
-- Name: grid_widgets grid_widgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grid_widgets
    ADD CONSTRAINT grid_widgets_pkey PRIMARY KEY (id);


--
-- Name: grids grids_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.grids
    ADD CONSTRAINT grids_pkey PRIMARY KEY (id);


--
-- Name: group_users group_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_users
    ADD CONSTRAINT group_users_pkey PRIMARY KEY (id);


--
-- Name: hierarchical_items hierarchical_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hierarchical_items
    ADD CONSTRAINT hierarchical_items_pkey PRIMARY KEY (id);


--
-- Name: ical_token_query_assignments ical_token_query_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ical_token_query_assignments
    ADD CONSTRAINT ical_token_query_assignments_pkey PRIMARY KEY (id);


--
-- Name: ifc_models ifc_models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ifc_models
    ADD CONSTRAINT ifc_models_pkey PRIMARY KEY (id);


--
-- Name: job_statuses job_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.job_statuses
    ADD CONSTRAINT job_statuses_pkey PRIMARY KEY (id);


--
-- Name: journals journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journals
    ADD CONSTRAINT journals_pkey PRIMARY KEY (id);


--
-- Name: labor_budget_items labor_budget_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.labor_budget_items
    ADD CONSTRAINT labor_budget_items_pkey PRIMARY KEY (id);


--
-- Name: last_project_folders last_project_folders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.last_project_folders
    ADD CONSTRAINT last_project_folders_pkey PRIMARY KEY (id);


--
-- Name: ldap_auth_sources ldap_auth_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_auth_sources
    ADD CONSTRAINT ldap_auth_sources_pkey PRIMARY KEY (id);


--
-- Name: ldap_groups_memberships ldap_groups_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_groups_memberships
    ADD CONSTRAINT ldap_groups_memberships_pkey PRIMARY KEY (id);


--
-- Name: ldap_groups_synchronized_filters ldap_groups_synchronized_filters_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_groups_synchronized_filters
    ADD CONSTRAINT ldap_groups_synchronized_filters_pkey PRIMARY KEY (id);


--
-- Name: ldap_groups_synchronized_groups ldap_groups_synchronized_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_groups_synchronized_groups
    ADD CONSTRAINT ldap_groups_synchronized_groups_pkey PRIMARY KEY (id);


--
-- Name: material_budget_items material_budget_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_budget_items
    ADD CONSTRAINT material_budget_items_pkey PRIMARY KEY (id);


--
-- Name: mcp_configurations mcp_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_configurations
    ADD CONSTRAINT mcp_configurations_pkey PRIMARY KEY (id);


--
-- Name: meeting_agenda_item_journals meeting_agenda_item_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_agenda_item_journals
    ADD CONSTRAINT meeting_agenda_item_journals_pkey PRIMARY KEY (id);


--
-- Name: meeting_agenda_items meeting_agenda_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_agenda_items
    ADD CONSTRAINT meeting_agenda_items_pkey PRIMARY KEY (id);


--
-- Name: meeting_journals meeting_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_journals
    ADD CONSTRAINT meeting_journals_pkey PRIMARY KEY (id);


--
-- Name: meeting_outcomes meeting_outcomes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_outcomes
    ADD CONSTRAINT meeting_outcomes_pkey PRIMARY KEY (id);


--
-- Name: meeting_participants meeting_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_participants
    ADD CONSTRAINT meeting_participants_pkey PRIMARY KEY (id);


--
-- Name: meeting_sections meeting_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_sections
    ADD CONSTRAINT meeting_sections_pkey PRIMARY KEY (id);


--
-- Name: meetings meetings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meetings
    ADD CONSTRAINT meetings_pkey PRIMARY KEY (id);


--
-- Name: member_roles member_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_roles
    ADD CONSTRAINT member_roles_pkey PRIMARY KEY (id);


--
-- Name: members members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_pkey PRIMARY KEY (id);


--
-- Name: menu_items menu_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_pkey PRIMARY KEY (id);


--
-- Name: message_journals message_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_journals
    ADD CONSTRAINT message_journals_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: news_journals news_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.news_journals
    ADD CONSTRAINT news_journals_pkey PRIMARY KEY (id);


--
-- Name: news news_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.news
    ADD CONSTRAINT news_pkey PRIMARY KEY (id);


--
-- Name: journals non_overlapping_journals_validity_periods; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.journals
    ADD CONSTRAINT non_overlapping_journals_validity_periods EXCLUDE USING gist (journable_id WITH =, journable_type WITH =, validity_period WITH &&) DEFERRABLE;


--
-- Name: non_working_days non_working_days_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.non_working_days
    ADD CONSTRAINT non_working_days_pkey PRIMARY KEY (id);


--
-- Name: notification_settings notification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT notification_settings_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: oauth_access_grants oauth_access_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_grants
    ADD CONSTRAINT oauth_access_grants_pkey PRIMARY KEY (id);


--
-- Name: oauth_access_tokens oauth_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_tokens
    ADD CONSTRAINT oauth_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: oauth_applications oauth_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_applications
    ADD CONSTRAINT oauth_applications_pkey PRIMARY KEY (id);


--
-- Name: oauth_client_tokens oauth_client_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client_tokens
    ADD CONSTRAINT oauth_client_tokens_pkey PRIMARY KEY (id);


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- Name: oidc_group_links oidc_group_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_group_links
    ADD CONSTRAINT oidc_group_links_pkey PRIMARY KEY (id);


--
-- Name: oidc_group_memberships oidc_group_memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_group_memberships
    ADD CONSTRAINT oidc_group_memberships_pkey PRIMARY KEY (id);


--
-- Name: oidc_user_session_links oidc_user_session_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_user_session_links
    ADD CONSTRAINT oidc_user_session_links_pkey PRIMARY KEY (id);


--
-- Name: oidc_user_tokens oidc_user_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_user_tokens
    ADD CONSTRAINT oidc_user_tokens_pkey PRIMARY KEY (id);


--
-- Name: ordered_work_packages ordered_work_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordered_work_packages
    ADD CONSTRAINT ordered_work_packages_pkey PRIMARY KEY (id);


--
-- Name: paper_trail_audits paper_trail_audits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.paper_trail_audits
    ADD CONSTRAINT paper_trail_audits_pkey PRIMARY KEY (id);


--
-- Name: project_custom_field_project_mappings project_custom_field_project_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_custom_field_project_mappings
    ADD CONSTRAINT project_custom_field_project_mappings_pkey PRIMARY KEY (id);


--
-- Name: project_journals project_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_journals
    ADD CONSTRAINT project_journals_pkey PRIMARY KEY (id);


--
-- Name: project_phase_definitions project_phase_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_phase_definitions
    ADD CONSTRAINT project_phase_definitions_pkey PRIMARY KEY (id);


--
-- Name: project_phase_journals project_phase_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_phase_journals
    ADD CONSTRAINT project_phase_journals_pkey PRIMARY KEY (id);


--
-- Name: project_phases project_phases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_phases
    ADD CONSTRAINT project_phases_pkey PRIMARY KEY (id);


--
-- Name: project_queries project_queries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_queries
    ADD CONSTRAINT project_queries_pkey PRIMARY KEY (id);


--
-- Name: project_storages project_storages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_storages
    ADD CONSTRAINT project_storages_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: queries queries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.queries
    ADD CONSTRAINT queries_pkey PRIMARY KEY (id);


--
-- Name: rates rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rates
    ADD CONSTRAINT rates_pkey PRIMARY KEY (id);


--
-- Name: recaptcha_entries recaptcha_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recaptcha_entries
    ADD CONSTRAINT recaptcha_entries_pkey PRIMARY KEY (id);


--
-- Name: recurring_meeting_interim_responses recurring_meeting_interim_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recurring_meeting_interim_responses
    ADD CONSTRAINT recurring_meeting_interim_responses_pkey PRIMARY KEY (id);


--
-- Name: recurring_meetings recurring_meetings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recurring_meetings
    ADD CONSTRAINT recurring_meetings_pkey PRIMARY KEY (id);


--
-- Name: relations relations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.relations
    ADD CONSTRAINT relations_pkey PRIMARY KEY (id);


--
-- Name: reminder_notifications reminder_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reminder_notifications
    ADD CONSTRAINT reminder_notifications_pkey PRIMARY KEY (id);


--
-- Name: reminders reminders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reminders
    ADD CONSTRAINT reminders_pkey PRIMARY KEY (id);


--
-- Name: remote_identities remote_identities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remote_identities
    ADD CONSTRAINT remote_identities_pkey PRIMARY KEY (id);


--
-- Name: repositories repositories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repositories
    ADD CONSTRAINT repositories_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: scheduled_meetings scheduled_meetings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_meetings
    ADD CONSTRAINT scheduled_meetings_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: scim_clients scim_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scim_clients
    ADD CONSTRAINT scim_clients_pkey PRIMARY KEY (id);


--
-- Name: service_account_associations service_account_associations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_account_associations
    ADD CONSTRAINT service_account_associations_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: statuses statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statuses
    ADD CONSTRAINT statuses_pkey PRIMARY KEY (id);


--
-- Name: storages_file_links_journals storages_file_links_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storages_file_links_journals
    ADD CONSTRAINT storages_file_links_journals_pkey PRIMARY KEY (id);


--
-- Name: storages storages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storages
    ADD CONSTRAINT storages_pkey PRIMARY KEY (id);


--
-- Name: subproject_template_assignments subproject_template_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subproject_template_assignments
    ADD CONSTRAINT subproject_template_assignments_pkey PRIMARY KEY (id);


--
-- Name: time_entries time_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_pkey PRIMARY KEY (id);


--
-- Name: time_entry_activities_projects time_entry_activities_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entry_activities_projects
    ADD CONSTRAINT time_entry_activities_projects_pkey PRIMARY KEY (id);


--
-- Name: time_entry_journals time_entry_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entry_journals
    ADD CONSTRAINT time_entry_journals_pkey PRIMARY KEY (id);


--
-- Name: tokens tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT tokens_pkey PRIMARY KEY (id);


--
-- Name: two_factor_authentication_devices two_factor_authentication_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.two_factor_authentication_devices
    ADD CONSTRAINT two_factor_authentication_devices_pkey PRIMARY KEY (id);


--
-- Name: types types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.types
    ADD CONSTRAINT types_pkey PRIMARY KEY (id);


--
-- Name: scheduled_meetings unique_recurring_meeting_start_time; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_meetings
    ADD CONSTRAINT unique_recurring_meeting_start_time UNIQUE (recurring_meeting_id, start_time) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_auth_provider_links user_auth_provider_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_auth_provider_links
    ADD CONSTRAINT user_auth_provider_links_pkey PRIMARY KEY (id);


--
-- Name: user_passwords user_passwords_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_passwords
    ADD CONSTRAINT user_passwords_pkey PRIMARY KEY (id);


--
-- Name: user_preferences user_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: version_settings version_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.version_settings
    ADD CONSTRAINT version_settings_pkey PRIMARY KEY (id);


--
-- Name: versions versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.versions
    ADD CONSTRAINT versions_pkey PRIMARY KEY (id);


--
-- Name: views views_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.views
    ADD CONSTRAINT views_pkey PRIMARY KEY (id);


--
-- Name: watchers watchers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.watchers
    ADD CONSTRAINT watchers_pkey PRIMARY KEY (id);


--
-- Name: webhooks_events webhooks_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_events
    ADD CONSTRAINT webhooks_events_pkey PRIMARY KEY (id);


--
-- Name: webhooks_logs webhooks_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_logs
    ADD CONSTRAINT webhooks_logs_pkey PRIMARY KEY (id);


--
-- Name: webhooks_projects webhooks_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_projects
    ADD CONSTRAINT webhooks_projects_pkey PRIMARY KEY (id);


--
-- Name: webhooks_webhooks webhooks_webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_webhooks
    ADD CONSTRAINT webhooks_webhooks_pkey PRIMARY KEY (id);


--
-- Name: wiki_page_journals wiki_page_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_page_journals
    ADD CONSTRAINT wiki_page_journals_pkey PRIMARY KEY (id);


--
-- Name: wiki_pages wiki_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_pages
    ADD CONSTRAINT wiki_pages_pkey PRIMARY KEY (id);


--
-- Name: wiki_redirects wiki_redirects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_redirects
    ADD CONSTRAINT wiki_redirects_pkey PRIMARY KEY (id);


--
-- Name: wikis wikis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wikis
    ADD CONSTRAINT wikis_pkey PRIMARY KEY (id);


--
-- Name: work_package_journals work_package_journals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_package_journals
    ADD CONSTRAINT work_package_journals_pkey PRIMARY KEY (id);


--
-- Name: work_packages work_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_packages
    ADD CONSTRAINT work_packages_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: changesets_changeset_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX changesets_changeset_id ON public.changes USING btree (changeset_id);


--
-- Name: changesets_repos_rev; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX changesets_repos_rev ON public.changesets USING btree (repository_id, revision);


--
-- Name: changesets_repos_scmid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX changesets_repos_scmid ON public.changesets USING btree (repository_id, scmid);


--
-- Name: changesets_work_packages_ids; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX changesets_work_packages_ids ON public.changesets_work_packages USING btree (changeset_id, work_package_id);


--
-- Name: custom_fields_types_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX custom_fields_types_unique ON public.custom_fields_types USING btree (custom_field_id, type_id);


--
-- Name: custom_values_customized; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX custom_values_customized ON public.custom_values USING btree (customized_type, customized_id);


--
-- Name: documents_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX documents_project_id ON public.documents USING btree (project_id);


--
-- Name: enabled_modules_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX enabled_modules_project_id ON public.enabled_modules USING btree (project_id);


--
-- Name: forums_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX forums_project_id ON public.forums USING btree (project_id);


--
-- Name: github_pr_wp_pr_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX github_pr_wp_pr_id ON public.github_pull_requests_work_packages USING btree (github_pull_request_id);


--
-- Name: gitlab_issues_wp_issue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gitlab_issues_wp_issue_id ON public.gitlab_issues_work_packages USING btree (gitlab_issue_id);


--
-- Name: gitlab_mr_wp_mr_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gitlab_mr_wp_mr_id ON public.gitlab_merge_requests_work_packages USING btree (gitlab_merge_request_id);


--
-- Name: group_user_ids; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX group_user_ids ON public.group_users USING btree (group_id, user_id);


--
-- Name: idx_on_auth_provider_id_external_id_a8e6468bb9; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_on_auth_provider_id_external_id_a8e6468bb9 ON public.user_auth_provider_links USING btree (auth_provider_id, external_id);


--
-- Name: idx_on_auth_provider_id_group_user_id_f86563dc26; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_on_auth_provider_id_group_user_id_f86563dc26 ON public.oidc_group_memberships USING btree (auth_provider_id, group_user_id);


--
-- Name: idx_on_recurring_meeting_id_start_time_user_id_0ea652f142; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_on_recurring_meeting_id_start_time_user_id_0ea652f142 ON public.recurring_meeting_interim_responses USING btree (recurring_meeting_id, start_time, user_id);


--
-- Name: idx_on_service_type_service_id_a76ab08fa2; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_on_service_type_service_id_a76ab08fa2 ON public.service_account_associations USING btree (service_type, service_id);


--
-- Name: idx_on_user_id_auth_source_type_auth_source_id_inte_fc6941e656; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_on_user_id_auth_source_type_auth_source_id_inte_fc6941e656 ON public.remote_identities USING btree (user_id, auth_source_type, auth_source_id, integration_id, integration_type);


--
-- Name: idx_subproj_tmpl_assignments_on_project_workspace; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_subproj_tmpl_assignments_on_project_workspace ON public.subproject_template_assignments USING btree (project_id, workspace_type);


--
-- Name: index_announcements_on_show_until_and_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_announcements_on_show_until_and_active ON public.announcements USING btree (show_until, active);


--
-- Name: index_attachable_journals_on_attachment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_attachable_journals_on_attachment_id ON public.attachable_journals USING btree (attachment_id);


--
-- Name: index_attachable_journals_on_journal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_attachable_journals_on_journal_id ON public.attachable_journals USING btree (journal_id);


--
-- Name: index_attachments_on_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_attachments_on_author_id ON public.attachments USING btree (author_id);


--
-- Name: index_attachments_on_container_id_and_container_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_attachments_on_container_id_and_container_type ON public.attachments USING btree (container_id, container_type);


--
-- Name: index_attachments_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_attachments_on_created_at ON public.attachments USING btree (created_at);


--
-- Name: index_attachments_on_file_tsv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_attachments_on_file_tsv ON public.attachments USING gin (file_tsv);


--
-- Name: index_attachments_on_fulltext_tsv; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_attachments_on_fulltext_tsv ON public.attachments USING gin (fulltext_tsv);


--
-- Name: index_auth_providers_on_creator_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_auth_providers_on_creator_id ON public.auth_providers USING btree (creator_id);


--
-- Name: index_auth_providers_on_display_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_auth_providers_on_display_name ON public.auth_providers USING btree (display_name);


--
-- Name: index_auth_providers_on_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_auth_providers_on_slug ON public.auth_providers USING btree (slug);


--
-- Name: index_autologin_session_links_on_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_autologin_session_links_on_session_id ON public.autologin_session_links USING btree (session_id);


--
-- Name: index_autologin_session_links_on_token_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_autologin_session_links_on_token_id ON public.autologin_session_links USING btree (token_id);


--
-- Name: index_bcf_comments_on_issue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_bcf_comments_on_issue_id ON public.bcf_comments USING btree (issue_id);


--
-- Name: index_bcf_comments_on_journal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_bcf_comments_on_journal_id ON public.bcf_comments USING btree (journal_id);


--
-- Name: index_bcf_comments_on_uuid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_bcf_comments_on_uuid ON public.bcf_comments USING btree (uuid);


--
-- Name: index_bcf_comments_on_uuid_and_issue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_bcf_comments_on_uuid_and_issue_id ON public.bcf_comments USING btree (uuid, issue_id);


--
-- Name: index_bcf_comments_on_viewpoint_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_bcf_comments_on_viewpoint_id ON public.bcf_comments USING btree (viewpoint_id);


--
-- Name: index_bcf_issues_on_uuid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_bcf_issues_on_uuid ON public.bcf_issues USING btree (uuid);


--
-- Name: index_bcf_issues_on_work_package_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_bcf_issues_on_work_package_id ON public.bcf_issues USING btree (work_package_id);


--
-- Name: index_bcf_viewpoints_on_issue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_bcf_viewpoints_on_issue_id ON public.bcf_viewpoints USING btree (issue_id);


--
-- Name: index_bcf_viewpoints_on_uuid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_bcf_viewpoints_on_uuid ON public.bcf_viewpoints USING btree (uuid);


--
-- Name: index_bcf_viewpoints_on_uuid_and_issue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_bcf_viewpoints_on_uuid_and_issue_id ON public.bcf_viewpoints USING btree (uuid, issue_id);


--
-- Name: index_budgets_on_project_id_and_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_budgets_on_project_id_and_updated_at ON public.budgets USING btree (project_id, updated_at);


--
-- Name: index_calculated_value_errors_on_custom_field_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_calculated_value_errors_on_custom_field_id ON public.calculated_value_errors USING btree (custom_field_id);


--
-- Name: index_calculated_value_errors_on_customized; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_calculated_value_errors_on_customized ON public.calculated_value_errors USING btree (customized_type, customized_id);


--
-- Name: index_categories_on_assigned_to_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_categories_on_assigned_to_id ON public.categories USING btree (assigned_to_id);


--
-- Name: index_categories_on_project_id_and_LOWER_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "index_categories_on_project_id_and_LOWER_name" ON public.categories USING btree (project_id, lower((name)::text));


--
-- Name: index_changesets_on_committed_on; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_changesets_on_committed_on ON public.changesets USING btree (committed_on);


--
-- Name: index_changesets_on_repository_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_changesets_on_repository_id ON public.changesets USING btree (repository_id);


--
-- Name: index_changesets_on_repository_id_and_committed_on; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_changesets_on_repository_id_and_committed_on ON public.changesets USING btree (repository_id, committed_on);


--
-- Name: index_changesets_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_changesets_on_user_id ON public.changesets USING btree (user_id);


--
-- Name: index_comments_on_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_comments_on_author_id ON public.comments USING btree (author_id);


--
-- Name: index_comments_on_commented_id_and_commented_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_comments_on_commented_id_and_commented_type ON public.comments USING btree (commented_id, commented_type);


--
-- Name: index_cost_entries_on_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_cost_entries_on_entity ON public.cost_entries USING btree (entity_type, entity_id);


--
-- Name: index_cost_entries_on_entity_type_and_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_cost_entries_on_entity_type_and_entity_id ON public.cost_entries USING btree (entity_type, entity_id);


--
-- Name: index_cost_entries_on_logged_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_cost_entries_on_logged_by_id ON public.cost_entries USING btree (logged_by_id);


--
-- Name: index_cost_types_on_LOWER_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "index_cost_types_on_LOWER_name" ON public.cost_types USING btree (lower((name)::text));


--
-- Name: index_custom_actions_projects_on_custom_action_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_projects_on_custom_action_id ON public.custom_actions_projects USING btree (custom_action_id);


--
-- Name: index_custom_actions_projects_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_projects_on_project_id ON public.custom_actions_projects USING btree (project_id);


--
-- Name: index_custom_actions_roles_on_custom_action_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_roles_on_custom_action_id ON public.custom_actions_roles USING btree (custom_action_id);


--
-- Name: index_custom_actions_roles_on_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_roles_on_role_id ON public.custom_actions_roles USING btree (role_id);


--
-- Name: index_custom_actions_statuses_on_custom_action_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_statuses_on_custom_action_id ON public.custom_actions_statuses USING btree (custom_action_id);


--
-- Name: index_custom_actions_statuses_on_status_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_statuses_on_status_id ON public.custom_actions_statuses USING btree (status_id);


--
-- Name: index_custom_actions_types_on_custom_action_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_types_on_custom_action_id ON public.custom_actions_types USING btree (custom_action_id);


--
-- Name: index_custom_actions_types_on_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_actions_types_on_type_id ON public.custom_actions_types USING btree (type_id);


--
-- Name: index_custom_fields_on_custom_field_section_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_fields_on_custom_field_section_id ON public.custom_fields USING btree (custom_field_section_id);


--
-- Name: index_custom_fields_on_formula; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_fields_on_formula ON public.custom_fields USING gin (formula);


--
-- Name: index_custom_fields_on_id_and_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_fields_on_id_and_type ON public.custom_fields USING btree (id, type);


--
-- Name: index_custom_fields_on_type_and_LOWER_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "index_custom_fields_on_type_and_LOWER_name" ON public.custom_fields USING btree (type, lower((name)::text));


--
-- Name: index_custom_fields_projects_on_custom_field_id_and_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_custom_fields_projects_on_custom_field_id_and_project_id ON public.custom_fields_projects USING btree (custom_field_id, project_id);


--
-- Name: index_custom_fields_roles_on_custom_field_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_custom_fields_roles_on_custom_field_id ON public.custom_fields_roles USING btree (custom_field_id);


--
-- Name: index_custom_fields_roles_on_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_fields_roles_on_role_id ON public.custom_fields_roles USING btree (role_id);


--
-- Name: index_custom_options_on_custom_field_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_options_on_custom_field_id ON public.custom_options USING btree (custom_field_id);


--
-- Name: index_custom_options_on_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_options_on_value ON public.custom_options USING gin (value gin_trgm_ops);


--
-- Name: index_custom_values_on_custom_field_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_values_on_custom_field_id ON public.custom_values USING btree (custom_field_id);


--
-- Name: index_custom_values_on_value; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_custom_values_on_value ON public.custom_values USING gin (value gin_trgm_ops);


--
-- Name: index_customizable_journals_on_custom_field_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_customizable_journals_on_custom_field_id ON public.customizable_journals USING btree (custom_field_id);


--
-- Name: index_customizable_journals_on_journal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_customizable_journals_on_journal_id ON public.customizable_journals USING btree (journal_id);


--
-- Name: index_deploy_status_checks_on_deploy_target_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_deploy_status_checks_on_deploy_target_id ON public.deploy_status_checks USING btree (deploy_target_id);


--
-- Name: index_deploy_status_checks_on_github_pull_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_deploy_status_checks_on_github_pull_request_id ON public.deploy_status_checks USING btree (github_pull_request_id);


--
-- Name: index_deploy_targets_on_host; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_deploy_targets_on_host ON public.deploy_targets USING btree (host);


--
-- Name: index_design_colors_on_variable; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_design_colors_on_variable ON public.design_colors USING btree (variable);


--
-- Name: index_document_types_on_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_document_types_on_name ON public.document_types USING btree (name);


--
-- Name: index_documents_on_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_documents_on_category_id ON public.documents USING btree (category_id);


--
-- Name: index_documents_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_documents_on_created_at ON public.documents USING btree (created_at);


--
-- Name: index_documents_on_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_documents_on_type_id ON public.documents USING btree (type_id);


--
-- Name: index_emoji_reactions_on_reactable; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_emoji_reactions_on_reactable ON public.emoji_reactions USING btree (reactable_type, reactable_id);


--
-- Name: index_emoji_reactions_on_reaction; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_emoji_reactions_on_reaction ON public.emoji_reactions USING btree (reaction);


--
-- Name: index_emoji_reactions_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_emoji_reactions_on_user_id ON public.emoji_reactions USING btree (user_id);


--
-- Name: index_emoji_reactions_uniqueness; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_emoji_reactions_uniqueness ON public.emoji_reactions USING btree (user_id, reactable_type, reactable_id, reaction);


--
-- Name: index_enabled_modules_on_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_enabled_modules_on_name ON public.enabled_modules USING btree (name);


--
-- Name: index_enterprise_tokens_on_valid_from_and_valid_until; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_enterprise_tokens_on_valid_from_and_valid_until ON public.enterprise_tokens USING btree (valid_from, valid_until);


--
-- Name: index_enumerations_on_color_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_enumerations_on_color_id ON public.enumerations USING btree (color_id);


--
-- Name: index_enumerations_on_id_and_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_enumerations_on_id_and_type ON public.enumerations USING btree (id, type);


--
-- Name: index_enumerations_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_enumerations_on_project_id ON public.enumerations USING btree (project_id);


--
-- Name: index_enumerations_on_type_project_id_and_LOWER_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "index_enumerations_on_type_project_id_and_LOWER_name" ON public.enumerations USING btree (type, project_id, lower((name)::text)) NULLS NOT DISTINCT;


--
-- Name: index_export_settings_on_query_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_export_settings_on_query_id ON public.export_settings USING btree (query_id);


--
-- Name: index_export_settings_on_query_id_and_format; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_export_settings_on_query_id_and_format ON public.export_settings USING btree (query_id, format);


--
-- Name: index_favorites_on_favored; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_favorites_on_favored ON public.favorites USING btree (favorited_type, favorited_id);


--
-- Name: index_favorites_on_favorited_type_and_favorited_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_favorites_on_favorited_type_and_favorited_id ON public.favorites USING btree (favorited_type, favorited_id);


--
-- Name: index_favorites_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_favorites_on_user_id ON public.favorites USING btree (user_id);


--
-- Name: index_favorites_on_user_id_and_favorited_type_and_favorited_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_favorites_on_user_id_and_favorited_type_and_favorited_id ON public.favorites USING btree (user_id, favorited_type, favorited_id);


--
-- Name: index_file_links_on_container_id_and_container_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_file_links_on_container_id_and_container_type ON public.file_links USING btree (container_id, container_type);


--
-- Name: index_file_links_on_creator_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_file_links_on_creator_id ON public.file_links USING btree (creator_id);


--
-- Name: index_file_links_on_origin_id_and_storage_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_file_links_on_origin_id_and_storage_id ON public.file_links USING btree (origin_id, storage_id);


--
-- Name: index_file_links_on_storage_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_file_links_on_storage_id ON public.file_links USING btree (storage_id);


--
-- Name: index_forums_on_last_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_forums_on_last_message_id ON public.forums USING btree (last_message_id);


--
-- Name: index_github_check_runs_on_github_pull_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_github_check_runs_on_github_pull_request_id ON public.github_check_runs USING btree (github_pull_request_id);


--
-- Name: index_github_pull_requests_on_github_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_github_pull_requests_on_github_user_id ON public.github_pull_requests USING btree (github_user_id);


--
-- Name: index_github_pull_requests_on_merged_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_github_pull_requests_on_merged_by_id ON public.github_pull_requests USING btree (merged_by_id);


--
-- Name: index_gitlab_issues_on_gitlab_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_gitlab_issues_on_gitlab_user_id ON public.gitlab_issues USING btree (gitlab_user_id);


--
-- Name: index_gitlab_merge_requests_on_gitlab_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_gitlab_merge_requests_on_gitlab_user_id ON public.gitlab_merge_requests USING btree (gitlab_user_id);


--
-- Name: index_gitlab_merge_requests_on_merged_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_gitlab_merge_requests_on_merged_by_id ON public.gitlab_merge_requests USING btree (merged_by_id);


--
-- Name: index_gitlab_pipelines_on_gitlab_merge_request_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_gitlab_pipelines_on_gitlab_merge_request_id ON public.gitlab_pipelines USING btree (gitlab_merge_request_id);


--
-- Name: index_good_job_executions_on_active_job_id_and_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_good_job_executions_on_active_job_id_and_created_at ON public.good_job_executions USING btree (active_job_id, created_at);


--
-- Name: index_good_job_executions_on_process_id_and_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_good_job_executions_on_process_id_and_created_at ON public.good_job_executions USING btree (process_id, created_at);


--
-- Name: index_good_job_jobs_for_candidate_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_good_job_jobs_for_candidate_lookup ON public.good_jobs USING btree (priority, created_at) WHERE (finished_at IS NULL);


--
-- Name: index_good_job_settings_on_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_good_job_settings_on_key ON public.good_job_settings USING btree (key);


--
-- Name: index_good_jobs_jobs_on_finished_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_good_jobs_jobs_on_finished_at ON public.good_jobs USING btree (finished_at) WHERE ((retried_good_job_id IS NULL) AND (finished_at IS NOT NULL));


--
-- Name: index_good_jobs_jobs_on_priority_created_at_when_unfinished; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_good_jobs_jobs_on_priority_created_at_when_unfinished ON public.good_jobs USING btree (priority DESC NULLS LAST, created_at) WHERE (finished_at IS NULL);


--
-- Name: index_good_jobs_on_active_job_id_and_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_good_jobs_on_active_job_id_and_created_at ON public.good_jobs USING btree (active_job_id, created_at);


--
-- Name: index_good_jobs_on_batch_callback_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_good_jobs_on_batch_callback_id ON public.good_jobs USING btree (batch_callback_id) WHERE (batch_callback_id IS NOT NULL);


--
-- Name: index_good_jobs_on_batch_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_good_jobs_on_batch_id ON public.good_jobs USING btree (batch_id) WHERE (batch_id IS NOT NULL);


--
-- Name: index_good_jobs_on_concurrency_key_and_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_good_jobs_on_concurrency_key_and_created_at ON public.good_jobs USING btree (concurrency_key, created_at);


--
-- Name: index_good_jobs_on_concurrency_key_when_unfinished; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_good_jobs_on_concurrency_key_when_unfinished ON public.good_jobs USING btree (concurrency_key) WHERE (finished_at IS NULL);


--
-- Name: index_good_jobs_on_cron_key_and_created_at_cond; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_good_jobs_on_cron_key_and_created_at_cond ON public.good_jobs USING btree (cron_key, created_at) WHERE (cron_key IS NOT NULL);


--
-- Name: index_good_jobs_on_cron_key_and_cron_at_cond; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_good_jobs_on_cron_key_and_cron_at_cond ON public.good_jobs USING btree (cron_key, cron_at) WHERE (cron_key IS NOT NULL);


--
-- Name: index_good_jobs_on_job_class; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_good_jobs_on_job_class ON public.good_jobs USING btree (job_class);


--
-- Name: index_good_jobs_on_labels; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_good_jobs_on_labels ON public.good_jobs USING gin (labels) WHERE (labels IS NOT NULL);


--
-- Name: index_good_jobs_on_locked_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_good_jobs_on_locked_by_id ON public.good_jobs USING btree (locked_by_id) WHERE (locked_by_id IS NOT NULL);


--
-- Name: index_good_jobs_on_priority_scheduled_at_unfinished_unlocked; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_good_jobs_on_priority_scheduled_at_unfinished_unlocked ON public.good_jobs USING btree (priority, scheduled_at) WHERE ((finished_at IS NULL) AND (locked_by_id IS NULL));


--
-- Name: index_good_jobs_on_queue_name_and_scheduled_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_good_jobs_on_queue_name_and_scheduled_at ON public.good_jobs USING btree (queue_name, scheduled_at) WHERE (finished_at IS NULL);


--
-- Name: index_good_jobs_on_scheduled_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_good_jobs_on_scheduled_at ON public.good_jobs USING btree (scheduled_at) WHERE (finished_at IS NULL);


--
-- Name: index_grid_widgets_on_grid_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_grid_widgets_on_grid_id ON public.grid_widgets USING btree (grid_id);


--
-- Name: index_grids_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_grids_on_project_id ON public.grids USING btree (project_id);


--
-- Name: index_grids_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_grids_on_user_id ON public.grids USING btree (user_id);


--
-- Name: index_group_users_on_user_id_and_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_group_users_on_user_id_and_group_id ON public.group_users USING btree (user_id, group_id);


--
-- Name: index_hierarchical_items_on_custom_field_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_hierarchical_items_on_custom_field_id ON public.hierarchical_items USING btree (custom_field_id);


--
-- Name: index_hierarchical_items_on_position_cache; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_hierarchical_items_on_position_cache ON public.hierarchical_items USING btree (position_cache);


--
-- Name: index_ical_token_query_assignments_on_ical_token_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ical_token_query_assignments_on_ical_token_id ON public.ical_token_query_assignments USING btree (ical_token_id);


--
-- Name: index_ical_token_query_assignments_on_query_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ical_token_query_assignments_on_query_id ON public.ical_token_query_assignments USING btree (query_id);


--
-- Name: index_ifc_models_on_is_default; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ifc_models_on_is_default ON public.ifc_models USING btree (is_default);


--
-- Name: index_ifc_models_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ifc_models_on_project_id ON public.ifc_models USING btree (project_id);


--
-- Name: index_ifc_models_on_uploader_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ifc_models_on_uploader_id ON public.ifc_models USING btree (uploader_id);


--
-- Name: index_job_statuses_on_job_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_job_statuses_on_job_id ON public.job_statuses USING btree (job_id);


--
-- Name: index_job_statuses_on_reference_type_and_reference_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_job_statuses_on_reference_type_and_reference_id ON public.job_statuses USING btree (reference_type, reference_id);


--
-- Name: index_job_statuses_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_job_statuses_on_user_id ON public.job_statuses USING btree (user_id);


--
-- Name: index_journals_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_journals_on_created_at ON public.journals USING btree (created_at);


--
-- Name: index_journals_on_data_id_and_data_type; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_journals_on_data_id_and_data_type ON public.journals USING btree (data_id, data_type);


--
-- Name: index_journals_on_journable_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_journals_on_journable_id ON public.journals USING btree (journable_id);


--
-- Name: index_journals_on_journable_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_journals_on_journable_type ON public.journals USING btree (journable_type);


--
-- Name: index_journals_on_journable_type_and_journable_id_and_version; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_journals_on_journable_type_and_journable_id_and_version ON public.journals USING btree (journable_type, journable_id, version);


--
-- Name: index_journals_on_notes; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_journals_on_notes ON public.journals USING gin (notes gin_trgm_ops);


--
-- Name: index_journals_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_journals_on_user_id ON public.journals USING btree (user_id);


--
-- Name: index_last_project_folders_on_project_storage_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_last_project_folders_on_project_storage_id ON public.last_project_folders USING btree (project_storage_id);


--
-- Name: index_last_project_folders_on_project_storage_id_and_mode; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_last_project_folders_on_project_storage_id_and_mode ON public.last_project_folders USING btree (project_storage_id, mode);


--
-- Name: index_ldap_auth_sources_on_LOWER_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "index_ldap_auth_sources_on_LOWER_name" ON public.ldap_auth_sources USING btree (lower((name)::text));


--
-- Name: index_ldap_groups_memberships_on_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ldap_groups_memberships_on_group_id ON public.ldap_groups_memberships USING btree (group_id);


--
-- Name: index_ldap_groups_memberships_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ldap_groups_memberships_on_user_id ON public.ldap_groups_memberships USING btree (user_id);


--
-- Name: index_ldap_groups_memberships_on_user_id_and_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_ldap_groups_memberships_on_user_id_and_group_id ON public.ldap_groups_memberships USING btree (user_id, group_id);


--
-- Name: index_ldap_groups_synchronized_filters_on_ldap_auth_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ldap_groups_synchronized_filters_on_ldap_auth_source_id ON public.ldap_groups_synchronized_filters USING btree (ldap_auth_source_id);


--
-- Name: index_ldap_groups_synchronized_groups_on_filter_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ldap_groups_synchronized_groups_on_filter_id ON public.ldap_groups_synchronized_groups USING btree (filter_id);


--
-- Name: index_ldap_groups_synchronized_groups_on_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ldap_groups_synchronized_groups_on_group_id ON public.ldap_groups_synchronized_groups USING btree (group_id);


--
-- Name: index_ldap_groups_synchronized_groups_on_ldap_auth_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ldap_groups_synchronized_groups_on_ldap_auth_source_id ON public.ldap_groups_synchronized_groups USING btree (ldap_auth_source_id);


--
-- Name: index_meeting_agenda_item_journals_on_presenter_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_meeting_agenda_item_journals_on_presenter_id ON public.meeting_agenda_item_journals USING btree (presenter_id);


--
-- Name: index_meeting_agenda_items_on_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_meeting_agenda_items_on_author_id ON public.meeting_agenda_items USING btree (author_id);


--
-- Name: index_meeting_agenda_items_on_meeting_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_meeting_agenda_items_on_meeting_id ON public.meeting_agenda_items USING btree (meeting_id);


--
-- Name: index_meeting_agenda_items_on_meeting_section_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_meeting_agenda_items_on_meeting_section_id ON public.meeting_agenda_items USING btree (meeting_section_id);


--
-- Name: index_meeting_agenda_items_on_notes; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_meeting_agenda_items_on_notes ON public.meeting_agenda_items USING gin (notes gin_trgm_ops);


--
-- Name: index_meeting_agenda_items_on_presenter_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_meeting_agenda_items_on_presenter_id ON public.meeting_agenda_items USING btree (presenter_id);


--
-- Name: index_meeting_agenda_items_on_work_package_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_meeting_agenda_items_on_work_package_id ON public.meeting_agenda_items USING btree (work_package_id);


--
-- Name: index_meeting_outcomes_on_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_meeting_outcomes_on_author_id ON public.meeting_outcomes USING btree (author_id);


--
-- Name: index_meeting_outcomes_on_meeting_agenda_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_meeting_outcomes_on_meeting_agenda_item_id ON public.meeting_outcomes USING btree (meeting_agenda_item_id);


--
-- Name: index_meeting_outcomes_on_work_package_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_meeting_outcomes_on_work_package_id ON public.meeting_outcomes USING btree (work_package_id);


--
-- Name: index_meeting_participants_on_meeting_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_meeting_participants_on_meeting_id ON public.meeting_participants USING btree (meeting_id);


--
-- Name: index_meeting_participants_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_meeting_participants_on_user_id ON public.meeting_participants USING btree (user_id);


--
-- Name: index_meeting_sections_on_meeting_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_meeting_sections_on_meeting_id ON public.meeting_sections USING btree (meeting_id);


--
-- Name: index_meetings_on_project_id_and_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_meetings_on_project_id_and_updated_at ON public.meetings USING btree (project_id, updated_at);


--
-- Name: index_meetings_on_recurring_meeting_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_meetings_on_recurring_meeting_id ON public.meetings USING btree (recurring_meeting_id);


--
-- Name: index_meetings_on_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_meetings_on_uid ON public.meetings USING btree (uid);


--
-- Name: index_member_roles_on_inherited_from; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_member_roles_on_inherited_from ON public.member_roles USING btree (inherited_from);


--
-- Name: index_member_roles_on_member_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_member_roles_on_member_id ON public.member_roles USING btree (member_id);


--
-- Name: index_member_roles_on_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_member_roles_on_role_id ON public.member_roles USING btree (role_id);


--
-- Name: index_members_on_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_members_on_entity ON public.members USING btree (entity_type, entity_id);


--
-- Name: index_members_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_members_on_project_id ON public.members USING btree (project_id);


--
-- Name: index_members_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_members_on_user_id ON public.members USING btree (user_id);


--
-- Name: index_members_on_user_id_and_project_with_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_members_on_user_id_and_project_with_entity ON public.members USING btree (user_id, project_id, entity_type, entity_id) WHERE ((entity_type IS NOT NULL) AND (entity_id IS NOT NULL));


--
-- Name: index_members_on_user_id_and_project_without_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_members_on_user_id_and_project_without_entity ON public.members USING btree (user_id, project_id) WHERE ((entity_type IS NULL) AND (entity_id IS NULL));


--
-- Name: index_menu_items_on_navigatable_id_and_title; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_menu_items_on_navigatable_id_and_title ON public.menu_items USING btree (navigatable_id, title);


--
-- Name: index_menu_items_on_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_menu_items_on_parent_id ON public.menu_items USING btree (parent_id);


--
-- Name: index_messages_on_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_messages_on_author_id ON public.messages USING btree (author_id);


--
-- Name: index_messages_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_messages_on_created_at ON public.messages USING btree (created_at);


--
-- Name: index_messages_on_forum_id_and_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_messages_on_forum_id_and_updated_at ON public.messages USING btree (forum_id, updated_at);


--
-- Name: index_messages_on_last_reply_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_messages_on_last_reply_id ON public.messages USING btree (last_reply_id);


--
-- Name: index_news_journals_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_news_journals_on_project_id ON public.news_journals USING btree (project_id);


--
-- Name: index_news_on_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_news_on_author_id ON public.news USING btree (author_id);


--
-- Name: index_news_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_news_on_created_at ON public.news USING btree (created_at);


--
-- Name: index_news_on_project_id_and_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_news_on_project_id_and_created_at ON public.news USING btree (project_id, created_at);


--
-- Name: index_non_working_days_on_date; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_non_working_days_on_date ON public.non_working_days USING btree (date);


--
-- Name: index_notification_settings_on_document_added; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_document_added ON public.notification_settings USING btree (document_added);


--
-- Name: index_notification_settings_on_forum_messages; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_forum_messages ON public.notification_settings USING btree (forum_messages);


--
-- Name: index_notification_settings_on_membership_added; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_membership_added ON public.notification_settings USING btree (membership_added);


--
-- Name: index_notification_settings_on_membership_updated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_membership_updated ON public.notification_settings USING btree (membership_updated);


--
-- Name: index_notification_settings_on_news_added; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_news_added ON public.notification_settings USING btree (news_added);


--
-- Name: index_notification_settings_on_news_commented; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_news_commented ON public.notification_settings USING btree (news_commented);


--
-- Name: index_notification_settings_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_project_id ON public.notification_settings USING btree (project_id);


--
-- Name: index_notification_settings_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_user_id ON public.notification_settings USING btree (user_id);


--
-- Name: index_notification_settings_on_wiki_page_added; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_wiki_page_added ON public.notification_settings USING btree (wiki_page_added);


--
-- Name: index_notification_settings_on_wiki_page_updated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_wiki_page_updated ON public.notification_settings USING btree (wiki_page_updated);


--
-- Name: index_notification_settings_on_work_package_commented; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_work_package_commented ON public.notification_settings USING btree (work_package_commented);


--
-- Name: index_notification_settings_on_work_package_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_work_package_created ON public.notification_settings USING btree (work_package_created);


--
-- Name: index_notification_settings_on_work_package_prioritized; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_work_package_prioritized ON public.notification_settings USING btree (work_package_prioritized);


--
-- Name: index_notification_settings_on_work_package_processed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_work_package_processed ON public.notification_settings USING btree (work_package_processed);


--
-- Name: index_notification_settings_on_work_package_scheduled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notification_settings_on_work_package_scheduled ON public.notification_settings USING btree (work_package_scheduled);


--
-- Name: index_notification_settings_unique_project; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_notification_settings_unique_project ON public.notification_settings USING btree (user_id, project_id) WHERE (project_id IS NOT NULL);


--
-- Name: index_notification_settings_unique_project_null; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_notification_settings_unique_project_null ON public.notification_settings USING btree (user_id) WHERE (project_id IS NULL);


--
-- Name: index_notifications_on_actor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_actor_id ON public.notifications USING btree (actor_id);


--
-- Name: index_notifications_on_journal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_journal_id ON public.notifications USING btree (journal_id);


--
-- Name: index_notifications_on_mail_alert_sent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_mail_alert_sent ON public.notifications USING btree (mail_alert_sent);


--
-- Name: index_notifications_on_mail_reminder_sent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_mail_reminder_sent ON public.notifications USING btree (mail_reminder_sent);


--
-- Name: index_notifications_on_read_ian; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_read_ian ON public.notifications USING btree (read_ian);


--
-- Name: index_notifications_on_recipient_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_recipient_id ON public.notifications USING btree (recipient_id);


--
-- Name: index_notifications_on_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_notifications_on_resource ON public.notifications USING btree (resource_type, resource_id);


--
-- Name: index_oauth_access_grants_on_application_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_access_grants_on_application_id ON public.oauth_access_grants USING btree (application_id);


--
-- Name: index_oauth_access_grants_on_resource_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_access_grants_on_resource_owner_id ON public.oauth_access_grants USING btree (resource_owner_id);


--
-- Name: index_oauth_access_grants_on_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_oauth_access_grants_on_token ON public.oauth_access_grants USING btree (token);


--
-- Name: index_oauth_access_tokens_on_application_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_access_tokens_on_application_id ON public.oauth_access_tokens USING btree (application_id);


--
-- Name: index_oauth_access_tokens_on_refresh_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_oauth_access_tokens_on_refresh_token ON public.oauth_access_tokens USING btree (refresh_token);


--
-- Name: index_oauth_access_tokens_on_resource_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_access_tokens_on_resource_owner_id ON public.oauth_access_tokens USING btree (resource_owner_id);


--
-- Name: index_oauth_access_tokens_on_token; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_oauth_access_tokens_on_token ON public.oauth_access_tokens USING btree (token);


--
-- Name: index_oauth_applications_on_integration; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_applications_on_integration ON public.oauth_applications USING btree (integration_type, integration_id);


--
-- Name: index_oauth_applications_on_owner_id_and_owner_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_applications_on_owner_id_and_owner_type ON public.oauth_applications USING btree (owner_id, owner_type);


--
-- Name: index_oauth_applications_on_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_oauth_applications_on_uid ON public.oauth_applications USING btree (uid);


--
-- Name: index_oauth_client_tokens_on_oauth_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_client_tokens_on_oauth_client_id ON public.oauth_client_tokens USING btree (oauth_client_id);


--
-- Name: index_oauth_client_tokens_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oauth_client_tokens_on_user_id ON public.oauth_client_tokens USING btree (user_id);


--
-- Name: index_oauth_client_tokens_on_user_id_and_oauth_client_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_oauth_client_tokens_on_user_id_and_oauth_client_id ON public.oauth_client_tokens USING btree (user_id, oauth_client_id);


--
-- Name: index_oauth_clients_on_integration; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_oauth_clients_on_integration ON public.oauth_clients USING btree (integration_type, integration_id);


--
-- Name: index_oidc_group_links_on_auth_provider_id_and_oidc_group_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_oidc_group_links_on_auth_provider_id_and_oidc_group_name ON public.oidc_group_links USING btree (auth_provider_id, oidc_group_name);


--
-- Name: index_oidc_group_links_on_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oidc_group_links_on_group_id ON public.oidc_group_links USING btree (group_id);


--
-- Name: index_oidc_group_memberships_on_group_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oidc_group_memberships_on_group_user_id ON public.oidc_group_memberships USING btree (group_user_id);


--
-- Name: index_oidc_user_session_links_on_oidc_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oidc_user_session_links_on_oidc_session ON public.oidc_user_session_links USING btree (oidc_session);


--
-- Name: index_oidc_user_session_links_on_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oidc_user_session_links_on_session_id ON public.oidc_user_session_links USING btree (session_id);


--
-- Name: index_oidc_user_tokens_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_oidc_user_tokens_on_user_id ON public.oidc_user_tokens USING btree (user_id);


--
-- Name: index_ordered_work_packages_on_position; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ordered_work_packages_on_position ON public.ordered_work_packages USING btree ("position");


--
-- Name: index_ordered_work_packages_on_query_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ordered_work_packages_on_query_id ON public.ordered_work_packages USING btree (query_id);


--
-- Name: index_ordered_work_packages_on_work_package_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_ordered_work_packages_on_work_package_id ON public.ordered_work_packages USING btree (work_package_id);


--
-- Name: index_paper_trail_audits_on_item_type_and_item_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_paper_trail_audits_on_item_type_and_item_id ON public.paper_trail_audits USING btree (item_type, item_id);


--
-- Name: index_project_cf_project_mappings_on_custom_field_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_project_cf_project_mappings_on_custom_field_id ON public.project_custom_field_project_mappings USING btree (custom_field_id);


--
-- Name: index_project_custom_field_project_mappings_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_project_custom_field_project_mappings_on_project_id ON public.project_custom_field_project_mappings USING btree (project_id);


--
-- Name: index_project_custom_field_project_mappings_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_project_custom_field_project_mappings_unique ON public.project_custom_field_project_mappings USING btree (project_id, custom_field_id);


--
-- Name: index_project_phase_definitions_on_color_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_project_phase_definitions_on_color_id ON public.project_phase_definitions USING btree (color_id);


--
-- Name: index_project_phase_definitions_on_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_project_phase_definitions_on_name ON public.project_phase_definitions USING btree (name);


--
-- Name: index_project_phase_journals_on_journal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_project_phase_journals_on_journal_id ON public.project_phase_journals USING btree (journal_id);


--
-- Name: index_project_phase_journals_on_phase_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_project_phase_journals_on_phase_id ON public.project_phase_journals USING btree (phase_id);


--
-- Name: index_project_phases_on_definition_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_project_phases_on_definition_id ON public.project_phases USING btree (definition_id);


--
-- Name: index_project_phases_on_finish_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_project_phases_on_finish_date ON public.project_phases USING btree (finish_date);


--
-- Name: index_project_phases_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_project_phases_on_project_id ON public.project_phases USING btree (project_id);


--
-- Name: index_project_phases_on_project_id_and_definition_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_project_phases_on_project_id_and_definition_id ON public.project_phases USING btree (project_id, definition_id);


--
-- Name: index_project_phases_on_start_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_project_phases_on_start_date ON public.project_phases USING btree (start_date);


--
-- Name: index_project_queries_on_public; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_project_queries_on_public ON public.project_queries USING btree (public);


--
-- Name: index_project_queries_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_project_queries_on_user_id ON public.project_queries USING btree (user_id);


--
-- Name: index_project_storages_on_creator_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_project_storages_on_creator_id ON public.project_storages USING btree (creator_id);


--
-- Name: index_project_storages_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_project_storages_on_project_id ON public.project_storages USING btree (project_id);


--
-- Name: index_project_storages_on_project_id_and_storage_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_project_storages_on_project_id_and_storage_id ON public.project_storages USING btree (project_id, storage_id);


--
-- Name: index_project_storages_on_storage_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_project_storages_on_storage_id ON public.project_storages USING btree (storage_id);


--
-- Name: index_projects_on_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_projects_on_active ON public.projects USING btree (active);


--
-- Name: index_projects_on_identifier; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_projects_on_identifier ON public.projects USING btree (identifier);


--
-- Name: index_projects_on_lft; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_projects_on_lft ON public.projects USING btree (lft);


--
-- Name: index_projects_on_lft_and_rgt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_projects_on_lft_and_rgt ON public.projects USING btree (lft, rgt);


--
-- Name: index_projects_on_rgt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_projects_on_rgt ON public.projects USING btree (rgt);


--
-- Name: index_projects_on_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_projects_on_template_id ON public.projects USING btree (template_id);


--
-- Name: index_projects_on_workspace_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_projects_on_workspace_type ON public.projects USING btree (workspace_type);


--
-- Name: index_queries_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_queries_on_project_id ON public.queries USING btree (project_id);


--
-- Name: index_queries_on_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_queries_on_updated_at ON public.queries USING btree (updated_at);


--
-- Name: index_queries_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_queries_on_user_id ON public.queries USING btree (user_id);


--
-- Name: index_recaptcha_entries_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_recaptcha_entries_on_user_id ON public.recaptcha_entries USING btree (user_id);


--
-- Name: index_recurring_meetings_on_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_recurring_meetings_on_author_id ON public.recurring_meetings USING btree (author_id);


--
-- Name: index_recurring_meetings_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_recurring_meetings_on_project_id ON public.recurring_meetings USING btree (project_id);


--
-- Name: index_recurring_meetings_on_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_recurring_meetings_on_uid ON public.recurring_meetings USING btree (uid);


--
-- Name: index_relations_on_from_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_relations_on_from_id ON public.relations USING btree (from_id);


--
-- Name: index_relations_on_from_id_and_to_id_and_relation_type; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_relations_on_from_id_and_to_id_and_relation_type ON public.relations USING btree (from_id, to_id, relation_type);


--
-- Name: index_relations_on_to_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_relations_on_to_id ON public.relations USING btree (to_id);


--
-- Name: index_relations_on_to_id_and_from_id_and_relation_type; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_relations_on_to_id_and_from_id_and_relation_type ON public.relations USING btree (to_id, from_id, relation_type);


--
-- Name: index_reminder_notifications_on_notification_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_reminder_notifications_on_notification_id ON public.reminder_notifications USING btree (notification_id);


--
-- Name: index_reminder_notifications_on_reminder_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_reminder_notifications_on_reminder_id ON public.reminder_notifications USING btree (reminder_id);


--
-- Name: index_reminder_notifications_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_reminder_notifications_unique ON public.reminder_notifications USING btree (notification_id);


--
-- Name: index_reminders_on_creator_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_reminders_on_creator_id ON public.reminders USING btree (creator_id);


--
-- Name: index_reminders_on_remindable; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_reminders_on_remindable ON public.reminders USING btree (remindable_type, remindable_id);


--
-- Name: index_remote_identities_on_auth_source_type_and_auth_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_remote_identities_on_auth_source_type_and_auth_source_id ON public.remote_identities USING btree (auth_source_type, auth_source_id);


--
-- Name: index_remote_identities_on_integration_type_and_integration_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_remote_identities_on_integration_type_and_integration_id ON public.remote_identities USING btree (integration_type, integration_id);


--
-- Name: index_repositories_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_repositories_on_project_id ON public.repositories USING btree (project_id);


--
-- Name: index_role_permissions_on_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_role_permissions_on_role_id ON public.role_permissions USING btree (role_id);


--
-- Name: index_roles_on_LOWER_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "index_roles_on_LOWER_name" ON public.roles USING btree (lower((name)::text));


--
-- Name: index_scheduled_meetings_on_meeting_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_scheduled_meetings_on_meeting_id ON public.scheduled_meetings USING btree (meeting_id);


--
-- Name: index_scheduled_meetings_on_recurring_meeting_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_scheduled_meetings_on_recurring_meeting_id ON public.scheduled_meetings USING btree (recurring_meeting_id);


--
-- Name: index_scim_clients_on_auth_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_scim_clients_on_auth_provider_id ON public.scim_clients USING btree (auth_provider_id);


--
-- Name: index_service_account_associations_on_service_account_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_service_account_associations_on_service_account_id ON public.service_account_associations USING btree (service_account_id);


--
-- Name: index_sessions_on_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_sessions_on_session_id ON public.sessions USING btree (session_id);


--
-- Name: index_sessions_on_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_sessions_on_updated_at ON public.sessions USING btree (updated_at);


--
-- Name: index_sessions_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_sessions_on_user_id ON public.sessions USING btree (user_id);


--
-- Name: index_settings_on_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_settings_on_name ON public.settings USING btree (name);


--
-- Name: index_statuses_on_LOWER_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "index_statuses_on_LOWER_name" ON public.statuses USING btree (lower((name)::text));


--
-- Name: index_statuses_on_color_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_statuses_on_color_id ON public.statuses USING btree (color_id);


--
-- Name: index_statuses_on_is_closed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_statuses_on_is_closed ON public.statuses USING btree (is_closed);


--
-- Name: index_statuses_on_is_default; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_statuses_on_is_default ON public.statuses USING btree (is_default);


--
-- Name: index_statuses_on_position; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_statuses_on_position ON public.statuses USING btree ("position");


--
-- Name: index_storages_file_links_journals_on_file_link_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_storages_file_links_journals_on_file_link_id ON public.storages_file_links_journals USING btree (file_link_id);


--
-- Name: index_storages_file_links_journals_on_journal_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_storages_file_links_journals_on_journal_id ON public.storages_file_links_journals USING btree (journal_id);


--
-- Name: index_storages_on_LOWER_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "index_storages_on_LOWER_name" ON public.storages USING btree (lower((name)::text));


--
-- Name: index_storages_on_creator_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_storages_on_creator_id ON public.storages USING btree (creator_id);


--
-- Name: index_storages_on_host; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_storages_on_host ON public.storages USING btree (host);


--
-- Name: index_storages_on_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_storages_on_name ON public.storages USING btree (name);


--
-- Name: index_subproject_template_assignments_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_subproject_template_assignments_on_project_id ON public.subproject_template_assignments USING btree (project_id);


--
-- Name: index_subproject_template_assignments_on_template_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_subproject_template_assignments_on_template_id ON public.subproject_template_assignments USING btree (template_id);


--
-- Name: index_subproject_template_assignments_on_workspace_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_subproject_template_assignments_on_workspace_type ON public.subproject_template_assignments USING btree (workspace_type);


--
-- Name: index_teap_on_project_id_and_activity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_teap_on_project_id_and_activity_id ON public.time_entry_activities_projects USING btree (project_id, activity_id);


--
-- Name: index_time_entries_on_activity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entries_on_activity_id ON public.time_entries USING btree (activity_id);


--
-- Name: index_time_entries_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entries_on_created_at ON public.time_entries USING btree (created_at);


--
-- Name: index_time_entries_on_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entries_on_entity ON public.time_entries USING btree (entity_type, entity_id);


--
-- Name: index_time_entries_on_entity_type_and_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entries_on_entity_type_and_entity_id ON public.time_entries USING btree (entity_type, entity_id);


--
-- Name: index_time_entries_on_logged_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entries_on_logged_by_id ON public.time_entries USING btree (logged_by_id);


--
-- Name: index_time_entries_on_ongoing; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entries_on_ongoing ON public.time_entries USING btree (ongoing);


--
-- Name: index_time_entries_on_project_id_and_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entries_on_project_id_and_updated_at ON public.time_entries USING btree (project_id, updated_at);


--
-- Name: index_time_entries_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entries_on_user_id ON public.time_entries USING btree (user_id);


--
-- Name: index_time_entries_on_user_id_and_ongoing; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_time_entries_on_user_id_and_ongoing ON public.time_entries USING btree (user_id, ongoing) WHERE (ongoing = true);


--
-- Name: index_time_entry_activities_projects_on_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entry_activities_projects_on_active ON public.time_entry_activities_projects USING btree (active);


--
-- Name: index_time_entry_activities_projects_on_activity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entry_activities_projects_on_activity_id ON public.time_entry_activities_projects USING btree (activity_id);


--
-- Name: index_time_entry_activities_projects_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entry_activities_projects_on_project_id ON public.time_entry_activities_projects USING btree (project_id);


--
-- Name: index_time_entry_journals_on_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entry_journals_on_entity ON public.time_entry_journals USING btree (entity_type, entity_id);


--
-- Name: index_time_entry_journals_on_entity_type_and_entity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entry_journals_on_entity_type_and_entity_id ON public.time_entry_journals USING btree (entity_type, entity_id);


--
-- Name: index_time_entry_journals_on_logged_by_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entry_journals_on_logged_by_id ON public.time_entry_journals USING btree (logged_by_id);


--
-- Name: index_time_entry_journals_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_time_entry_journals_on_project_id ON public.time_entry_journals USING btree (project_id);


--
-- Name: index_tokens_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_tokens_on_user_id ON public.tokens USING btree (user_id);


--
-- Name: index_two_factor_authentication_devices_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_two_factor_authentication_devices_on_user_id ON public.two_factor_authentication_devices USING btree (user_id);


--
-- Name: index_two_factor_authentication_devices_on_webauthn_external_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_two_factor_authentication_devices_on_webauthn_external_id ON public.two_factor_authentication_devices USING btree (webauthn_external_id);


--
-- Name: index_types_on_LOWER_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "index_types_on_LOWER_name" ON public.types USING btree (lower((name)::text));


--
-- Name: index_types_on_color_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_types_on_color_id ON public.types USING btree (color_id);


--
-- Name: index_unique_calc_val_error_per_customized_and_cf; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_unique_calc_val_error_per_customized_and_cf ON public.calculated_value_errors USING btree (customized_type, customized_id, custom_field_id, error_code);


--
-- Name: index_user_auth_provider_links_on_auth_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_auth_provider_links_on_auth_provider_id ON public.user_auth_provider_links USING btree (auth_provider_id);


--
-- Name: index_user_auth_provider_links_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_auth_provider_links_on_user_id ON public.user_auth_provider_links USING btree (user_id);


--
-- Name: index_user_auth_provider_links_on_user_id_and_auth_provider_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_user_auth_provider_links_on_user_id_and_auth_provider_id ON public.user_auth_provider_links USING btree (user_id, auth_provider_id);


--
-- Name: index_user_passwords_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_passwords_on_user_id ON public.user_passwords USING btree (user_id);


--
-- Name: index_user_preferences_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_user_preferences_on_user_id ON public.user_preferences USING btree (user_id);


--
-- Name: index_user_prefs_settings_daily_reminders_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_prefs_settings_daily_reminders_enabled ON public.user_preferences USING gin ((((settings -> 'daily_reminders'::text) -> 'enabled'::text)));


--
-- Name: index_user_prefs_settings_daily_reminders_times; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_prefs_settings_daily_reminders_times ON public.user_preferences USING gin ((((settings -> 'daily_reminders'::text) -> 'times'::text)));


--
-- Name: index_user_prefs_settings_pause_reminders_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_prefs_settings_pause_reminders_enabled ON public.user_preferences USING btree (((((settings -> 'pause_reminders'::text) ->> 'enabled'::text))::boolean));


--
-- Name: index_user_prefs_settings_time_zone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_prefs_settings_time_zone ON public.user_preferences USING gin (((settings -> 'time_zone'::text)));


--
-- Name: index_user_prefs_settings_workdays; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_user_prefs_settings_workdays ON public.user_preferences USING gin (((settings -> 'workdays'::text)));


--
-- Name: index_users_on_id_and_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_id_and_type ON public.users USING btree (id, type);


--
-- Name: index_users_on_ldap_auth_source_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_ldap_auth_source_id ON public.users USING btree (ldap_auth_source_id);


--
-- Name: index_users_on_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_type ON public.users USING btree (type);


--
-- Name: index_users_on_type_and_login; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_type_and_login ON public.users USING btree (type, login);


--
-- Name: index_users_on_type_and_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_users_on_type_and_status ON public.users USING btree (type, status);


--
-- Name: index_version_settings_on_project_id_and_version_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_version_settings_on_project_id_and_version_id ON public.version_settings USING btree (project_id, version_id);


--
-- Name: index_versions_on_project_id_and_LOWER_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "index_versions_on_project_id_and_LOWER_name" ON public.versions USING btree (project_id, lower((name)::text));


--
-- Name: index_versions_on_sharing; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_versions_on_sharing ON public.versions USING btree (sharing);


--
-- Name: index_views_on_query_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_views_on_query_id ON public.views USING btree (query_id);


--
-- Name: index_watchers_on_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_watchers_on_user_id ON public.watchers USING btree (user_id);


--
-- Name: index_watchers_on_user_id_and_watchable; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX index_watchers_on_user_id_and_watchable ON public.watchers USING btree (user_id, watchable_type, watchable_id);


--
-- Name: index_watchers_on_watchable_id_and_watchable_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_watchers_on_watchable_id_and_watchable_type ON public.watchers USING btree (watchable_id, watchable_type);


--
-- Name: index_webhooks_events_on_webhooks_webhook_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_webhooks_events_on_webhooks_webhook_id ON public.webhooks_events USING btree (webhooks_webhook_id);


--
-- Name: index_webhooks_logs_on_webhooks_webhook_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_webhooks_logs_on_webhooks_webhook_id ON public.webhooks_logs USING btree (webhooks_webhook_id);


--
-- Name: index_webhooks_projects_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_webhooks_projects_on_project_id ON public.webhooks_projects USING btree (project_id);


--
-- Name: index_webhooks_projects_on_webhooks_webhook_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_webhooks_projects_on_webhooks_webhook_id ON public.webhooks_projects USING btree (webhooks_webhook_id);


--
-- Name: index_webhooks_webhooks_on_LOWER_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "index_webhooks_webhooks_on_LOWER_name" ON public.webhooks_webhooks USING btree (lower((name)::text));


--
-- Name: index_wiki_pages_on_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_wiki_pages_on_author_id ON public.wiki_pages USING btree (author_id);


--
-- Name: index_wiki_pages_on_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_wiki_pages_on_parent_id ON public.wiki_pages USING btree (parent_id);


--
-- Name: index_wiki_pages_on_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_wiki_pages_on_updated_at ON public.wiki_pages USING btree (updated_at);


--
-- Name: index_wiki_pages_on_wiki_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_wiki_pages_on_wiki_id ON public.wiki_pages USING btree (wiki_id);


--
-- Name: index_wiki_redirects_on_wiki_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_wiki_redirects_on_wiki_id ON public.wiki_redirects USING btree (wiki_id);


--
-- Name: index_work_package_journals_on_assigned_to_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_package_journals_on_assigned_to_id ON public.work_package_journals USING btree (assigned_to_id);


--
-- Name: index_work_package_journals_on_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_package_journals_on_author_id ON public.work_package_journals USING btree (author_id);


--
-- Name: index_work_package_journals_on_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_package_journals_on_category_id ON public.work_package_journals USING btree (category_id);


--
-- Name: index_work_package_journals_on_due_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_package_journals_on_due_date ON public.work_package_journals USING btree (due_date);


--
-- Name: index_work_package_journals_on_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_package_journals_on_parent_id ON public.work_package_journals USING btree (parent_id);


--
-- Name: index_work_package_journals_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_package_journals_on_project_id ON public.work_package_journals USING btree (project_id);


--
-- Name: index_work_package_journals_on_responsible_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_package_journals_on_responsible_id ON public.work_package_journals USING btree (responsible_id);


--
-- Name: index_work_package_journals_on_schedule_manually; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_package_journals_on_schedule_manually ON public.work_package_journals USING btree (schedule_manually);


--
-- Name: index_work_package_journals_on_start_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_package_journals_on_start_date ON public.work_package_journals USING btree (start_date);


--
-- Name: index_work_package_journals_on_status_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_package_journals_on_status_id ON public.work_package_journals USING btree (status_id);


--
-- Name: index_work_package_journals_on_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_package_journals_on_type_id ON public.work_package_journals USING btree (type_id);


--
-- Name: index_work_package_journals_on_version_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_package_journals_on_version_id ON public.work_package_journals USING btree (version_id);


--
-- Name: index_work_packages_on_assigned_to_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_assigned_to_id ON public.work_packages USING btree (assigned_to_id);


--
-- Name: index_work_packages_on_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_author_id ON public.work_packages USING btree (author_id);


--
-- Name: index_work_packages_on_category_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_category_id ON public.work_packages USING btree (category_id);


--
-- Name: index_work_packages_on_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_created_at ON public.work_packages USING btree (created_at);


--
-- Name: index_work_packages_on_due_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_due_date ON public.work_packages USING btree (due_date);


--
-- Name: index_work_packages_on_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_parent_id ON public.work_packages USING btree (parent_id);


--
-- Name: index_work_packages_on_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_project_id ON public.work_packages USING btree (project_id);


--
-- Name: index_work_packages_on_project_id_and_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_project_id_and_updated_at ON public.work_packages USING btree (project_id, updated_at);


--
-- Name: index_work_packages_on_project_phase_definition_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_project_phase_definition_id ON public.work_packages USING btree (project_phase_definition_id);


--
-- Name: index_work_packages_on_responsible_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_responsible_id ON public.work_packages USING btree (responsible_id);


--
-- Name: index_work_packages_on_schedule_manually; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_schedule_manually ON public.work_packages USING btree (schedule_manually) WHERE schedule_manually;


--
-- Name: index_work_packages_on_start_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_start_date ON public.work_packages USING btree (start_date);


--
-- Name: index_work_packages_on_status_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_status_id ON public.work_packages USING btree (status_id);


--
-- Name: index_work_packages_on_type_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_type_id ON public.work_packages USING btree (type_id);


--
-- Name: index_work_packages_on_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_updated_at ON public.work_packages USING btree (updated_at);


--
-- Name: index_work_packages_on_version_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_work_packages_on_version_id ON public.work_packages USING btree (version_id);


--
-- Name: index_workflows_on_new_status_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_workflows_on_new_status_id ON public.workflows USING btree (new_status_id);


--
-- Name: index_workflows_on_old_status_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_workflows_on_old_status_id ON public.workflows USING btree (old_status_id);


--
-- Name: index_workflows_on_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_workflows_on_role_id ON public.workflows USING btree (role_id);


--
-- Name: issue_categories_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX issue_categories_project_id ON public.categories USING btree (project_id);


--
-- Name: item_anc_desc_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX item_anc_desc_idx ON public.hierarchical_item_hierarchies USING btree (ancestor_id, descendant_id, generations);


--
-- Name: item_desc_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX item_desc_idx ON public.hierarchical_item_hierarchies USING btree (descendant_id);


--
-- Name: messages_board_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_board_id ON public.messages USING btree (forum_id);


--
-- Name: messages_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX messages_parent_id ON public.messages USING btree (parent_id);


--
-- Name: news_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX news_project_id ON public.news USING btree (project_id);


--
-- Name: projects_types_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX projects_types_project_id ON public.projects_types USING btree (project_id);


--
-- Name: projects_types_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX projects_types_unique ON public.projects_types USING btree (project_id, type_id);


--
-- Name: time_entries_issue_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX time_entries_issue_id ON public.time_entries USING btree (work_package_id);


--
-- Name: time_entries_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX time_entries_project_id ON public.time_entries USING btree (project_id);


--
-- Name: unique_index_gh_prs_wps_on_gh_pr_id_and_wp_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_index_gh_prs_wps_on_gh_pr_id_and_wp_id ON public.github_pull_requests_work_packages USING btree (github_pull_request_id, work_package_id);


--
-- Name: unique_index_gl_issues_wps_on_gl_issue_id_and_wp_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_index_gl_issues_wps_on_gl_issue_id_and_wp_id ON public.gitlab_issues_work_packages USING btree (gitlab_issue_id, work_package_id);


--
-- Name: unique_index_gl_mrs_wps_on_gl_mr_id_and_wp_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_index_gl_mrs_wps_on_gl_mr_id_and_wp_id ON public.gitlab_merge_requests_work_packages USING btree (gitlab_merge_request_id, work_package_id);


--
-- Name: unique_inherited_role; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_inherited_role ON public.member_roles USING btree (member_id, role_id, inherited_from);


--
-- Name: unique_lastname_for_groups_and_placeholder_users; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unique_lastname_for_groups_and_placeholder_users ON public.users USING btree (lastname, type) WHERE (((type)::text = 'Group'::text) OR ((type)::text = 'PlaceholderUser'::text));


--
-- Name: versions_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX versions_project_id ON public.versions USING btree (project_id);


--
-- Name: watchers_user_id_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX watchers_user_id_type ON public.watchers USING btree (user_id, watchable_type);


--
-- Name: wiki_pages_wiki_id_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX wiki_pages_wiki_id_slug ON public.wiki_pages USING btree (wiki_id, slug);


--
-- Name: wiki_pages_wiki_id_title; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wiki_pages_wiki_id_title ON public.wiki_pages USING btree (wiki_id, title);


--
-- Name: wiki_redirects_wiki_id_title; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wiki_redirects_wiki_id_title ON public.wiki_redirects USING btree (wiki_id, title);


--
-- Name: wikis_project_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wikis_project_id ON public.wikis USING btree (project_id);


--
-- Name: wkfs_role_type_old_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX wkfs_role_type_old_status ON public.workflows USING btree (role_id, type_id, old_status_id);


--
-- Name: work_package_anc_desc_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX work_package_anc_desc_idx ON public.work_package_hierarchies USING btree (ancestor_id, descendant_id, generations);


--
-- Name: work_package_desc_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_package_desc_idx ON public.work_package_hierarchies USING btree (descendant_id);


--
-- Name: work_package_journal_on_burndown_attributes; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_package_journal_on_burndown_attributes ON public.work_package_journals USING btree (version_id, status_id, project_id, type_id);


--
-- Name: project_storages fk_rails_04546d7b88; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_storages
    ADD CONSTRAINT fk_rails_04546d7b88 FOREIGN KEY (storage_id) REFERENCES public.storages(id) ON DELETE CASCADE;


--
-- Name: bcf_comments fk_rails_0571c4b386; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_comments
    ADD CONSTRAINT fk_rails_0571c4b386 FOREIGN KEY (reply_to) REFERENCES public.bcf_comments(id) ON DELETE SET NULL;


--
-- Name: oidc_group_memberships fk_rails_061b856d2a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_group_memberships
    ADD CONSTRAINT fk_rails_061b856d2a FOREIGN KEY (group_user_id) REFERENCES public.group_users(id) ON DELETE CASCADE;


--
-- Name: notifications fk_rails_06a39bb8cc; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_rails_06a39bb8cc FOREIGN KEY (actor_id) REFERENCES public.users(id);


--
-- Name: meeting_agenda_items fk_rails_06b94602d9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_agenda_items
    ADD CONSTRAINT fk_rails_06b94602d9 FOREIGN KEY (presenter_id) REFERENCES public.users(id);


--
-- Name: two_factor_authentication_devices fk_rails_0b09e132e7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.two_factor_authentication_devices
    ADD CONSTRAINT fk_rails_0b09e132e7 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: workflows fk_rails_0c5f149c21; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT fk_rails_0c5f149c21 FOREIGN KEY (role_id) REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notification_settings fk_rails_0c95e91db7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT fk_rails_0c95e91db7 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: project_phase_definitions fk_rails_0cd5e50674; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_phase_definitions
    ADD CONSTRAINT fk_rails_0cd5e50674 FOREIGN KEY (color_id) REFERENCES public.colors(id);


--
-- Name: cost_entries fk_rails_0d35f09506; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_entries
    ADD CONSTRAINT fk_rails_0d35f09506 FOREIGN KEY (logged_by_id) REFERENCES public.users(id);


--
-- Name: project_phase_journals fk_rails_0e71534908; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_phase_journals
    ADD CONSTRAINT fk_rails_0e71534908 FOREIGN KEY (journal_id) REFERENCES public.journals(id);


--
-- Name: oidc_group_links fk_rails_0ed529eb13; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_group_links
    ADD CONSTRAINT fk_rails_0ed529eb13 FOREIGN KEY (auth_provider_id) REFERENCES public.auth_providers(id) ON DELETE CASCADE;


--
-- Name: custom_fields_projects fk_rails_12fb30588e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_fields_projects
    ADD CONSTRAINT fk_rails_12fb30588e FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: oidc_user_tokens fk_rails_1571e35480; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_user_tokens
    ADD CONSTRAINT fk_rails_1571e35480 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: service_account_associations fk_rails_18733515b3; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_account_associations
    ADD CONSTRAINT fk_rails_18733515b3 FOREIGN KEY (service_account_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: project_custom_field_project_mappings fk_rails_1a1f3f10e9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_custom_field_project_mappings
    ADD CONSTRAINT fk_rails_1a1f3f10e9 FOREIGN KEY (custom_field_id) REFERENCES public.custom_fields(id);


--
-- Name: workflows fk_rails_2a8f410364; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT fk_rails_2a8f410364 FOREIGN KEY (type_id) REFERENCES public.types(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: recurring_meeting_interim_responses fk_rails_2bc91bc636; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recurring_meeting_interim_responses
    ADD CONSTRAINT fk_rails_2bc91bc636 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: oauth_applications fk_rails_3d1f3b58d2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_applications
    ADD CONSTRAINT fk_rails_3d1f3b58d2 FOREIGN KEY (client_credentials_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: meeting_agenda_items fk_rails_3f56abf49c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_agenda_items
    ADD CONSTRAINT fk_rails_3f56abf49c FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: wiki_pages fk_rails_4189064f3f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wiki_pages
    ADD CONSTRAINT fk_rails_4189064f3f FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: reminder_notifications fk_rails_4398e72474; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reminder_notifications
    ADD CONSTRAINT fk_rails_4398e72474 FOREIGN KEY (reminder_id) REFERENCES public.reminders(id);


--
-- Name: ldap_groups_synchronized_groups fk_rails_44dac1537e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ldap_groups_synchronized_groups
    ADD CONSTRAINT fk_rails_44dac1537e FOREIGN KEY (filter_id) REFERENCES public.ldap_groups_synchronized_filters(id);


--
-- Name: types fk_rails_46ceaf0e5b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.types
    ADD CONSTRAINT fk_rails_46ceaf0e5b FOREIGN KEY (color_id) REFERENCES public.colors(id) ON DELETE SET NULL;


--
-- Name: notification_settings fk_rails_496a500fda; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_settings
    ADD CONSTRAINT fk_rails_496a500fda FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: notifications fk_rails_4aea6afa11; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_rails_4aea6afa11 FOREIGN KEY (recipient_id) REFERENCES public.users(id);


--
-- Name: reminder_notifications fk_rails_4db3d8d95d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reminder_notifications
    ADD CONSTRAINT fk_rails_4db3d8d95d FOREIGN KEY (notification_id) REFERENCES public.notifications(id);


--
-- Name: export_settings fk_rails_4e2ea236a3; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.export_settings
    ADD CONSTRAINT fk_rails_4e2ea236a3 FOREIGN KEY (query_id) REFERENCES public.queries(id);


--
-- Name: bcf_issues fk_rails_4e35bc3056; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_issues
    ADD CONSTRAINT fk_rails_4e35bc3056 FOREIGN KEY (work_package_id) REFERENCES public.work_packages(id) ON DELETE CASCADE;


--
-- Name: ifc_models fk_rails_4f53d4601c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ifc_models
    ADD CONSTRAINT fk_rails_4f53d4601c FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: meeting_outcomes fk_rails_53dfa07660; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_outcomes
    ADD CONSTRAINT fk_rails_53dfa07660 FOREIGN KEY (work_package_id) REFERENCES public.work_packages(id);


--
-- Name: webhooks_logs fk_rails_551257cdac; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_logs
    ADD CONSTRAINT fk_rails_551257cdac FOREIGN KEY (webhooks_webhook_id) REFERENCES public.webhooks_webhooks(id) ON DELETE CASCADE;


--
-- Name: bcf_comments fk_rails_556ef6e73e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_comments
    ADD CONSTRAINT fk_rails_556ef6e73e FOREIGN KEY (viewpoint_id) REFERENCES public.bcf_viewpoints(id) ON DELETE SET NULL;


--
-- Name: notifications fk_rails_595318131c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_rails_595318131c FOREIGN KEY (journal_id) REFERENCES public.journals(id) ON DELETE CASCADE;


--
-- Name: time_entry_activities_projects fk_rails_5b669d4f34; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entry_activities_projects
    ADD CONSTRAINT fk_rails_5b669d4f34 FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: oidc_user_session_links fk_rails_5e6a849f92; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_user_session_links
    ADD CONSTRAINT fk_rails_5e6a849f92 FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: work_packages fk_rails_5edb6f06e6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_packages
    ADD CONSTRAINT fk_rails_5edb6f06e6 FOREIGN KEY (status_id) REFERENCES public.statuses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: documents fk_rails_5fe3b44db5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT fk_rails_5fe3b44db5 FOREIGN KEY (type_id) REFERENCES public.document_types(id);


--
-- Name: meeting_sections fk_rails_613c652e16; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_sections
    ADD CONSTRAINT fk_rails_613c652e16 FOREIGN KEY (meeting_id) REFERENCES public.meetings(id);


--
-- Name: file_links fk_rails_650ebb2e1a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_links
    ADD CONSTRAINT fk_rails_650ebb2e1a FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: oauth_client_tokens fk_rails_65a92bfbf4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client_tokens
    ADD CONSTRAINT fk_rails_65a92bfbf4 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: project_phases fk_rails_664dd6ae3c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_phases
    ADD CONSTRAINT fk_rails_664dd6ae3c FOREIGN KEY (definition_id) REFERENCES public.project_phase_definitions(id);


--
-- Name: workflows fk_rails_66af376b7e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT fk_rails_66af376b7e FOREIGN KEY (new_status_id) REFERENCES public.statuses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: storages fk_rails_6c69bacb8d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storages
    ADD CONSTRAINT fk_rails_6c69bacb8d FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: oauth_client_tokens fk_rails_6e922d4135; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_client_tokens
    ADD CONSTRAINT fk_rails_6e922d4135 FOREIGN KEY (oauth_client_id) REFERENCES public.oauth_clients(id) ON DELETE CASCADE;


--
-- Name: scim_clients fk_rails_705242b5b2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scim_clients
    ADD CONSTRAINT fk_rails_705242b5b2 FOREIGN KEY (auth_provider_id) REFERENCES public.auth_providers(id) ON DELETE RESTRICT;


--
-- Name: time_entries fk_rails_709864c72f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT fk_rails_709864c72f FOREIGN KEY (logged_by_id) REFERENCES public.users(id);


--
-- Name: recurring_meetings fk_rails_718ca7b915; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recurring_meetings
    ADD CONSTRAINT fk_rails_718ca7b915 FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: oauth_access_tokens fk_rails_732cb83ab7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_tokens
    ADD CONSTRAINT fk_rails_732cb83ab7 FOREIGN KEY (application_id) REFERENCES public.oauth_applications(id);


--
-- Name: last_project_folders fk_rails_73e1c678f1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.last_project_folders
    ADD CONSTRAINT fk_rails_73e1c678f1 FOREIGN KEY (project_storage_id) REFERENCES public.project_storages(id) ON DELETE CASCADE;


--
-- Name: project_custom_field_project_mappings fk_rails_79aa0057e4; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_custom_field_project_mappings
    ADD CONSTRAINT fk_rails_79aa0057e4 FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: bcf_comments fk_rails_7ac870008c; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_comments
    ADD CONSTRAINT fk_rails_7ac870008c FOREIGN KEY (issue_id) REFERENCES public.bcf_issues(id) ON DELETE CASCADE;


--
-- Name: projects_types fk_rails_7c3935a107; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects_types
    ADD CONSTRAINT fk_rails_7c3935a107 FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: project_phases fk_rails_7c456fca1d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_phases
    ADD CONSTRAINT fk_rails_7c456fca1d FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: remote_identities fk_rails_7f8585fc1a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.remote_identities
    ADD CONSTRAINT fk_rails_7f8585fc1a FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: emoji_reactions fk_rails_80a9e7c3ce; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.emoji_reactions
    ADD CONSTRAINT fk_rails_80a9e7c3ce FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: recaptcha_entries fk_rails_890a90efa9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recaptcha_entries
    ADD CONSTRAINT fk_rails_890a90efa9 FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: oidc_group_links fk_rails_8d031325e2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_group_links
    ADD CONSTRAINT fk_rails_8d031325e2 FOREIGN KEY (group_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: calculated_value_errors fk_rails_8e54029654; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calculated_value_errors
    ADD CONSTRAINT fk_rails_8e54029654 FOREIGN KEY (custom_field_id) REFERENCES public.custom_fields(id);


--
-- Name: meeting_agenda_items fk_rails_9089886cdd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_agenda_items
    ADD CONSTRAINT fk_rails_9089886cdd FOREIGN KEY (meeting_id) REFERENCES public.meetings(id);


--
-- Name: work_packages fk_rails_931ad309e8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_packages
    ADD CONSTRAINT fk_rails_931ad309e8 FOREIGN KEY (project_id) REFERENCES public.projects(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: autologin_session_links fk_rails_93f00f2aab; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.autologin_session_links
    ADD CONSTRAINT fk_rails_93f00f2aab FOREIGN KEY (token_id) REFERENCES public.tokens(id) ON DELETE CASCADE;


--
-- Name: custom_fields_roles fk_rails_950d979cb9; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_fields_roles
    ADD CONSTRAINT fk_rails_950d979cb9 FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: project_storages fk_rails_96ab713fe3; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_storages
    ADD CONSTRAINT fk_rails_96ab713fe3 FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: custom_fields_roles fk_rails_96bf507f15; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_fields_roles
    ADD CONSTRAINT fk_rails_96bf507f15 FOREIGN KEY (custom_field_id) REFERENCES public.custom_fields(id);


--
-- Name: projects fk_rails_9702eec5cd; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT fk_rails_9702eec5cd FOREIGN KEY (template_id) REFERENCES public.projects(id);


--
-- Name: user_auth_provider_links fk_rails_9a2c7082f0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_auth_provider_links
    ADD CONSTRAINT fk_rails_9a2c7082f0 FOREIGN KEY (user_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: meeting_agenda_item_journals fk_rails_9b6296a185; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_agenda_item_journals
    ADD CONSTRAINT fk_rails_9b6296a185 FOREIGN KEY (presenter_id) REFERENCES public.users(id);


--
-- Name: meeting_outcomes fk_rails_9f4a5cc9ed; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_outcomes
    ADD CONSTRAINT fk_rails_9f4a5cc9ed FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: recurring_meetings fk_rails_a0ea141e10; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recurring_meetings
    ADD CONSTRAINT fk_rails_a0ea141e10 FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: webhooks_events fk_rails_a166925c91; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_events
    ADD CONSTRAINT fk_rails_a166925c91 FOREIGN KEY (webhooks_webhook_id) REFERENCES public.webhooks_webhooks(id);


--
-- Name: file_links fk_rails_a29c1fb981; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file_links
    ADD CONSTRAINT fk_rails_a29c1fb981 FOREIGN KEY (storage_id) REFERENCES public.storages(id) ON DELETE CASCADE;


--
-- Name: user_auth_provider_links fk_rails_aae2d958bb; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_auth_provider_links
    ADD CONSTRAINT fk_rails_aae2d958bb FOREIGN KEY (auth_provider_id) REFERENCES public.auth_providers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tokens fk_rails_ac8a5d0441; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tokens
    ADD CONSTRAINT fk_rails_ac8a5d0441 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: project_storages fk_rails_acca00a591; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_storages
    ADD CONSTRAINT fk_rails_acca00a591 FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: subproject_template_assignments fk_rails_b15b68fdaf; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subproject_template_assignments
    ADD CONSTRAINT fk_rails_b15b68fdaf FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: workflows fk_rails_b4628cffdf; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT fk_rails_b4628cffdf FOREIGN KEY (old_status_id) REFERENCES public.statuses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: oauth_access_grants fk_rails_b4b53e07b8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_access_grants
    ADD CONSTRAINT fk_rails_b4b53e07b8 FOREIGN KEY (application_id) REFERENCES public.oauth_applications(id);


--
-- Name: reminders fk_rails_b7e32f12b2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reminders
    ADD CONSTRAINT fk_rails_b7e32f12b2 FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: time_entry_activities_projects fk_rails_bc6c409022; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entry_activities_projects
    ADD CONSTRAINT fk_rails_bc6c409022 FOREIGN KEY (activity_id) REFERENCES public.enumerations(id);


--
-- Name: hierarchical_items fk_rails_c67cbe751d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hierarchical_items
    ADD CONSTRAINT fk_rails_c67cbe751d FOREIGN KEY (custom_field_id) REFERENCES public.custom_fields(id);


--
-- Name: scheduled_meetings fk_rails_c79817dc8f; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_meetings
    ADD CONSTRAINT fk_rails_c79817dc8f FOREIGN KEY (meeting_id) REFERENCES public.meetings(id) ON DELETE SET NULL;


--
-- Name: oauth_applications fk_rails_cc886e315a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_applications
    ADD CONSTRAINT fk_rails_cc886e315a FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: recurring_meeting_interim_responses fk_rails_cd46c27804; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recurring_meeting_interim_responses
    ADD CONSTRAINT fk_rails_cd46c27804 FOREIGN KEY (recurring_meeting_id) REFERENCES public.recurring_meetings(id);


--
-- Name: oidc_group_memberships fk_rails_cefb836ee1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_group_memberships
    ADD CONSTRAINT fk_rails_cefb836ee1 FOREIGN KEY (auth_provider_id) REFERENCES public.auth_providers(id) ON DELETE CASCADE;


--
-- Name: favorites fk_rails_d15744e438; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.favorites
    ADD CONSTRAINT fk_rails_d15744e438 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: webhooks_projects fk_rails_d7ea5de5b8; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_projects
    ADD CONSTRAINT fk_rails_d7ea5de5b8 FOREIGN KEY (webhooks_webhook_id) REFERENCES public.webhooks_webhooks(id);


--
-- Name: meeting_outcomes fk_rails_d89fa3e833; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.meeting_outcomes
    ADD CONSTRAINT fk_rails_d89fa3e833 FOREIGN KEY (meeting_agenda_item_id) REFERENCES public.meeting_agenda_items(id);


--
-- Name: projects_types fk_rails_da213a0c8b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects_types
    ADD CONSTRAINT fk_rails_da213a0c8b FOREIGN KEY (type_id) REFERENCES public.types(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subproject_template_assignments fk_rails_db83d82aa3; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subproject_template_assignments
    ADD CONSTRAINT fk_rails_db83d82aa3 FOREIGN KEY (template_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: scheduled_meetings fk_rails_dde1b994c5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scheduled_meetings
    ADD CONSTRAINT fk_rails_dde1b994c5 FOREIGN KEY (recurring_meeting_id) REFERENCES public.recurring_meetings(id) ON DELETE CASCADE;


--
-- Name: storages_file_links_journals fk_rails_e007095e78; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storages_file_links_journals
    ADD CONSTRAINT fk_rails_e007095e78 FOREIGN KEY (journal_id) REFERENCES public.journals(id);


--
-- Name: ical_token_query_assignments fk_rails_e0ecbb71e6; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ical_token_query_assignments
    ADD CONSTRAINT fk_rails_e0ecbb71e6 FOREIGN KEY (ical_token_id) REFERENCES public.tokens(id) ON DELETE CASCADE;


--
-- Name: custom_fields_projects fk_rails_e51cefe60d; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_fields_projects
    ADD CONSTRAINT fk_rails_e51cefe60d FOREIGN KEY (custom_field_id) REFERENCES public.custom_fields(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: webhooks_projects fk_rails_e978b5e3d7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks_projects
    ADD CONSTRAINT fk_rails_e978b5e3d7 FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: ordered_work_packages fk_rails_e99c4d5dfe; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordered_work_packages
    ADD CONSTRAINT fk_rails_e99c4d5dfe FOREIGN KEY (query_id) REFERENCES public.queries(id) ON DELETE CASCADE;


--
-- Name: auth_providers fk_rails_e9bd348863; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_providers
    ADD CONSTRAINT fk_rails_e9bd348863 FOREIGN KEY (creator_id) REFERENCES public.users(id);


--
-- Name: views fk_rails_ef3c430897; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.views
    ADD CONSTRAINT fk_rails_ef3c430897 FOREIGN KEY (query_id) REFERENCES public.queries(id);


--
-- Name: work_packages fk_rails_f2a8977aa1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_packages
    ADD CONSTRAINT fk_rails_f2a8977aa1 FOREIGN KEY (type_id) REFERENCES public.types(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ical_token_query_assignments fk_rails_f5e934437b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ical_token_query_assignments
    ADD CONSTRAINT fk_rails_f5e934437b FOREIGN KEY (query_id) REFERENCES public.queries(id) ON DELETE CASCADE;


--
-- Name: time_entry_journals fk_rails_f6e3d60ab5; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entry_journals
    ADD CONSTRAINT fk_rails_f6e3d60ab5 FOREIGN KEY (logged_by_id) REFERENCES public.users(id);


--
-- Name: bcf_viewpoints fk_rails_fa5c88e5be; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bcf_viewpoints
    ADD CONSTRAINT fk_rails_fa5c88e5be FOREIGN KEY (issue_id) REFERENCES public.bcf_issues(id) ON DELETE CASCADE;


--
-- Name: ordered_work_packages fk_rails_fe038e4e03; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ordered_work_packages
    ADD CONSTRAINT fk_rails_fe038e4e03 FOREIGN KEY (work_package_id) REFERENCES public.work_packages(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 77TwRn6COBC42aEVr2Pq7dAwNobAn369vtPSBYdLJGyV4KnrBiOae2XLzLGTZWp

